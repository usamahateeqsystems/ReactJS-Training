import { login } from '../js/login.js'

export default function LoginPage() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center p-6">
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm w-full max-w-5xl overflow-hidden grid grid-cols-1 md:grid-cols-2 min-h-[560px]">
        <div className="sidebar-bg p-10 text-white flex flex-col justify-between">
          <div>
            <div className="text-[34px] font-extrabold tracking-wide">ADIB</div>
            <div className="brand-ar text-blue-200 text-[13px] mt-1">مصرف أبوظبي الإسلامي</div>
            <div className="mt-12">
              <h1 className="text-[26px] font-bold leading-tight">Sukkuk Personal Finance Dashboard</h1>
              <p className="text-blue-100 text-[13px] mt-3 leading-6 max-w-sm">
                Secure access to application monitoring, review, and decision workflows.
              </p>
            </div>
          </div>
          <div className="text-blue-200 text-[11px]">Role-based access · Secure workflow portal</div>
        </div>

        <div className="p-10 flex flex-col justify-center">
          <div className="mb-7">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-4">
              <i className="fas fa-lock text-lg"></i>
            </div>
            <h2 className="text-[24px] font-bold text-gray-900">Login</h2>
            <p className="text-[13px] text-gray-500 mt-1">Enter a username to continue.</p>
          </div>

          <form onSubmit={login} className="space-y-4">
            <div>
              <label className="block text-[11px] font-semibold text-gray-600 mb-1.5" htmlFor="username">Username</label>
              <input id="username" name="username" className="field-input" placeholder="Enter your username" autoComplete="username" required />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-gray-600 mb-1.5" htmlFor="password">Password</label>
              <input id="password" name="password" type="password" className="field-input" placeholder="Enter your password" autoComplete="current-password" />
            </div>
            <button className="w-full rounded-xl px-4 py-3 text-[13px] font-semibold text-white bg-blue-600 hover:bg-blue-700 flex items-center justify-center gap-2">
              <i className="fas fa-right-to-bracket text-[12px]"></i> Login
            </button>
          </form>
          <p className="mt-6 text-[11px] text-gray-400 text-center">Use your assigned credentials to continue.</p>
        </div>
      </div>
    </div>
  )
}
