import { useLayoutEffect } from 'react'
import { mountOverview } from '../js/overview.js'

export default function OverviewPage() {
  useLayoutEffect(() => {
    mountOverview()
  }, [])

  return (
    <>
      <div className="flex min-h-screen">
        {/* Sidebar */}
        <aside className="sidebar-bg w-[180px] min-h-screen flex flex-col fixed left-0 top-0 z-30">
          <div className="flex flex-col items-center pt-6 pb-8">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-white text-[28px] font-extrabold tracking-wide">
                ADIB
              </span>
            </div>
            <span className="text-blue-200 text-[11px] mt-0.5 brand-ar">
              مصرف أبوظبي الإسلامي
            </span>
          </div>
          <nav className="flex flex-col gap-1 px-3">
            <a className="flex items-center gap-3 px-4 py-3 rounded-xl text-white font-medium text-[13px] nav-active" href="overview">
              <i className="fas fa-chart-line text-[16px]"></i>
              <span>
                Overview
              </span>
            </a>
            <a className="flex items-center gap-3 px-4 py-3 rounded-xl text-blue-200 hover:text-white text-[13px] transition" href="application-tracker">
              <i className="fas fa-clipboard-list text-[16px]"></i>
              <span>
                Application Tracker
              </span>
            </a>
            <a className="flex items-center gap-3 px-4 py-3 rounded-xl text-blue-200 hover:text-white text-[13px] transition" href="maker">
              <i className="fas fa-user-check text-[16px]"></i>
              <span>
                Maker Stage
              </span>
            </a>
            <a className="flex items-center gap-3 px-4 py-3 rounded-xl text-blue-200 hover:text-white text-[13px] transition" href="#">
              <i className="fas fa-cog text-[16px]"></i>
              <span>
                Settings
              </span>
            </a>
          </nav>
          <div className="mt-auto flex items-center gap-3 px-4 py-5">
            <div className="w-9 h-9 bg-blue-300/40 rounded-full flex items-center justify-center">
              <i className="fas fa-user text-white/80 text-sm"></i>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-white text-[12px] font-medium flex items-center gap-1 truncate">
                Ahmed Al Mansoori 
                <i className="fas fa-chevron-down text-[7px] text-blue-300 ml-0.5"></i>
              </span>
              <span className="text-blue-300 text-[10px]">
                Operations Manager
              </span>
            </div>
          </div>
        </aside>
        {/* Main */}
        <main className="main-content flex-1 p-6 min-h-screen">
          {/* Header */}
          <div className="flex items-start justify-between mb-5 gap-4 flex-wrap">
            <div>
              <h1 className="text-[22px] font-bold text-gray-900 leading-tight">
                Sukkuk — Management Overview
              </h1>
              <p className="text-blue-600 text-[13px] mt-1">
                Sukkuk Personal Finance application processing — performance &amp; trends
              </p>
            </div>
            <div className="flex items-center gap-3">
              {/* Export menu */}
              <div className="relative">
                <button className="flex items-center gap-2 border border-gray-200 rounded-lg px-4 py-2.5 text-[13px] text-gray-700 bg-white hover:bg-gray-50 shadow-sm" id="exportBtn" onClick={(event) => { window.toggleExportMenu(event) }}>
                  <i className="fas fa-download text-blue-600 text-sm"></i>
                  <span className="font-medium">
                    Export
                  </span>
                  <i className="fas fa-chevron-down text-[10px] text-gray-400 ml-1"></i>
                </button>
                <div className="hidden absolute right-0 top-full mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-20 min-w-[200px] overflow-hidden" id="exportMenu">
                  <button className="flex items-center gap-3 px-4 py-2.5 text-[13px] text-gray-700 hover:bg-gray-50 w-full text-left" onClick={(event) => { window.exportDashboardPDF() }}>
                    <i className="far fa-file-pdf text-red-500 w-4"></i>
                    <span>
                      Export as PDF
                    </span>
                  </button>
                  <button className="flex items-center gap-3 px-4 py-2.5 text-[13px] text-gray-700 hover:bg-gray-50 w-full text-left" onClick={(event) => { window.exportDashboardDOCX() }}>
                    <i className="far fa-file-word text-blue-600 w-4"></i>
                    <span>
                      Export as Word
                    </span>
                  </button>
                  <button className="flex items-center gap-3 px-4 py-2.5 text-[13px] text-gray-700 hover:bg-gray-50 w-full text-left" onClick={(event) => { window.exportDashboardImage() }}>
                    <i className="far fa-file-image text-green-600 w-4"></i>
                    <span>
                      Export as Image
                    </span>
                  </button>
                </div>
              </div>
              <button className="flex items-center gap-2 border border-gray-200 rounded-lg px-4 py-2.5 text-[13px] text-gray-700 bg-white hover:bg-gray-50 shadow-sm">
                <i className="far fa-calendar text-blue-600 text-sm"></i>
                <span className="font-medium">
                  Last 30 days
                </span>
                <i className="fas fa-chevron-down text-[10px] text-gray-400 ml-1"></i>
              </button>
            </div>
          </div>
          {/* Toast (used by export flow) */}
          <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-5 py-3 rounded-lg shadow-lg text-[13px] z-50 opacity-0 pointer-events-none transition-opacity duration-200" id="toast"></div>
          {/* KPIs (5 cards) */}
          <div className="grid grid-cols-5 gap-3 mb-4">
            <div className="bg-white rounded-2xl p-4 border border-gray-100/80 shadow-sm">
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="w-[40px] h-[40px] rounded-xl flex items-center justify-center icon-bg-blue">
                  <i className="fas fa-file-alt text-blue-600 text-[17px]"></i>
                </div>
                <div className="text-[12px] text-gray-600 font-medium leading-snug">
                  Total Applications
                  <br />
                  Processed
                </div>
              </div>
              <div className="text-[28px] font-bold text-gray-900 leading-none" id="kpiProcessed">
                2,000
              </div>
              <div className="text-[11px] mt-2" id="kpiProcessedDelta"></div>
            </div>
            <div className="bg-white rounded-2xl p-4 border border-gray-100/80 shadow-sm">
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="w-[40px] h-[40px] rounded-xl flex items-center justify-center icon-bg-blue">
                  <i className="far fa-clock text-blue-600 text-[17px]"></i>
                </div>
                <div className="text-[12px] text-gray-600 font-medium leading-snug">
                  Average Time
                  <br />
                  to Complete
                </div>
              </div>
              <div className="text-[28px] font-bold text-gray-900 leading-none">
                <span id="kpiTime">
                  25
                </span>
                {' '}
                <span className="text-[15px] font-semibold text-gray-500">
                  min
                </span>
              </div>
              <div className="text-[11px] mt-2" id="kpiTimeDelta"></div>
            </div>
            {/* Completed KPI: hover reveals outcome split */}
            <div className="group relative bg-white rounded-2xl p-4 border border-gray-100/80 shadow-sm cursor-help" tabIndex="0">
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="w-[40px] h-[40px] rounded-xl flex items-center justify-center icon-bg-green">
                  <i className="fas fa-check-double text-green-600 text-[17px]"></i>
                </div>
                <div className="text-[12px] text-gray-600 font-medium leading-snug">
                  Total Applications
                  <br />
                  Completed
                </div>
              </div>
              <div className="text-[28px] font-bold text-gray-900 leading-none" id="kpiCompleted">
                1,500
              </div>
              <div className="text-[11px] mt-2" id="kpiCompletedDelta"></div>
              <div className="pointer-events-none absolute left-1/2 top-full z-40 mt-2 w-[210px] -translate-x-1/2 rounded-xl border border-gray-200 bg-white p-3 opacity-0 shadow-xl transition-opacity duration-150 group-hover:opacity-100 group-focus:opacity-100">
                <div className="text-[11px] font-semibold text-gray-900 mb-2">
                  Completed application outcomes
                </div>
                <div className="flex items-center justify-between text-[11px] py-1">
                  <span className="text-gray-600">
                    Accepted applications
                  </span>
                  <span className="font-bold text-green-600" id="kpiCompletedAccepted">
                    1,300
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] py-1">
                  <span className="text-gray-600">
                    Rejected applications
                  </span>
                  <span className="font-bold text-red-600" id="kpiCompletedRejected">
                    200
                  </span>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-4 border border-gray-100/80 shadow-sm">
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="w-[40px] h-[40px] rounded-xl flex items-center justify-center icon-bg-orange">
                  <i className="fas fa-flag text-orange-500 text-[17px]"></i>
                </div>
                <div className="text-[12px] text-gray-600 font-medium leading-snug">
                  Applications
                  <br />
                  with Discrepancies
                </div>
              </div>
              <div className="text-[28px] font-bold text-gray-900 leading-none" id="kpiFlagged">
                500
              </div>
              <div className="text-[11px] mt-2" id="kpiExceptionsDelta"></div>
            </div>
            <div className="bg-white rounded-2xl p-4 border border-gray-100/80 shadow-sm">
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="w-[40px] h-[40px] rounded-xl flex items-center justify-center icon-bg-indigo">
                  <i className="fas fa-hourglass-half text-indigo-600 text-[17px]"></i>
                </div>
                <div className="text-[12px] text-gray-600 font-medium leading-snug">
                  Applications
                  <br />
                  Pending
                </div>
              </div>
              <div className="text-[28px] font-bold text-gray-900 leading-none" id="kpiPending">
                500
              </div>
              <div className="text-[11px] mt-2" id="kpiPendingDelta"></div>
            </div>
          </div>
          {/* Charts Row: Status Breakdown + Multi-series Trend */}
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="bg-white rounded-2xl p-5 border border-gray-100/80 shadow-sm flex flex-col">
              <h3 className="text-blue-700 font-semibold text-[15px] mb-4">
                Application Status Breakdown
              </h3>
              <div className="relative h-[220px] flex">
                <div className="flex flex-col justify-between text-[11px] text-gray-400 w-10 pb-7 pr-2 text-right" id="statusYAxis"></div>
                <div className="flex-1 flex items-end justify-center gap-8 pb-7 relative" id="statusBarsContainer">
                  <div className="absolute inset-0 bottom-7 flex flex-col justify-between pointer-events-none">
                    <div className="border-b border-gray-100"></div>
                    <div className="border-b border-gray-100"></div>
                    <div className="border-b border-gray-100"></div>
                    <div className="border-b border-gray-100"></div>
                    <div className="border-b border-gray-200"></div>
                  </div>
                </div>
              </div>
              {/* Rate tiles fill the empty space below the bars and add at-a-glance % */}
              <div className="mt-auto pt-4 grid grid-cols-3 gap-2.5">
                <div className="text-center rounded-xl py-3 border-2 border-gray-200">
                  <div className="text-[22px] font-bold text-green-600" id="rateCompleted">
                    75.0%
                  </div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mt-0.5">
                    Completion Rate
                  </div>
                </div>
                <div className="text-center rounded-xl py-3 border-2 border-gray-200">
                  <div className="text-[22px] font-bold text-orange-500" id="rateFlagged">
                    25.0%
                  </div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mt-0.5">
                    Flag Rate
                  </div>
                </div>
                <div className="text-center rounded-xl py-3 border-2 border-gray-200">
                  <div className="text-[22px] font-bold text-indigo-600" id="ratePending">
                    25.0%
                  </div>
                  <div className="text-[10px] text-gray-500 uppercase tracking-wider mt-0.5">
                    Pending Rate
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-gray-100/80 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-blue-700 font-semibold text-[15px]">
                  Application Volume Trend
                </h3>
                <div className="flex items-center bg-gray-100 rounded-full p-[3px]">
                  <button className="px-3 py-1 text-[11px] text-gray-500 rounded-full font-medium">
                    Daily
                  </button>
                  <button className="px-3 py-1 text-[11px] text-gray-500 rounded-full font-medium">
                    Weekly
                  </button>
                  <button className="px-3 py-1 text-[11px] text-white rounded-full font-semibold bg-brand">
                    Monthly
                  </button>
                </div>
              </div>
              {/* Legend */}
              <div className="flex items-center gap-4 text-[11px] mb-3 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 inline-block bg-brand"></span>
                  <span className="text-gray-600">
                    Total
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 inline-block legend-completed"></span>
                  <span className="text-gray-600">
                    Completed
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 inline-block legend-discrepancy"></span>
                  <span className="text-gray-600">
                    Discrepancy
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-0.5 inline-block legend-pending"></span>
                  <span className="text-gray-600">
                    Pending
                  </span>
                </div>
              </div>
              <div className="relative h-[260px] flex">
                <div className="flex flex-col justify-between text-[11px] text-gray-400 w-10 pb-0 pr-2 text-right" id="trendYAxis"></div>
                <div className="flex-1 relative">
                  <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                    <div className="border-b border-gray-100"></div>
                    <div className="border-b border-gray-100"></div>
                    <div className="border-b border-gray-100"></div>
                    <div className="border-b border-gray-200"></div>
                  </div>
                  <svg className="w-full h-full" id="trendSvg" viewBox="0 0 500 150" preserveAspectRatio="none"></svg>
                </div>
              </div>
              <div className="flex justify-between ml-10 text-[11px] text-gray-400 mt-2">
                <span>
                  Jan
                </span>
                <span>
                  Feb
                </span>
                <span>
                  Mar
                </span>
                <span>
                  Apr
                </span>
                <span>
                  May
                </span>
                <span>
                  Jun
                </span>
                <span>
                  Jul
                </span>
                <span>
                  Aug
                </span>
              </div>
            </div>
          </div>
          {/* Sub-Product Performance (product-level summary table) */}
          <div className="bg-white rounded-2xl p-5 border border-gray-100/80 shadow-sm mb-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-blue-700 font-semibold text-[15px]">
                  Sub-Product Performance
                </h3>
                <p className="text-[11px] text-gray-500 mt-0.5">
                  One row per Sukkuk sub-product · Last 30 days
                </p>
              </div>
            </div>
            <table className="w-full text-[12px]">
              <thead>
                <tr className="text-blue-600 text-[11px] font-semibold border-b border-gray-100">
                  <th className="pb-3 text-left">
                    Sub-Product
                  </th>
                  <th className="pb-3 text-right">
                    Volume
                  </th>
                  <th className="pb-3 text-right">
                    Completed
                  </th>
                  <th className="pb-3 text-right">
                    Accepted
                  </th>
                  <th className="pb-3 text-right">
                    Rejected
                  </th>
                  <th className="pb-3 text-right">
                    Discrepancy
                  </th>
                  <th className="pb-3 text-right pr-4">
                    Completion Rate
                  </th>
                  <th className="pb-3 text-left">
                    Top Discrepancy
                  </th>
                </tr>
              </thead>
              <tbody id="subProductPerfBody"></tbody>
            </table>
          </div>
          {/* Bottom: Recent Applications + Most Common Rejection Reasons */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-gray-100/80 shadow-sm flex flex-col recent-panel">
              <div className="flex items-center justify-between mb-3 flex-shrink-0">
                <h3 className="text-blue-700 font-semibold text-[15px]">
                  Recent Applications
                </h3>
                <a className="text-blue-600 text-[12px] font-medium hover:underline" href="application-tracker">
                  Open Application Tracker 
                  <i className="fas fa-arrow-right text-[10px] ml-0.5"></i>
                </a>
              </div>
              <div className="overflow-y-auto flex-1 min-h-0 -mx-2 px-2">
                <table className="w-full text-[12px]">
                  <thead className="sticky top-0 bg-white z-10">
                    <tr className="text-blue-600 text-[11px] font-semibold border-b border-gray-100">
                      <th className="pb-3 text-left">
                        Application ID
                      </th>
                      <th className="pb-3 text-left">
                        Customer
                      </th>
                      <th className="pb-3 text-left">
                        Status
                      </th>
                      <th className="pb-3 text-left">
                        Discrepancy
                      </th>
                      <th className="pb-3 text-left">
                        Submitted
                      </th>
                    </tr>
                  </thead>
                  <tbody id="recentApplicationsBody">
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014452') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014452
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Ahmed Al Mansoori
                      </td>
                      <td className="py-2.5">
                        <span className="bg-purple-100 text-purple-700 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">
                          Pending Assignment
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">
                          Yes
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        14 May 2026, 10:34 AM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014563') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014563
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Fatima Al Shamsi
                      </td>
                      <td className="py-2.5">
                        <span className="bg-blue-100 text-blue-700 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">
                          With FinnOne – Checker Stage
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">
                          No
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        14 May 2026, 9:19 AM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014689') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014689
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Khalid Al Nuaimi
                      </td>
                      <td className="py-2.5">
                        <span className="bg-blue-100 text-blue-700 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">
                          With FinnOne – Checker Stage
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">
                          No
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        13 May 2026, 2:02 PM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014568') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014568
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Mariam Al Maktoum
                      </td>
                      <td className="py-2.5">
                        <span className="bg-purple-100 text-purple-700 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">
                          Pending Assignment
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">
                          Yes
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        13 May 2026, 01:19 PM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014576') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014576
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Yousef Al Falasi
                      </td>
                      <td className="py-2.5">
                        <span className="bg-green-100 text-green-700 px-2.5 py-1 rounded-full text-[10px] font-medium" title="Accepted">
                          Completed
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">
                          No
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        13 May 2026, 11:47 AM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014581') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014581
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Sara Al Hashimi
                      </td>
                      <td className="py-2.5">
                        <span className="bg-green-100 text-green-700 px-2.5 py-1 rounded-full text-[10px] font-medium" title="Rejected">
                          Completed
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">
                          Yes
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        13 May 2026, 09:12 AM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014622') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014622
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Omar Al Suwaidi
                      </td>
                      <td className="py-2.5">
                        <span className="bg-orange-100 text-orange-700 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">
                          Pending at Maker
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">
                          No
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        13 May 2026, 08:45 AM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014701') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014701
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Layla Al Zaabi
                      </td>
                      <td className="py-2.5">
                        <span className="bg-orange-100 text-orange-700 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">
                          Pending at Maker
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">
                          Yes
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        12 May 2026, 03:21 PM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014734') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014734
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Hessa Al Marri
                      </td>
                      <td className="py-2.5">
                        <span className="bg-green-100 text-green-700 px-2.5 py-1 rounded-full text-[10px] font-medium" title="Accepted">
                          Completed
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">
                          No
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        12 May 2026, 01:08 PM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014755') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014755
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Abdullah Al Qubaisi
                      </td>
                      <td className="py-2.5">
                        <span className="bg-blue-100 text-blue-700 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">
                          With FinnOne – Checker Stage
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">
                          No
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        12 May 2026, 11:42 AM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014772') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014772
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Reem Al Dhaheri
                      </td>
                      <td className="py-2.5">
                        <span className="bg-green-100 text-green-700 px-2.5 py-1 rounded-full text-[10px] font-medium" title="Accepted">
                          Completed
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">
                          No
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        12 May 2026, 10:15 AM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014798') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014798
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Hamad Al Ameri
                      </td>
                      <td className="py-2.5">
                        <span className="bg-orange-100 text-orange-700 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">
                          Pending at Maker
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">
                          Yes
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        11 May 2026, 04:33 PM
                      </td>
                    </tr>
                    <tr className="border-b border-gray-50 table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014811') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014811
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Noura Al Kaabi
                      </td>
                      <td className="py-2.5">
                        <span className="bg-green-100 text-green-700 px-2.5 py-1 rounded-full text-[10px] font-medium" title="Accepted">
                          Completed
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">
                          No
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        11 May 2026, 02:16 PM
                      </td>
                    </tr>
                    <tr className="table-row-hover cursor-pointer" onClick={(event) => { window.openInApplicationTracker('SAK-2026-014826') }}>
                      <td className="py-2.5 text-blue-600 font-medium">
                        SAK-2026-014826
                      </td>
                      <td className="py-2.5 text-gray-800">
                        Salem Al Mazrouei
                      </td>
                      <td className="py-2.5">
                        <span className="bg-green-100 text-green-700 px-2.5 py-1 rounded-full text-[10px] font-medium" title="Rejected">
                          Completed
                        </span>
                      </td>
                      <td className="py-2.5">
                        <span className="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">
                          Yes
                        </span>
                      </td>
                      <td className="py-2.5 text-gray-500">
                        11 May 2026, 11:50 AM
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            {/* Most Common Rejection Reasons (across all rejected applications) */}
            <div className="bg-white rounded-2xl p-5 border border-gray-100/80 shadow-sm flex flex-col">
              <div className="mb-4">
                <h3 className="text-blue-700 font-semibold text-[15px]">
                  Most Common Rejection Reasons
                </h3>
                <p className="text-[11px] text-gray-500 mt-0.5">
                  Across all rejected applications · Last 30 days
                </p>
              </div>
              <div className="space-y-3 flex-1" id="rejectionReasonsList"></div>
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100 text-[11px]">
                <span className="text-gray-500">
                  Total rejected applications
                </span>
                <span className="text-gray-900 font-semibold" id="totalRejectedCount">
                  200
                </span>
              </div>
            </div>
          </div>
        </main>
      </div>
    </>
  )
}
