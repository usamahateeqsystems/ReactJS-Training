export default function CheckerPage() {
  return (
    <p>Phase 1 Checker processing is handled in FinnOne. Redirecting to the Application Tracker…</p>
  )
}
