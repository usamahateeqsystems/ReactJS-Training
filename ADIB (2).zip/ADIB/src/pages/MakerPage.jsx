import { useLayoutEffect } from 'react'
import { mountMaker } from '../js/maker.js'

export default function MakerPage() {
  useLayoutEffect(() => {
    mountMaker()
  }, [])

  return (
    <>
      <div className="flex min-h-screen">
        {/* Sidebar */}
        <aside className="sidebar-bg w-[180px] min-h-screen flex flex-col fixed left-0 top-0 z-30">
          <div className="flex flex-col items-center pt-6 pb-8">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-white text-[28px] font-extrabold tracking-wide">
                ADIB
              </span>
            </div>
            <span className="text-blue-200 text-[11px] mt-0.5 brand-ar">
              مصرف أبوظبي الإسلامي
            </span>
          </div>
          <nav className="flex flex-col gap-1 px-3">
            <a className="flex items-center gap-3 px-4 py-3 rounded-xl text-blue-200 hover:text-white text-[13px] transition nav-idle" href="overview">
              <i className="fas fa-chart-line text-[16px]"></i>
              <span>
                Overview
              </span>
            </a>
            <a className="flex items-center gap-3 px-4 py-3 rounded-xl text-blue-200 hover:text-white text-[13px] transition nav-idle" href="application-tracker">
              <i className="fas fa-clipboard-list text-[16px]"></i>
              <span>
                Application Tracker
              </span>
            </a>
            <a className="flex items-center gap-3 px-4 py-3 rounded-xl text-white font-medium text-[13px] nav-active" href="maker">
              <i className="fas fa-user-check text-[16px]"></i>
              <span>
                Maker Stage
              </span>
            </a>
            <a className="flex items-center gap-3 px-4 py-3 rounded-xl text-blue-200 hover:text-white text-[13px] transition nav-idle" href="#">
              <i className="fas fa-cog text-[16px]"></i>
              <span>
                Settings
              </span>
            </a>
          </nav>
          <div className="mt-auto flex items-center gap-3 px-4 py-5">
            <div className="w-9 h-9 bg-blue-300/40 rounded-full flex items-center justify-center">
              <i className="fas fa-user text-white/80 text-sm"></i>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-white text-[12px] font-medium flex items-center gap-1 truncate">
                Mariam Khalid 
                <i className="fas fa-chevron-down text-[7px] text-blue-300 ml-0.5"></i>
              </span>
              <span className="text-blue-300 text-[10px]">
                Maker Reviewer
              </span>
            </div>
          </div>
        </aside>
        {/* Main Content */}
        <main className="main-content flex-1 p-6 min-h-screen" id="mainContent">
          {/* Header */}
          <div className="flex items-start justify-between mb-5">
            <div>
              <h1 className="text-[22px] font-bold text-gray-900 leading-tight">
                Sukkuk — Maker Stage
              </h1>
              <p className="text-blue-600 text-[13px] mt-1">
                Review application-level details and approve or reject applications
              </p>
            </div>
          </div>
          {/* Search & Filters */}
          <div className="bg-white rounded-2xl p-5 border border-gray-100/80 shadow-sm mb-5">
            {/* Search Bar */}
            <div className="flex items-center gap-3 mb-4">
              <div className="flex-1 relative">
                <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                <input className="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl text-[13px] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" id="searchInput" type="text" placeholder="Search by Application ID, Customer Name, Emirates ID, Submitted By, or Branch Name" />
              </div>
            </div>
            {/* Status Pills */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[11px] font-semibold text-gray-500 mr-2">
                STATUS
              </span>
              <button className="status-pill active" data-status="all">
                Maker Queue 
                <span className="count">
                  —
                </span>
              </button>
              <button className="status-pill" data-status="pendingatmaker">
                Pending at Maker 
                <span className="count">
                  —
                </span>
              </button>
            </div>
          </div>
          {/* Results */}
          <div className="bg-white rounded-2xl border border-gray-100/80 shadow-sm overflow-hidden" id="resultsContainer">
            {/* Empty state */}
            <div className="text-center py-20 px-6" id="emptyState">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-search text-blue-500 text-2xl"></i>
              </div>
              <h3 className="text-[16px] font-semibold text-gray-900 mb-2">
                No applications are waiting for Maker review
              </h3>
              <p className="text-[13px] text-gray-500 max-w-md mx-auto">
                Maker decisions hand applications back to FinnOne, where the Checker stage is completed outside the AI platform.
              </p>
            </div>
            {/* Results Table (hidden until search) */}
            <div className="hidden" id="resultsList">
              <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
                <div className="text-[13px] text-gray-600">
                  <span className="font-semibold text-gray-900" id="resultsCount">
                    0
                  </span>
                  applications found
                </div>
                <div className="flex items-center gap-3">
                  <button className="text-[12px] text-gray-500 hover:underline" onClick={(event) => { window.resetDemoState() }}>
                    Reset demo
                  </button>
                  <button className="text-[12px] text-blue-600 hover:underline" onClick={(event) => { window.clearFilters() }}>
                    Clear filters
                  </button>
                  {/* Export menu */}
                  <div className="relative">
                    <button className="flex items-center gap-2 border border-gray-200 rounded-lg px-3 py-1.5 text-[12px] text-gray-700 bg-white hover:bg-gray-50" id="exportBtn" onClick={(event) => { window.toggleExportMenu(event) }}>
                      <i className="fas fa-download text-blue-600 text-[11px]"></i>
                      <span className="font-medium">
                        Export
                      </span>
                      <i className="fas fa-chevron-down text-[9px] text-gray-400"></i>
                    </button>
                    <div className="hidden absolute right-0 top-full mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-20 min-w-[190px] overflow-hidden" id="exportMenu">
                      <button className="flex items-center gap-3 px-4 py-2.5 text-[13px] text-gray-700 hover:bg-gray-50 w-full text-left" onClick={(event) => { window.exportResultsPDF() }}>
                        <i className="far fa-file-pdf text-red-500 w-4"></i>
                        <span>
                          Export as PDF
                        </span>
                      </button>
                      <button className="flex items-center gap-3 px-4 py-2.5 text-[13px] text-gray-700 hover:bg-gray-50 w-full text-left" onClick={(event) => { window.exportResultsExcel() }}>
                        <i className="far fa-file-excel text-green-600 w-4"></i>
                        <span>
                          Export as Excel
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[1420px] text-[12px]">
                  <thead>
                    <tr className="text-blue-600 text-[11px] font-semibold bg-gray-50 border-b border-gray-100">
                      <th className="py-3 px-5 text-left">
                        Application ID
                      </th>
                      <th className="py-3 text-left">
                        Customer
                      </th>
                      <th className="py-3 text-left">
                        Submitted By
                      </th>
                      <th className="py-3 text-left">
                        Branch Name
                      </th>
                      <th className="py-3 text-left">
                        Submitted
                      </th>
                      <th className="py-3 text-left">
                        FinnOne Application Status
                      </th>
                      <th className="py-3 text-left">
                        Workflow Status
                      </th>
                      <th className="py-3 text-left">
                        Discrepancy
                      </th>
                      <th className="py-3 text-left">
                        AI Agent Count
                      </th>
                      <th className="py-3 px-5 w-6"></th>
                    </tr>
                  </thead>
                  <tbody id="resultsBody"></tbody>
                </table>
              </div>
            </div>
          </div>
        </main>
        {/* Application Detail Panel */}
        <aside className="detail-panel fixed right-0 top-0 w-[450px] h-full bg-white border-l border-gray-200 overflow-y-auto z-40" id="detailPanel">
          <div className="p-6">
            {/* Application number — prominent at top */}
            <div className="flex items-start justify-between mb-4 gap-3">
              <div className="min-w-0 flex-1">
                <p className="text-[10px] text-blue-600 font-bold uppercase tracking-wider mb-0.5">
                  Application
                </p>
                <h2 className="text-[22px] font-bold text-gray-900 leading-tight break-all" id="detailAppId"></h2>
                <div className="mt-1.5">
                  <span id="detailStatusBadge"></span>
                </div>
              </div>
              <button className="text-gray-400 hover:text-gray-600 w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-lg hover:bg-gray-100 transition" onClick={(event) => { window.closeDetailPanel() }}>
                <i className="fas fa-times text-lg"></i>
              </button>
            </div>
            {/* Application Details accordion (COLLAPSED by default) */}
            <details className="bg-blue-50 rounded-xl border border-blue-100 mb-4 overflow-hidden">
              <summary className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-blue-100/50 transition">
                <span className="text-[13px] font-semibold text-gray-900 flex items-center gap-2">
                  <i className="fas fa-user-circle text-blue-600"></i>
                  Application Details
                </span>
                <i className="fas fa-chevron-right text-gray-400 text-[11px] chevron"></i>
              </summary>
              <div className="px-4 pt-3 pb-4 space-y-2.5 text-[12px] border-t border-blue-100">
                <div className="flex justify-between gap-4">
                  <span className="text-gray-600">
                    Customer
                  </span>
                  <span className="text-gray-900 font-semibold text-right" id="detailCustomer"></span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-600">
                    Emirates ID
                  </span>
                  <span className="text-gray-900 font-medium text-right" id="detailEid"></span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-600">
                    Submitted By
                  </span>
                  <span className="text-gray-900 font-medium text-right" id="detailSubmittedBy"></span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-600">
                    Branch Name
                  </span>
                  <span className="text-gray-900 font-medium text-right" id="detailBranchId"></span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-600">
                    FinnOne Application Status
                  </span>
                  <span className="text-gray-900 font-medium text-right" id="detailFinnOneStatus"></span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-600">
                    AI Agent Processing Count
                  </span>
                  <span className="text-gray-900 font-medium text-right" id="detailAiProcessingCount"></span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-600">
                    Submitted
                  </span>
                  <span className="text-gray-900 text-right" id="detailSubmitted"></span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-gray-600">
                    Discrepancy
                  </span>
                  <span className="text-right" id="detailFlagged"></span>
                </div>
                <div className="flex justify-between gap-4 is-hidden" id="detailOutcomeRow">
                  <span className="text-gray-600">
                    Completion Outcome
                  </span>
                  <span className="text-gray-900 font-semibold text-right" id="detailOutcome"></span>
                </div>
                <div className="flex justify-between gap-4 is-hidden" id="detailCompletedAtRow">
                  <span className="text-gray-600">
                    Completed On
                  </span>
                  <span className="text-gray-900 font-medium text-right" id="detailCompletedAt"></span>
                </div>
                <div className="flex justify-between gap-4 is-hidden" id="detailRejectionAtRow">
                  <span className="text-gray-600">
                    Rejection Date &amp; Time
                  </span>
                  <span className="text-gray-900 font-medium text-right" id="detailRejectionAt"></span>
                </div>
                <div className="flex justify-between gap-4 items-start is-hidden" id="detailRejectionReasonRow">
                  <span className="text-gray-600 flex-shrink-0">
                    RFO Processor Comments
                  </span>
                  <span className="text-gray-900 font-medium text-right break-words max-w-[245px]" id="detailRejectionReason"></span>
                </div>
                <div className="hidden" id="detailCheckerCommentsRow">
                  <span id="detailCheckerComments"></span>
                </div>
              </div>
            </details>
            {/* Discrepancy Documents — surfaced FIRST so the reviewer sees them immediately */}
            <div className="mb-5 is-hidden" id="flaggedDocsSection">
              <div className="bg-red-50 border-l-4 border-red-500 rounded-r-xl p-4">
                <h3 className="text-red-900 font-semibold text-[13px] mb-3 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <i className="fas fa-exclamation-triangle"></i>
                    Discrepancy Documents — Review First
                  </span>
                  <span className="bg-red-200 text-red-800 px-2 py-0.5 rounded-full text-[10px] font-bold" id="flaggedDocsCount"></span>
                </h3>
                <div className="space-y-2" id="flaggedDocsList"></div>
              </div>
            </div>
            {/* All Documents (no discrepancy) */}
            <h3 className="text-gray-900 font-semibold text-[13px] mb-3 flex items-center gap-2">
              <i className="fas fa-folder-open text-gray-400 text-[12px]"></i>
              All Documents
              <span className="text-gray-500 font-normal text-[11px]" id="docCount"></span>
            </h3>
            <div className="space-y-2 mb-5" id="docList"></div>
            {/* Role-specific workflow action area */}
            <div className="mb-5" id="workflowActionCard"></div>
          </div>
        </aside>
      </div>
      {/* Document Detail Modal (validation checklist + extracted fields + image) */}
      <div className="modal" id="docModal" onClick={(event) => { window.closeDocModal(event) }}>
        <div className="modal-card" onClick={(event) => { event.stopPropagation() }}>
          {/* Modal Header */}
          <div className="flex items-center justify-between p-5 border-b border-gray-200">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center" id="modalDocIcon">
                <i className="fas fa-id-card text-blue-600"></i>
              </div>
              <div>
                <h3 className="text-[17px] font-bold text-gray-900" id="modalDocTitle">
                  Emirates ID
                </h3>
                <div className="flex items-center gap-3 mt-1">
                  <span className="doc-status-badge passed" id="modalDocStatus">
                    Passed
                  </span>
                  <span className="text-[11px] text-gray-500" id="modalAppRef">
                    SAK-2026-014452
                  </span>
                </div>
              </div>
            </div>
            <button className="text-gray-400 hover:text-gray-600 w-9 h-9 flex items-center justify-center rounded-lg hover:bg-gray-100 transition" onClick={(event) => { window.closeDocModal() }}>
              <i className="fas fa-times text-xl"></i>
            </button>
          </div>
          {/* Modal Body */}
          <div className="flex-1 overflow-hidden">
            <div className="grid grid-cols-2 h-full modal-split">
              {/* Left: Validation checklist + extracted fields */}
              <div className="p-5 border-r border-gray-200 overflow-y-auto bg-gray-50">
                {/* Validation checklist */}
                <h4 className="text-[13px] font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <i className="fas fa-check-square text-blue-600 text-[12px]"></i>
                  Validation Checks
                </h4>
                <div className="space-y-2 mb-5" id="validationChecks"></div>
                {/* Extracted fields */}
                <h4 className="text-[13px] font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <i className="fas fa-list text-blue-600 text-[12px]"></i>
                  Extracted Fields
                </h4>
                <div className="bg-white rounded-lg border border-gray-200 overflow-hidden mb-3" id="extractedFields"></div>
                <details className="text-[11px] text-gray-500">
                  <summary className="flex items-center gap-2 py-2 cursor-pointer hover:text-gray-700">
                    <i className="fas fa-chevron-right text-[8px] chevron"></i>
                    <span>
                      Audit details
                    </span>
                  </summary>
                  <div className="pl-4 pt-1 space-y-1" id="auditDetails"></div>
                </details>
              </div>
              {/* Right: Document preview (PDF or image, with fullscreen) */}
              <div className="p-5 overflow-y-auto bg-white">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-[13px] font-semibold text-gray-900">
                      Document Preview
                    </h4>
                    <p className="text-[10px] text-gray-500 mt-0.5" id="viewerSubtitle"></p>
                  </div>
                  <div className="flex items-center gap-1 bg-gray-50 rounded-lg border border-gray-200 px-1.5 py-1">
                    <button className="viewer-btn" onClick={(event) => { window.viewerZoom(-0.15) }} title="Zoom out">
                      <i className="fas fa-search-minus"></i>
                    </button>
                    <span className="text-[11px] text-gray-600 font-medium w-10 text-center select-none" id="viewerZoomLabel">
                      100%
                    </span>
                    <button className="viewer-btn" onClick={(event) => { window.viewerZoom(0.15) }} title="Zoom in">
                      <i className="fas fa-search-plus"></i>
                    </button>
                    <div className="w-px h-5 bg-gray-200 mx-1"></div>
                    <button className="viewer-btn" onClick={(event) => { window.viewerResetZoom() }} title="Fit to screen">
                      <i className="fas fa-compress-arrows-alt"></i>
                    </button>
                    <button className="viewer-btn" onClick={(event) => { window.viewerDownload() }} title="Download">
                      <i className="fas fa-download"></i>
                    </button>
                    <button className="viewer-btn" onClick={(event) => { window.viewerToggleFullscreen() }} title="Fullscreen">
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                </div>
                <div className="bg-gray-100 rounded-lg border border-gray-200 relative overflow-hidden viewer-min" id="docViewer">
                  <button className="fs-overlay-btn fs-only is-hidden" onClick={(event) => { window.viewerToggleFullscreen() }}>
                    <i className="fas fa-compress mr-1.5"></i>
                    Exit fullscreen
                  </button>
                  <div className="viewer-content w-full h-full flex items-center justify-center viewer-min">
                    <iframe className="w-full doc-pdf-frame" id="docPdfFrame" frameBorder="0"></iframe>
                    <img className="max-w-full object-contain rounded-md mx-auto doc-image-preview" id="docImagePreview" src="" alt="Document Preview" />
                    <div className="text-center text-gray-400 px-6 py-10" id="docPlaceholder">
                      <i className="fas fa-file-pdf text-5xl text-red-300 mb-3"></i>
                      <p className="text-[13px] text-gray-700 font-medium">
                        PDF preview unavailable in this demo
                      </p>
                      <p className="text-[11px] mt-2 text-gray-500 max-w-xs mx-auto">
                        In production this pane renders the original document with zoom, page navigation and fullscreen. Click the 
                        <i className="fas fa-expand text-gray-400"></i>
                         button above to test fullscreen behaviour.
                      </p>
                      <p className="text-[10px] mt-3 text-gray-400 font-mono" id="placeholderFileMeta"></p>
                    </div>
                  </div>
                </div>
                <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-100 text-[11px] text-blue-700">
                  <i className="fas fa-info-circle mr-1"></i>
                  Validation checks on the left reflect the rules defined for this document type. Each rule reads either match (100%) or no match (0%) — except names, which are fuzzy-matched.
                </div>
              </div>
            </div>
          </div>
          {/* Modal Footer: review-only (no per-doc actions) */}
          <div className="flex items-center justify-end p-4 border-t border-gray-200 bg-gray-50">
            <button className="px-5 py-2 bg-blue-600 text-white rounded-lg text-[12px] font-medium hover:bg-blue-700 transition" onClick={(event) => { window.closeDocModal() }}>
              Close
            </button>
          </div>
        </div>
      </div>
      {/* Overall Approve Modal */}
      <div className="modal" id="overallApproveModal" onClick={(event) => { window.closeOverallApproveModal(event) }}>
        <div className="modal-card small p-6" onClick={(event) => { event.stopPropagation() }}>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-11 h-11 bg-green-100 rounded-full flex items-center justify-center">
              <i className="fas fa-check-double text-green-600 text-lg"></i>
            </div>
            <div>
              <h3 className="text-[16px] font-bold text-gray-900">
                Approve Application
              </h3>
              <p className="text-[11px] text-gray-500" id="overallApproveSubtitle"></p>
            </div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
            <p className="text-[11px] text-green-800">
              <i className="fas fa-info-circle mr-1"></i>
               Maker approval records the RFO Processor decision and moves the workflow status to 
              <strong>
                With FinnOne – Checker Stage
              </strong>
              .
            </p>
          </div>
          <label className="block text-[12px] font-medium text-gray-700 mb-2">
            Comments (optional)
          </label>
          <textarea className="w-full border border-gray-200 rounded-lg p-3 text-[12px] resize-none focus:outline-none focus:ring-2 focus:ring-green-500" id="overallApproveComments" rows="3"></textarea>
          <div className="flex gap-3 mt-4">
            <button className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg text-[12px] font-medium text-gray-700 hover:bg-gray-50" onClick={(event) => { window.closeOverallApproveModal() }}>
              Cancel
            </button>
            <button className="flex-1 px-4 py-2.5 bg-green-600 text-white rounded-lg text-[12px] font-medium hover:bg-green-700 flex items-center justify-center gap-2" onClick={(event) => { window.confirmOverallApprove() }}>
              <i className="fas fa-check-double text-[10px]"></i>
              Confirm Approval
            </button>
          </div>
        </div>
      </div>
      {/* Overall Reject Application Modal */}
      <div className="modal" id="overallRejectModal" onClick={(event) => { window.closeOverallRejectModal(event) }}>
        <div className="modal-card small p-6" onClick={(event) => { event.stopPropagation() }}>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-11 h-11 bg-red-100 rounded-full flex items-center justify-center">
              <i className="fas fa-times text-red-600 text-lg"></i>
            </div>
            <div>
              <h3 className="text-[16px] font-bold text-gray-900">
                Reject Application
              </h3>
              <p className="text-[11px] text-gray-500" id="overallRejectSubtitle"></p>
            </div>
          </div>
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
            <p className="text-[11px] text-red-800">
              <i className="fas fa-exclamation-triangle mr-1"></i>
               This records the RFO Processor 
              <strong>
                Rejected
              </strong>
               decision and moves the workflow status to 
              <strong>
                With FinnOne – Checker Stage
              </strong>
              .
            </p>
          </div>
          <label className="flex items-center gap-2 text-[12px] font-medium text-gray-700 mb-2">
            <i className="fas fa-magic-wand-sparkles text-blue-600 text-[11px]"></i>
            AI-drafted comments
            <span className="text-red-500">
              *
            </span>
            <span className="text-gray-400 font-normal text-[10px]">
              — review and edit as needed
            </span>
          </label>
          <textarea className="w-full border border-gray-200 rounded-lg p-3 text-[11px] resize-none focus:outline-none focus:ring-2 focus:ring-red-500 font-mono" id="overallRejectComments" rows="9" placeholder="AI is drafting…"></textarea>
          <div className="flex gap-3 mt-4">
            <button className="flex-1 px-4 py-2.5 border border-gray-200 rounded-lg text-[12px] font-medium text-gray-700 hover:bg-gray-50" onClick={(event) => { window.closeOverallRejectModal() }}>
              Cancel
            </button>
            <button className="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-lg text-[12px] font-medium hover:bg-red-700 flex items-center justify-center gap-2" onClick={(event) => { window.confirmOverallReject() }}>
              <i className="fas fa-paper-plane text-[10px]"></i>
              Confirm Rejection
            </button>
          </div>
        </div>
      </div>
      {/* Toast */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-5 py-3 rounded-lg shadow-lg text-[13px] z-50 opacity-0 pointer-events-none transition-opacity duration-200" id="toast"></div>
    </>
  )
}
