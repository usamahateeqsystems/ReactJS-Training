import { getHomeModel, logout } from '../js/home.js'

export default function HomePage() {
  const { pages, subtitle } = getHomeModel()

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm w-full max-w-4xl overflow-hidden">
        <div className="sidebar-bg p-7 text-white flex items-center justify-between gap-4">
          <div>
            <div className="text-[28px] font-extrabold tracking-wide">ADIB</div>
            <div className="text-blue-200 text-[12px] mt-1">Sukkuk Personal Finance dashboard mockup</div>
          </div>
          <button
            id="logoutBtn"
            type="button"
            onClick={logout}
            className="text-[12px] border border-white/30 rounded-lg px-3 py-2 hover:bg-white/10"
          >
            Logout
          </button>
        </div>
        <div className="p-7">
          <h1 className="text-[20px] font-bold text-gray-900">Updated mockup pages</h1>
          <p id="subText" className="text-[13px] text-gray-500 mt-1 mb-5">{subtitle}</p>
          <div id="links" className="grid grid-cols-2 gap-3">
            {pages.map((page) => (
              <a
                key={page.href}
                href={page.href}
                className="rounded-xl border border-gray-200 px-4 py-4 hover:border-blue-400 hover:bg-blue-50 transition"
              >
                <div className="text-[13px] font-semibold text-gray-900">{page.title}</div>
                <div className="text-[11px] text-gray-500 mt-1">{page.description}</div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
