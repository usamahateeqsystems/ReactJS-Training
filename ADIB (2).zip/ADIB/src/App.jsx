import { BrowserRouter, Routes, Route } from "react-router-dom";
import './styles/app.css'
import ApplicationTracker from "./pages/ApplicationTrackerPage";
import CheckerPage from "./pages/CheckerPage";
import Login from "./pages/LoginPage";
import Maker from "./pages/MakerPage";
import Overview from "./pages/OverviewPage";
import Home from "./pages/HomePage";

export default function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/index" element={<Home />} />
                <Route path="/" element={<Home />} />
                <Route path="/application-tracker" element={<ApplicationTracker />} />
                <Route path="/checker" element={<CheckerPage />} />
                <Route path="/login" element={<Login />} />
                <Route path="/maker" element={<Maker />} />
                <Route path="/overview" element={<Overview />} />
            </Routes>
        </BrowserRouter>
    );
}