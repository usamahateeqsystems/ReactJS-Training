export function mountOverview() {
  window["fmtNumber"] = fmtNumber;
  window["fmtAxis"] = fmtAxis;
  window["niceCeil"] = niceCeil;
  window["deltaHtml"] = deltaHtml;
  window["renderKpis"] = renderKpis;
  window["renderStatusBars"] = renderStatusBars;
  window["renderTrend"] = renderTrend;
  window["renderRejectionReasons"] = renderRejectionReasons;
  window["renderSubProductPerformance"] = renderSubProductPerformance;
  window["openInApplicationTracker"] = openInApplicationTracker;
  window["toggleExportMenu"] = toggleExportMenu;
  window["toast"] = toast;
  window["fileStamp"] = fileStamp;
  window["snapshotMain"] = snapshotMain;
  window["exportDashboardPDF"] = exportDashboardPDF;
  window["exportDashboardImage"] = exportDashboardImage;
  window["exportDashboardDOCX"] = exportDashboardDOCX;
  window["parseWorkflowApps"] = parseWorkflowApps;
  window["normaliseStatus"] = normaliseStatus;
  window["statusDisplay"] = statusDisplay;
  window["statusPill"] = statusPill;
  window["discrepancyPill"] = discrepancyPill;
  window["connectedSubmittedDate"] = connectedSubmittedDate;
  window["syncOverviewWithWorkflowState"] = syncOverviewWithWorkflowState;
  window["buildFlatTrend"] = buildFlatTrend;
  window["syncSubProductPerformance"] = syncSubProductPerformance;
  window["syncRejectionReasons"] = syncRejectionReasons;
  window["syncRecentApplications"] = syncRecentApplications;

// ============================================================
// SUKKUK DATA — scope is Sukkuk Personal Finance.
// Workflow status and validation flags are deliberately separated:
//   Pending Assignment + Pending at Maker + With FinnOne – Checker Stage + Completed = Total Processed.
//   Discrepancy is an independent Yes / No characteristic and is not a status.
// ============================================================
const KPIS = {
  processed: 2000, processedDelta: 21.0,
  timeMin: 25, timeDelta: -32.4,
  completed: 1500, completedDelta: 18.6,
  accepted: 1300,
  rejected: 200,
  flagged: 500, flaggedDelta: 28.1,
  pending: 500, pendingDelta: 12.3
};

const STATUS_BARS = {
  pendingAssignment: 280,
  pendingMaker: 140,
  pendingChecker: 80,
  completed: 1500
};

// Total and workflow series share a time axis. Discrepancies remain independent.
const TREND_SERIES = [
  { key: 'total',     label: 'Total',     color: '#2952E8', points: [780, 1080, 1240, 1400, 1580, 1750, 1900, 2000] },
  { key: 'completed', label: 'Completed', color: '#16A34A', points: [585,  810,  930, 1050, 1185, 1313, 1425, 1500] },
  { key: 'flagged',   label: 'Discrepancies',   color: '#F97316', points: [195,  270,  310,  350,  395,  437,  475,  500] },
  { key: 'pending',   label: 'Pending',   color: '#4F46E5', points: [195,  270,  310,  350,  395,  437,  475,  500] }
];

const REJECTION_REASONS = [
  { label: 'Customer name mismatch',                 count: 70 },
  { label: 'Emirates ID expired',                    count: 52 },
  { label: 'True Copy stamp not found',              count: 38 },
  { label: 'Amount mismatch with FinOne',            count: 30 },
  { label: 'Customer signature missing',             count: 22 },
  { label: 'ID number mismatch (Validation Report)', count: 18 }
];

const SUB_PRODUCT_PERF = [
  { label: 'Standard',                volume: 1100, completed: 870, accepted: 770, rejected: 100, flagged: 230, topDiscrepancy: 'Customer name mismatch' },
  { label: 'Top-Up / Consolidation',  volume:  500, completed: 370, accepted: 320, rejected:  50, flagged: 130, topDiscrepancy: 'Emirates ID expired' },
  { label: 'Debt Settlement',         volume:  280, completed: 190, accepted: 160, rejected:  30, flagged:  90, topDiscrepancy: 'Amount mismatch (FinOne)' },
  { label: 'PDC (Non-Salaried)',      volume:  120, completed:  70, accepted:  50, rejected:  20, flagged:  50, topDiscrepancy: 'Bank seal missing' }
];

// ============================================================
// FORMATTING
// ============================================================
function fmtNumber(n) { return n.toLocaleString('en-US'); }
function fmtAxis(n) {
  if (n >= 1000) {
    const k = n / 1000;
    return (k % 1 === 0 ? k.toFixed(0) : k.toFixed(1)) + 'K';
  }
  return n.toString();
}
function niceCeil(n) {
  if (n <= 0) return 1;
  const mag = Math.pow(10, Math.floor(Math.log10(n)));
  const norm = n / mag;
  let nice;
  if (norm <= 1) nice = 1;
  else if (norm <= 2) nice = 2;
  else if (norm <= 5) nice = 5;
  else nice = 10;
  return nice * mag;
}
function deltaHtml(delta, lowerIsBetter) {
  const positive = delta >= 0;
  const arrow = positive ? 'fa-arrow-up' : 'fa-arrow-down';
  const good = lowerIsBetter ? delta < 0 : delta >= 0;
  const color = good ? 'text-green-500' : 'text-red-500';
  const sign = positive ? '+' : '';
  return `<span class="${color} font-medium"><i class="fas ${arrow} text-[9px]"></i> ${sign}${delta.toFixed(1)}%</span> <span class="text-gray-400">vs previous 30 days</span>`;
}

// ============================================================
// RENDER
// ============================================================
function renderKpis() {
  const k = KPIS;
  document.getElementById('kpiProcessed').textContent = fmtNumber(k.processed);
  document.getElementById('kpiTime').textContent = k.timeMin;
  document.getElementById('kpiCompleted').textContent = fmtNumber(k.completed);
  document.getElementById('kpiCompletedAccepted').textContent = fmtNumber(k.accepted);
  document.getElementById('kpiCompletedRejected').textContent = fmtNumber(k.rejected);
  document.getElementById('kpiFlagged').textContent = fmtNumber(k.flagged);
  document.getElementById('kpiPending').textContent = fmtNumber(k.pending);

  document.getElementById('kpiProcessedDelta').innerHTML = deltaHtml(k.processedDelta, false);
  document.getElementById('kpiTimeDelta').innerHTML = deltaHtml(k.timeDelta, true);
  document.getElementById('kpiCompletedDelta').innerHTML = deltaHtml(k.completedDelta, false);
  document.getElementById('kpiExceptionsDelta').innerHTML = deltaHtml(k.flaggedDelta, true);
  document.getElementById('kpiPendingDelta').innerHTML = deltaHtml(k.pendingDelta, true);
}

function renderStatusBars() {
  const total = KPIS.processed;
  document.getElementById('rateCompleted').textContent = ((STATUS_BARS.completed / total) * 100).toFixed(1) + '%';
  document.getElementById('rateFlagged').textContent  = ((KPIS.flagged / total) * 100).toFixed(1) + '%';
  document.getElementById('ratePending').textContent = ((KPIS.pending / total) * 100).toFixed(1) + '%';

  const bars = [
    { label: 'Pending Assignment', value: STATUS_BARS.pendingAssignment, color: '#7C3AED' },
    { label: 'Pending at Maker', value: STATUS_BARS.pendingMaker, color: '#F97316' },
    { label: 'With FinnOne – Checker Stage', value: STATUS_BARS.pendingChecker, color: '#2952E8' },
    { label: 'Completed', value: STATUS_BARS.completed, color: '#16A34A' }
  ];
  const maxBarHeight = 150;
  const axisMax = niceCeil(Math.max(...bars.map(b => b.value), 1));
  document.getElementById('statusYAxis').innerHTML =
    [4,3,2,1,0].map(i => `<span>${fmtAxis(Math.round(axisMax * i / 4))}</span>`).join('');

  const container = document.getElementById('statusBarsContainer');
  container.querySelectorAll('.bar-col').forEach(n => n.remove());
  const frag = document.createDocumentFragment();
  bars.forEach(b => {
    const col = document.createElement('div');
    col.className = 'bar-col flex flex-col items-center relative z-10';
    const h = Math.max(2, Math.round((b.value / axisMax) * maxBarHeight));
    col.innerHTML = `
      <span class="text-[13px] font-bold text-gray-800 mb-2">${fmtNumber(b.value)}</span>
      <div class="w-[72px] rounded-t-md transition-all duration-500" style="height: ${h}px; background: ${b.color};"></div>
      <span class="text-[11px] text-gray-500 mt-2 text-center max-w-[92px] leading-tight">${b.label}</span>
    `;
    frag.appendChild(col);
  });
  container.appendChild(frag);
}

// Single consolidated trend chart: all 4 series on one y-axis.
function renderTrend() {
  const axisMax = niceCeil(Math.max(...TREND_SERIES.flatMap(s => s.points), 1));
  const w = 500, h = 150;
  const n = TREND_SERIES[0].points.length;
  const step = w / (n - 1);

  const svgParts = TREND_SERIES.map(series => {
    const coords = series.points.map((v, i) => ({
      x: (i * step).toFixed(1),
      y: (h - (v / axisMax) * h).toFixed(1)
    }));
    const poly = `<polyline points="${coords.map(c => `${c.x},${c.y}`).join(' ')}" fill="none" stroke="${series.color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
    const circles = coords.map(c => `<circle cx="${c.x}" cy="${c.y}" r="3.5" fill="${series.color}" stroke="white" stroke-width="1.5"/>`).join('');
    return poly + circles;
  });

  document.getElementById('trendSvg').innerHTML = svgParts.join('');
  document.getElementById('trendYAxis').innerHTML =
    [3,2,1,0].map(i => `<span>${fmtAxis(Math.round(axisMax * i / 3))}</span>`).join('');
}

function renderRejectionReasons() {
  const max = Math.max(...REJECTION_REASONS.map(r => r.count), 1);
  document.getElementById('rejectionReasonsList').innerHTML = REJECTION_REASONS.map(r => {
    const pct = Math.round((r.count / max) * 100);
    return `
      <div>
        <div class="flex items-center justify-between text-[12px] mb-1.5">
          <span class="text-gray-700">${r.label}</span>
          <span class="text-gray-500"><span class="text-gray-900 font-semibold">${r.count}</span> apps</span>
        </div>
        <div class="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
          <div class="h-2 rounded-full transition-all duration-500 rejection-bar" style="width: ${pct}%;"></div>
        </div>
      </div>
    `;
  }).join('');
}

function renderSubProductPerformance() {
  document.getElementById('subProductPerfBody').innerHTML = SUB_PRODUCT_PERF.map(row => {
    const rate = (row.completed / row.volume) * 100;
    const rateColor = rate >= 75 ? 'text-green-600 bg-green-50' : rate >= 65 ? 'text-amber-600 bg-amber-50' : 'text-red-600 bg-red-50';
    return `
      <tr class="border-b border-gray-50 hover:bg-gray-50/60">
        <td class="py-2.5 text-gray-900 font-medium">${row.label}</td>
        <td class="py-2.5 text-right text-gray-700">${fmtNumber(row.volume)}</td>
        <td class="py-2.5 text-right text-green-700 font-medium">${fmtNumber(row.completed)}</td>
        <td class="py-2.5 text-right text-gray-700">${fmtNumber(row.accepted)}</td>
        <td class="py-2.5 text-right text-red-600 font-medium">${fmtNumber(row.rejected)}</td>
        <td class="py-2.5 text-right text-orange-600 font-medium">${fmtNumber(row.flagged)}</td>
        <td class="py-2.5 text-right pr-4"><span class="${rateColor} font-semibold px-2 py-0.5 rounded text-[11px]">${rate.toFixed(1)}%</span></td>
        <td class="py-2.5 text-gray-500">${row.topDiscrepancy}</td>
      </tr>
    `;
  }).join('');
}

function openInApplicationTracker(appId) {
  window.location.href = 'application-tracker?app=' + encodeURIComponent(appId);
}

// ============================================================
// EXPORT — dashboard snapshot to PDF / Word / Image
// ============================================================
function toggleExportMenu(e) {
  if (e) e.stopPropagation();
  document.getElementById('exportMenu').classList.toggle('hidden');
}
document.addEventListener('click', e => {
  if (!e.target.closest('#exportBtn') && !e.target.closest('#exportMenu')) {
    document.getElementById('exportMenu').classList.add('hidden');
  }
});

let toastTimer = null;
function toast(msg, isError) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.toggle('bg-red-600', !!isError);
  el.classList.toggle('bg-gray-900', !isError);
  el.style.opacity = '1';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.style.opacity = '0'; }, 2400);
}

function fileStamp() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

async function snapshotMain() {
  const main = document.querySelector('main');
  return html2canvas(main, { scale: 2, backgroundColor: '#F0F2F8', useCORS: true, logging: false });
}

async function exportDashboardPDF() {
  document.getElementById('exportMenu').classList.add('hidden');
  toast('Generating PDF…');
  try {
    const canvas = await snapshotMain();
    const imgData = canvas.toDataURL('image/png');
    const { jsPDF } = window.jspdf;
    // Use canvas dimensions to size the PDF so the snapshot fits without crop.
    const pdfW = 297, pdfH = (canvas.height * pdfW) / canvas.width;
    const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: [pdfW, pdfH] });
    pdf.addImage(imgData, 'PNG', 0, 0, pdfW, pdfH);
    pdf.save(`sukkuk-overview-${fileStamp()}.pdf`);
    toast('PDF downloaded');
  } catch (err) {
    console.error(err);
    toast('Export failed', true);
  }
}

async function exportDashboardImage() {
  document.getElementById('exportMenu').classList.add('hidden');
  toast('Generating image…');
  try {
    const canvas = await snapshotMain();
    const link = document.createElement('a');
    link.download = `sukkuk-overview-${fileStamp()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    toast('Image downloaded');
  } catch (err) {
    console.error(err);
    toast('Export failed', true);
  }
}

// Word doesn't open .docx easily without a real library; it does open HTML
// served with a .doc extension and Word MIME type. That's enough for managers
// who want to drop the dashboard into a report.
function exportDashboardDOCX() {
  document.getElementById('exportMenu').classList.add('hidden');
  const main = document.querySelector('main').outerHTML;
  const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office"
          xmlns:w="urn:schemas-microsoft-com:office:word"
          xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta charset="utf-8">
      <title>Sukkuk Management Overview</title>
      <style>
        body { font-family: Arial, sans-serif; }
        table { border-collapse: collapse; width: 100%; }
        th, td { padding: 6px; border: 1px solid #ddd; text-align: left; }
        h1, h3 { color: #1B3EC5; }
      </style>
    </head>
    <body>
      <h1>Sukkuk — Management Overview</h1>
      <p>Snapshot exported ${new Date().toLocaleString()}</p>
      ${main}
    </body>
    </html>`;
  const blob = new Blob(['﻿', html], { type: 'application/msword' });
  const link = document.createElement('a');
  link.download = `sukkuk-overview-${fileStamp()}.doc`;
  link.href = URL.createObjectURL(blob);
  link.click();
  toast('Word document downloaded');
}


// ============================================================
// CONNECTED OVERVIEW — keeps the current Overview layout/content,
// but syncs counts and recent records from the same workflow state
// used by Application Tracker and Maker
// after those pages create/update localStorage.
// ============================================================
const WORKFLOW_STORAGE_KEY = 'adib-sukkuk-workflow-v10';

function parseWorkflowApps() {
  try {
    const parsed = JSON.parse(localStorage.getItem(WORKFLOW_STORAGE_KEY));
    return Array.isArray(parsed) ? parsed : null;
  } catch (e) {
    return null;
  }
}
function normaliseStatus(status) {
  return String(status || '').toLowerCase().replace(/\s+/g, '').replace(/-/g, '');
}
function statusDisplay(status) {
  const s = normaliseStatus(status);
  return ({
    pendingassignment: 'Pending Assignment',
    pendingatmaker: 'Pending at Maker',
    withfinnone: 'With FinnOne – Checker Stage',
    waitingstatusfromfinnone: 'Waiting Status from FinnOne',
    updatingstatusfinnone: 'Updating Status in FinnOne',
    completed: 'Completed'
  })[s] || (status || '—');
}
function statusPill(status, outcome) {
  const s = normaliseStatus(status);
  const cls = ({
    pendingassignment: 'bg-purple-100 text-purple-700',
    pendingatmaker: 'bg-orange-100 text-orange-700',
    withfinnone: 'bg-blue-100 text-blue-700',
    waitingstatusfromfinnone: 'bg-amber-100 text-amber-700',
    updatingstatusfinnone: 'bg-cyan-100 text-cyan-700',
    completed: 'bg-green-100 text-green-700'
  })[s] || 'bg-gray-100 text-gray-600';
  const title = outcome ? ` title="${String(outcome).replace(/"/g, '&quot;')}"` : '';
  return `<span${title} class="${cls} px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">${statusDisplay(status)}</span>`;
}
function discrepancyPill(flags) {
  return Number(flags || 0) > 0
    ? '<span class="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">Yes</span>'
    : '<span class="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">No</span>';
}
function connectedSubmittedDate(app) {
  return app.submitted || app.createdAt || app.lastFinnOneSubmittedAt || app.completedAt || app.lastAiProcessedAt || '—';
}
function syncOverviewWithWorkflowState() {
  const apps = parseWorkflowApps();
  if (!apps || !apps.length) return;

  const total = apps.length;
  const completed = apps.filter(a => normaliseStatus(a.status) === 'completed').length;
  const accepted = apps.filter(a => normaliseStatus(a.status) === 'completed' && String(a.outcome || a.finnOneStatus || '').toLowerCase().includes('accept')).length;
  const rejected = apps.filter(a => normaliseStatus(a.status) === 'completed' && String(a.outcome || a.finnOneStatus || a.rejectionReason || '').toLowerCase().includes('reject')).length;
  const flagged = apps.filter(a => Number(a.flags || 0) > 0).length;
  const pendingAssignment = apps.filter(a => normaliseStatus(a.status) === 'pendingassignment').length;
  const pendingMaker = apps.filter(a => normaliseStatus(a.status) === 'pendingatmaker').length;
  const pendingChecker = apps.filter(a => normaliseStatus(a.status) === 'withfinnone').length;
  const waitingFinnOne = apps.filter(a => normaliseStatus(a.status) === 'waitingstatusfromfinnone').length;
  const updatingFinnOne = apps.filter(a => normaliseStatus(a.status) === 'updatingstatusfinnone').length;
  const pending = total - completed;

  KPIS.processed = total;
  KPIS.completed = completed;
  KPIS.accepted = accepted || Math.max(completed - rejected, 0);
  KPIS.rejected = rejected;
  KPIS.flagged = flagged;
  KPIS.pending = pending;
  KPIS.processedDelta = 0;
  KPIS.completedDelta = 0;
  KPIS.flaggedDelta = 0;
  KPIS.pendingDelta = 0;

  STATUS_BARS.pendingAssignment = pendingAssignment + waitingFinnOne + updatingFinnOne;
  STATUS_BARS.pendingMaker = pendingMaker;
  STATUS_BARS.pendingChecker = pendingChecker;
  STATUS_BARS.completed = completed;

  TREND_SERIES[0].points = buildFlatTrend(total);
  TREND_SERIES[1].points = buildFlatTrend(completed);
  TREND_SERIES[2].points = buildFlatTrend(flagged);
  TREND_SERIES[3].points = buildFlatTrend(pending);

  syncSubProductPerformance(apps);
  syncRejectionReasons(apps);
  syncRecentApplications(apps);
}
function buildFlatTrend(value) {
  const start = Math.max(0, Math.round(value * 0.7));
  return [0,1,2,3,4,5,6,7].map(i => Math.round(start + ((value - start) * i / 7)));
}
function syncSubProductPerformance(apps) {
  const groups = new Map();
  apps.forEach(app => {
    const label = app.subProduct || 'Standard';
    if (!groups.has(label)) groups.set(label, { label, volume: 0, completed: 0, accepted: 0, rejected: 0, flagged: 0, topDiscrepancy: 'Document discrepancy' });
    const row = groups.get(label);
    row.volume += 1;
    if (normaliseStatus(app.status) === 'completed') row.completed += 1;
    if (String(app.outcome || app.finnOneStatus || '').toLowerCase().includes('accept')) row.accepted += 1;
    if (String(app.outcome || app.finnOneStatus || app.rejectionReason || '').toLowerCase().includes('reject')) row.rejected += 1;
    if (Number(app.flags || 0) > 0) row.flagged += 1;
    if (app.rejectionReason) row.topDiscrepancy = app.rejectionReason;
  });
  SUB_PRODUCT_PERF.length = 0;
  Array.from(groups.values()).slice(0, 6).forEach(row => SUB_PRODUCT_PERF.push(row));
}
function syncRejectionReasons(apps) {
  const counts = new Map();
  apps.forEach(app => {
    const reason = app.rejectionReason || app.rfoProcessorComments || app.decisionComments;
    if (String(app.outcome || app.finnOneStatus || reason || '').toLowerCase().includes('reject')) {
      const label = reason || 'Rejected in FinnOne';
      counts.set(label, (counts.get(label) || 0) + 1);
    }
  });
  if (counts.size) {
    REJECTION_REASONS.length = 0;
    Array.from(counts.entries()).sort((a,b) => b[1] - a[1]).slice(0, 6).forEach(([label, count]) => REJECTION_REASONS.push({ label, count }));
  }
}
function syncRecentApplications(apps) {
  const body = document.getElementById('recentApplicationsBody');
  if (!body) return;
  const rows = apps.slice().sort((a, b) => String(connectedSubmittedDate(b)).localeCompare(String(connectedSubmittedDate(a)))).slice(0, 12);
  body.innerHTML = rows.map(app => `
    <tr class="border-b border-gray-50 table-row-hover cursor-pointer" onclick="openInApplicationTracker('${String(app.id || '').replace(/'/g, "\\'")}')">
      <td class="py-2.5 text-blue-600 font-medium">${app.id || '—'}</td>
      <td class="py-2.5 text-gray-800">${app.customer || '—'}</td>
      <td class="py-2.5">${statusPill(app.status, app.outcome)}</td>
      <td class="py-2.5">${discrepancyPill(app.flags)}</td>
      <td class="py-2.5 text-gray-500">${connectedSubmittedDate(app)}</td>
    </tr>`).join('');
  const totalRejected = document.getElementById('totalRejectedCount');
  if (totalRejected) totalRejected.textContent = fmtNumber(KPIS.rejected);
}

syncOverviewWithWorkflowState();

renderKpis();
renderStatusBars();
renderTrend();
renderRejectionReasons();
renderSubProductPerformance();

(function () {
  const page = (location.pathname.split('/').pop() || 'index').toLowerCase();
  const publicPages = ['login', 'index'];
  const rpaAllowed = ['application-tracker'];
  const role = localStorage.getItem('adibUserRole');
  const username = localStorage.getItem('adibUsername') || 'User';

  // if (!role && !publicPages.includes(page)) {
  //   location.href = 'login';
  //   return;
  // }

  if (role === 'rpa' && !rpaAllowed.includes(page) && !publicPages.includes(page)) {
    location.href = 'application-tracker';
    return;
  }

  function applyRoleNavigation() {
    document.querySelectorAll('nav a').forEach(function (a) {
      const href = (a.getAttribute('href') || '').split('?')[0].split('#')[0].toLowerCase();
      if (role === 'rpa' && !rpaAllowed.includes(href)) {
        a.remove();
      }
    });

    const sidebarFooter = document.querySelector('aside .mt-auto');
    if (sidebarFooter && role) {
      sidebarFooter.innerHTML = `
        <div class="w-9 h-9 bg-blue-300/40 rounded-full flex items-center justify-center">
          <i class="fas fa-user text-white/80 text-sm"></i>
        </div>
        <div class="flex flex-col min-w-0 flex-1">
          <span class="text-white text-[12px] font-medium truncate">${username}</span>
          <span class="text-blue-300 text-[10px]">${role === 'rpa' ? 'RPA User' : 'Operations User'}</span>
        </div>
        <button onclick="adibLogout()" title="Logout" class="text-blue-200 hover:text-white text-[12px]">
          <i class="fas fa-right-from-bracket"></i>
        </button>`;
    }
  }

  window.adibLogout = function () {
    localStorage.removeItem('adibUsername');
    localStorage.removeItem('adibUserRole');
    location.href = 'login';
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyRoleNavigation);
  } else {
    applyRoleNavigation();
  }
})();
}
