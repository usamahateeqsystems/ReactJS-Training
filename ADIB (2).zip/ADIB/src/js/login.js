export function login(event) {
  event.preventDefault()
  const username = event.currentTarget.username.value.trim()
  if (!username) return
  const role = username.toLowerCase() === 'rpa' ? 'rpa' : 'full'
  localStorage.setItem('adibUsername', username)
  localStorage.setItem('adibUserRole', role)
  window.location.href = role === 'rpa' ? 'overview' : 'index'
}
