export function mountApplicationTracker() {
  window["clone"] = clone;
  window["loadApplications"] = loadApplications;
  window["normalizeApp"] = normalizeApp;
  window["saveApplications"] = saveApplications;
  window["normaliseStatus"] = normaliseStatus;
  window["statusLabel"] = statusLabel;
  window["statusBadge"] = statusBadge;
  window["stageLabel"] = stageLabel;
  window["assignedToLabel"] = assignedToLabel;
  window["finnOneStatusLabel"] = finnOneStatusLabel;
  window["outcomeLabel"] = outcomeLabel;
  window["outcomeBadge"] = outcomeBadge;
  window["decisionDetails"] = decisionDetails;
  window["discrepancyBadge"] = discrepancyBadge;
  window["escapeHtml"] = escapeHtml;
  window["submittedDate"] = submittedDate;
  window["formatDateTime"] = formatDateTime;
  window["appHaystack"] = appHaystack;
  window["getTrackerApps"] = getTrackerApps;
  window["finnOneStatusControl"] = finnOneStatusControl;
  window["updateFinnOneStatus"] = updateFinnOneStatus;
  window["updateLeadAssignmentUI"] = updateLeadAssignmentUI;
  window["toggleAssignmentSelection"] = toggleAssignmentSelection;
  window["toggleSelectAllPending"] = toggleSelectAllPending;
  window["assignSelectedApplications"] = assignSelectedApplications;
  window["render"] = render;
  window["clearTrackerFilters"] = clearTrackerFilters;
  window["resetDemoState"] = resetDemoState;
  window["openReportPanel"] = openReportPanel;
  window["closeReportPanel"] = closeReportPanel;
  window["uniqueValues"] = uniqueValues;
  window["fillSelect"] = fillSelect;
  window["populateReportOptions"] = populateReportOptions;
  window["resetReportFilters"] = resetReportFilters;
  window["setAllFields"] = setAllFields;
  window["selectedStatuses"] = selectedStatuses;
  window["selectedFields"] = selectedFields;
  window["getReportApps"] = getReportApps;
  window["updateReportCount"] = updateReportCount;
  window["previewReportRows"] = previewReportRows;
  window["fieldLabel"] = fieldLabel;
  window["fieldValue"] = fieldValue;
  window["reportFilterSummary"] = reportFilterSummary;
  window["fileStamp"] = fileStamp;
  window["validateReport"] = validateReport;
  window["exportReportExcel"] = exportReportExcel;
  window["exportReportPDF"] = exportReportPDF;
  window["toast"] = toast;

const STORAGE_KEY = 'adib-sukkuk-workflow-v10';
const INITIAL_APPLICATIONS = [
  {
    "id": "SAK-2026-014452",
    "customer": "Ahmed Mohammed Al Mansoori",
    "eid": "784-1990-1234567-1",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Aisha Rahman",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-101",
    "submitted": "14 May 2026, 10:34 AM",
    "ageMin": 38,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 3,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 2,
    "lastAiProcessedAt": "2026-05-09T10:07:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014563",
    "customer": "Fatima Khaled Al Shamsi",
    "eid": "784-1988-9876543-2",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Zainab Noor",
    "branchName": "Dubai Deira Branch",
    "branchId": "BR-102",
    "submitted": "14 May 2026, 9:19 AM",
    "ageMin": 12,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-10T11:14:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014689",
    "customer": "Khalid Rashid Al Nuaimi",
    "eid": "784-1992-4567890-3",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Hassan Ali",
    "branchName": "Sharjah King Faisal Branch",
    "branchId": "BR-103",
    "submitted": "13 May 2026, 2:02 PM",
    "ageMin": 24,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-11T12:21:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014568",
    "customer": "Mariam Saeed Al Maktoum",
    "eid": "784-1995-1112223-4",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Noor Fatima",
    "branchName": "Al Ain Town Centre Branch",
    "branchId": "BR-104",
    "submitted": "13 May 2026, 01:19 PM",
    "ageMin": 65,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 1,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-12T13:28:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014576",
    "customer": "Yousef Hamad Al Falasi",
    "eid": "784-1987-3334445-5",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Sara Khan",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-105",
    "submitted": "13 May 2026, 11:47 AM",
    "ageMin": 22,
    "status": "completed",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-13T14:35:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": "2026-05-13T12:16:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014581",
    "customer": "Sara Ali Al Hashimi",
    "eid": "784-1991-5556667-6",
    "product": "Sukkuk",
    "subProduct": "PDC",
    "submittedBy": "Omar Hussain",
    "branchName": "Dubai Mall Branch",
    "branchId": "BR-106",
    "submitted": "13 May 2026, 09:12 AM",
    "ageMin": 80,
    "status": "completed",
    "outcome": "rejected",
    "flags": 4,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-14T15:42:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "sukuk-certificate",
      "security-cheque",
      "processing-fee",
      "installment-calc"
    ],
    "completedAt": "2026-05-13T10:34:00",
    "rejectionAt": "2026-05-13T10:34:00",
    "rejectionReason": "RFO Processor noted unresolved validation discrepancies across the Emirates ID, Sukuk Certificate, Security Cheque and Processing Fee Form.",
    "rfoProcessorComments": "RFO Processor noted unresolved validation discrepancies across the Emirates ID, Sukuk Certificate, Security Cheque and Processing Fee Form.",
    "decisionComments": "RFO Processor noted unresolved validation discrepancies across the Emirates ID, Sukuk Certificate, Security Cheque and Processing Fee Form.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "rejected"
  },
  {
    "id": "SAK-2026-014622",
    "customer": "Omar Khalifa Al Suwaidi",
    "eid": "784-1993-7778889-7",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Maya Joseph",
    "branchName": "Sharjah King Faisal Branch",
    "branchId": "BR-107",
    "submitted": "13 May 2026, 08:45 AM",
    "ageMin": 18,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 0,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-08T16:49:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014701",
    "customer": "Layla Mohammed Al Zaabi",
    "eid": "784-1989-2223334-8",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Bilal Ahmed",
    "branchName": "Al Ain Town Centre Branch",
    "branchId": "BR-108",
    "submitted": "12 May 2026, 03:21 PM",
    "ageMin": 28,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 2,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-09T09:56:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014728",
    "customer": "Hassan Abdullah Al Ketbi",
    "eid": "784-1986-4448891-9",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Meera Shah",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-109",
    "submitted": "12 May 2026, 01:55 PM",
    "ageMin": 41,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 1,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-10T10:03:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014744",
    "customer": "Reem Nasser Al Ameri",
    "eid": "784-1994-2221187-0",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Adeel Siddiqui",
    "branchName": "Dubai Jumeirah Branch",
    "branchId": "BR-110",
    "submitted": "12 May 2026, 12:07 PM",
    "ageMin": 19,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 0,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-11T11:10:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014759",
    "customer": "Noura Salem Al Qasimi",
    "eid": "784-1996-0099887-3",
    "product": "Sukkuk",
    "subProduct": "PDC",
    "submittedBy": "Rabia Malik",
    "branchName": "Sharjah King Faisal Branch",
    "branchId": "BR-111",
    "submitted": "12 May 2026, 10:26 AM",
    "ageMin": 54,
    "status": "completed",
    "outcome": "accepted",
    "flags": 1,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-12T12:17:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "sukuk-certificate",
      "security-cheque",
      "processing-fee",
      "installment-calc"
    ],
    "completedAt": "2026-05-12T12:05:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014803",
    "customer": "Mohammed Tariq Al Blooshi",
    "eid": "784-1985-7654321-4",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Kiran Thomas",
    "branchName": "Dubai Deira Branch",
    "branchId": "BR-112",
    "submitted": "11 May 2026, 04:42 PM",
    "ageMin": 33,
    "status": "completed",
    "outcome": "rejected",
    "flags": 3,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-13T13:24:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": "2026-05-11T17:35:00",
    "rejectionAt": "2026-05-11T17:35:00",
    "rejectionReason": "RFO Processor rejected the case because the financed amount and customer liability records did not reconcile with FinOne.",
    "rfoProcessorComments": "RFO Processor rejected the case because the financed amount and customer liability records did not reconcile with FinOne.",
    "decisionComments": "RFO Processor rejected the case because the financed amount and customer liability records did not reconcile with FinOne.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "rejected"
  },
  {
    "id": "SAK-2026-014817",
    "customer": "Huda Faisal Al Mazrouei",
    "eid": "784-1997-1029384-5",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Yasmin Ali",
    "branchName": "Ras Al Khaimah Branch",
    "branchId": "BR-113",
    "submitted": "11 May 2026, 03:38 PM",
    "ageMin": 16,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 0,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-14T14:31:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014835",
    "customer": "Saeed Ali Al Darmaki",
    "eid": "784-1991-5647382-6",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Tariq Mahmood",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-114",
    "submitted": "11 May 2026, 02:11 PM",
    "ageMin": 29,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 2,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-08T15:38:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014846",
    "customer": "Amna Khalifa Al Neyadi",
    "eid": "784-1998-9182736-7",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Dina Nabil",
    "branchName": "Fujairah Branch",
    "branchId": "BR-115",
    "submitted": "11 May 2026, 12:48 PM",
    "ageMin": 21,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 1,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-09T16:45:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014852",
    "customer": "Rashid Mubarak Al Kaabi",
    "eid": "784-1984-8273645-8",
    "product": "Sukkuk",
    "subProduct": "PDC",
    "submittedBy": "Asim Khan",
    "branchName": "Dubai Mall Branch",
    "branchId": "BR-116",
    "submitted": "11 May 2026, 11:05 AM",
    "ageMin": 73,
    "status": "completed",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-10T09:52:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "sukuk-certificate",
      "security-cheque",
      "processing-fee",
      "installment-calc"
    ],
    "completedAt": "2026-05-11T12:02:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014869",
    "customer": "Salama Hamad Al Muhairi",
    "eid": "784-1990-6677889-9",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Mona Farouk",
    "branchName": "Al Ain Town Centre Branch",
    "branchId": "BR-117",
    "submitted": "10 May 2026, 04:19 PM",
    "ageMin": 47,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-11T10:59:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014877",
    "customer": "Ali Sultan Al Shehhi",
    "eid": "784-1989-5544332-1",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Rania Habib",
    "branchName": "Ras Al Khaimah Branch",
    "branchId": "BR-118",
    "submitted": "10 May 2026, 02:30 PM",
    "ageMin": 62,
    "status": "pendingatmaker",
    "outcome": null,
    "flags": 3,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-12T11:06:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014889",
    "customer": "Mahra Saif Al Tunaiji",
    "eid": "784-1993-3344556-2",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Ibrahim Noor",
    "branchName": "Sharjah King Faisal Branch",
    "branchId": "BR-119",
    "submitted": "10 May 2026, 12:17 PM",
    "ageMin": 13,
    "status": "completed",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-13T12:13:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": "2026-05-10T13:04:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014901",
    "customer": "Abdullah Hamdan Al Marri",
    "eid": "784-1983-7788991-3",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Shazia Ahmed",
    "branchName": "Dubai Jumeirah Branch",
    "branchId": "BR-120",
    "submitted": "10 May 2026, 10:41 AM",
    "ageMin": 91,
    "status": "completed",
    "outcome": "rejected",
    "flags": 2,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-14T13:20:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": "2026-05-10T11:30:00",
    "rejectionAt": "2026-05-10T11:30:00",
    "rejectionReason": "RFO Processor comments: Debt settlement documents were incomplete and the liability closure confirmation was not available.",
    "rfoProcessorComments": "RFO Processor comments: Debt settlement documents were incomplete and the liability closure confirmation was not available.",
    "decisionComments": "RFO Processor comments: Debt settlement documents were incomplete and the liability closure confirmation was not available.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "rejected"
  },
  {
    "id": "SAK-2026-014916",
    "customer": "Latifa Rashid Al Mansouri",
    "eid": "784-1999-1212121-4",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Hina Qureshi",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-121",
    "submitted": "09 May 2026, 04:07 PM",
    "ageMin": 26,
    "status": "pendingatmaker",
    "outcome": null,
    "flags": 0,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-08T14:27:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014932",
    "customer": "Majid Saeed Al Hosani",
    "eid": "784-1988-3434343-5",
    "product": "Sukkuk",
    "subProduct": "PDC",
    "submittedBy": "Naveed Akram",
    "branchName": "Fujairah Branch",
    "branchId": "BR-122",
    "submitted": "09 May 2026, 02:54 PM",
    "ageMin": 39,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 1,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-09T15:34:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "sukuk-certificate",
      "security-cheque",
      "processing-fee",
      "installment-calc"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014948",
    "customer": "Alya Mohammed Al Falahi",
    "eid": "784-1996-5656565-6",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Sana Shah",
    "branchName": "Dubai Deira Branch",
    "branchId": "BR-123",
    "submitted": "09 May 2026, 11:32 AM",
    "ageMin": 57,
    "status": "pendingatmaker",
    "outcome": null,
    "flags": 2,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-10T16:41:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014965",
    "customer": "Hamdan Nasser Al Shamsi",
    "eid": "784-1982-7878787-7",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Fahad Saleem",
    "branchName": "Dubai Mall Branch",
    "branchId": "BR-124",
    "submitted": "08 May 2026, 03:18 PM",
    "ageMin": 31,
    "status": "completed",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-11T09:48:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": "2026-05-08T16:07:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014981",
    "customer": "Maryam Ali Al Otaiba",
    "eid": "784-1995-9090909-8",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Priya Menon",
    "branchName": "Ras Al Khaimah Branch",
    "branchId": "BR-125",
    "submitted": "08 May 2026, 12:36 PM",
    "ageMin": 44,
    "status": "pendingatmaker",
    "outcome": null,
    "flags": 1,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-12T10:55:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014997",
    "customer": "Sultan Khalifa Al Nahyan",
    "eid": "784-1981-2468246-9",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Imran Saeed",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-126",
    "submitted": "08 May 2026, 09:44 AM",
    "ageMin": 69,
    "status": "completed",
    "outcome": "rejected",
    "flags": 5,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-13T11:02:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": "2026-05-08T10:52:00",
    "rejectionAt": "2026-05-08T10:52:00",
    "rejectionReason": "RFO Processor comments: Multiple resubmissions failed automated checks; customer documentation did not reconcile with FinOne approval details.",
    "rfoProcessorComments": "RFO Processor comments: Multiple resubmissions failed automated checks; customer documentation did not reconcile with FinOne approval details.",
    "decisionComments": "RFO Processor comments: Multiple resubmissions failed automated checks; customer documentation did not reconcile with FinOne approval details.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "rejected"
  }
];
let APPLICATIONS = loadApplications();
let activeStatus = 'all';
let toastTimer = null;

function clone(value){ return JSON.parse(JSON.stringify(value)); }
function loadApplications(){
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (Array.isArray(stored) && stored.length) {
      const byId = new Map(stored.map(a => [a.id, normalizeApp(a)]));
      INITIAL_APPLICATIONS.forEach(a => { if (!byId.has(a.id)) byId.set(a.id, normalizeApp(clone(a))); });
      const merged = Array.from(byId.values());
      localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
      return merged;
    }
  } catch(e) {}
  const seeded = clone(INITIAL_APPLICATIONS).map(normalizeApp);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(seeded));
  return seeded;
}
function normalizeApp(app){
  app.status = normaliseStatus(app.status || 'pendingassignment');
  if (app.status === 'pendingatchecker' || (app.status === 'pendingassignment' && app.assignmentStage === 'checker') || ['waitingstatusfromfinnone','updatingstatusfinnone'].includes(app.status)) {
    app.status = 'withfinnone';
    app.assignmentStage = 'finnone';
    if (app.makerDecision === 'approved') app.outcome = 'accepted';
    if (app.makerDecision === 'rejected') app.outcome = 'rejected';
    app.finnOneStatus = app.finnOneStatus === 'Completed' ? 'Completed' : 'Checker Stage';
  }
  app.flags = Number(app.flags || 0);
  app.aiProcessingCount = Number(app.aiProcessingCount || 0);
  app.branchName = app.branchName || app.branchId || '—';
  if (app.status === 'pendingassignment') { app.assignmentStage = 'maker'; app.assignedMaker = null; }
  app.assignmentStage = app.assignmentStage || (app.status === 'withfinnone' ? 'finnone' : 'maker');
  app.assignedChecker = null;
  app.rfoProcessorComments = app.rfoProcessorComments || null;
  app.rfoCheckerComments = null;
  if (app.rfoProcessorComments) app.decisionComments = app.rfoProcessorComments;
  return app;
}
function saveApplications(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(APPLICATIONS)); }
function normaliseStatus(status){ return String(status || '').toLowerCase().replace(/\s+/g,'').replace(/-/g,''); }
function statusLabel(s){ return ({pendingassignment:'Pending Assignment',pendingatmaker:'Pending at Maker',withfinnone:'With FinnOne – Checker Stage',completed:'Completed'})[normaliseStatus(s)] || s || '—'; }
function statusBadge(s){
  s = normaliseStatus(s);
  const cls = ({pendingassignment:'bg-purple-100 text-purple-700',pendingatmaker:'bg-orange-100 text-orange-700',withfinnone:'bg-blue-100 text-blue-700',completed:'bg-green-100 text-green-700'})[s] || 'bg-gray-100 text-gray-600';
  return `<span class="${cls} px-2.5 py-1 rounded-full text-[10px] font-semibold whitespace-nowrap">${escapeHtml(statusLabel(s))}</span>`;
}
function stageLabel(stage){ return ({maker:'RFO Processor Review',finnone:'FinnOne Checker Stage',completed:'Completed'})[stage] || stage || '—'; }
function assignedToLabel(app){
  const s = normaliseStatus(app.status);
  if (s === 'pendingassignment') return 'RFO Lead';
  if (s === 'pendingatmaker') return app.assignedMaker || 'RFO Processor';
  if (s === 'withfinnone') return 'FinnOne';
  return '—';
}
function finnOneStatusLabel(app){ return app.finnOneStatus || '—'; }
function outcomeLabel(app){
  if (app.outcome === 'rejected') return 'Rejected';
  if (app.outcome === 'accepted') return 'Approved';
  return '—';
}
function outcomeBadge(app){
  if (app.outcome === 'rejected') return '<span class="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">Rejected</span>';
  if (app.outcome === 'accepted') return '<span class="bg-green-100 text-green-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">Approved</span>';
  return '<span class="text-gray-400">—</span>';
}
function decisionDetails(app){
  if (app.outcome === 'rejected') return app.rejectionReason || app.rfoProcessorComments || 'Rejected without a recorded reason';
  if (app.outcome === 'accepted') return app.rfoProcessorComments || app.decisionComments || 'Approved by RFO Processor';
  return app.rfoProcessorComments || '—';
}
function discrepancyBadge(app){ return app.flags > 0 ? `<span title="${app.flags} discrepancy item(s)" class="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold">Yes (${app.flags})</span>` : '<span class="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium">No</span>'; }
function escapeHtml(value){ return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c])); }
function submittedDate(app){
  if (app.submittedISO) return new Date(app.submittedISO);
  const value = app.submitted || '';
  const parsed = new Date(value.replace(/,(?=\s*\d{1,2}:)/,''));
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}
function formatDateTime(value){ if(!value) return '—'; const d=new Date(value); return Number.isNaN(d.getTime())?value:d.toLocaleString('en-GB',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:true}); }
function appHaystack(app){ return [app.id,app.customer,app.eid,app.product,app.subProduct,app.submittedBy,app.branchName,app.branchId,app.submitted,finnOneStatusLabel(app),statusLabel(app.status),assignedToLabel(app),outcomeLabel(app),app.rejectionReason,app.rfoProcessorComments].join(' ').toLowerCase(); }
function getTrackerApps(){
  const q=(document.getElementById('searchInput').value||'').trim().toLowerCase();
  return APPLICATIONS.filter(a => (activeStatus==='all'||normaliseStatus(a.status)===activeStatus) && (!q||appHaystack(a).includes(q)));
}

const selectedAssignmentIds = new Set();
const FINNONE_STATUS_OPTIONS = ['In Process','RFF Creation','Checker Stage','Approved','Rejected','Completed'];
function finnOneStatusControl(app){
  const role = localStorage.getItem('adibUserRole');
  if (role === 'rpa' || normaliseStatus(app.status) === 'completed') return `<span class="text-gray-700 whitespace-nowrap">${escapeHtml(finnOneStatusLabel(app))}</span>`;
  const options = FINNONE_STATUS_OPTIONS.map(v => `<option value="${escapeHtml(v)}" ${v===finnOneStatusLabel(app)?'selected':''}>${escapeHtml(v)}</option>`).join('');
  return `<select onclick="event.stopPropagation()" onchange="updateFinnOneStatus('${escapeHtml(app.id)}', this.value)" class="border border-gray-200 rounded-lg px-2 py-1.5 text-[10px] text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">${options}</select>`;
}
function updateFinnOneStatus(id,value){
  const app=APPLICATIONS.find(a=>a.id===id); if(!app || !FINNONE_STATUS_OPTIONS.includes(value)) return;
  app.finnOneStatus=value;
  if(value==='Completed'){
    app.status='completed'; app.assignmentStage='completed'; app.completedAt=new Date().toISOString();
    if(!app.outcome && app.makerDecision==='approved') app.outcome='accepted';
    if(!app.outcome && app.makerDecision==='rejected') app.outcome='rejected';
  } else if(app.makerDecision && !['pendingassignment','pendingatmaker'].includes(normaliseStatus(app.status))){
    app.status='withfinnone'; app.assignmentStage='finnone'; app.completedAt=null;
  }
  saveApplications(); render(); populateReportOptions(); toast(value==='Completed'?'Application marked Completed.':'FinnOne status updated.');
}
function updateLeadAssignmentUI(){
  const pending=APPLICATIONS.filter(a=>normaliseStatus(a.status)==='pendingassignment');
  const countEl=document.getElementById('pendingAssignmentCount'); if(countEl) countEl.textContent=pending.length;
  const selected=[...selectedAssignmentIds].filter(id=>pending.some(a=>a.id===id));
  [...selectedAssignmentIds].forEach(id=>{if(!selected.includes(id))selectedAssignmentIds.delete(id);});
  const selectedEl=document.getElementById('selectedAssignmentCount'); if(selectedEl) selectedEl.textContent=`${selected.length} selected`;
  const btn=document.getElementById('assignSelectedBtn'); const processor=document.getElementById('processorSelect'); if(btn) btn.disabled=selected.length===0 || !processor?.value;
  const alert=document.getElementById('leadAlert'); if(alert){alert.classList.toggle('hidden',pending.length<20); const c=document.getElementById('leadAlertCount'); if(c)c.textContent=pending.length;}
  const all=document.getElementById('selectAllPending'); if(all){const visible=getTrackerApps().filter(a=>normaliseStatus(a.status)==='pendingassignment'); all.checked=visible.length>0 && visible.every(a=>selectedAssignmentIds.has(a.id)); all.indeterminate=visible.some(a=>selectedAssignmentIds.has(a.id)) && !all.checked;}
}
function toggleAssignmentSelection(id,checked){ if(checked)selectedAssignmentIds.add(id);else selectedAssignmentIds.delete(id); updateLeadAssignmentUI(); }
function toggleSelectAllPending(checked){ getTrackerApps().filter(a=>normaliseStatus(a.status)==='pendingassignment').forEach(a=>checked?selectedAssignmentIds.add(a.id):selectedAssignmentIds.delete(a.id)); render(); }
function assignSelectedApplications(){
  const processor=document.getElementById('processorSelect').value; if(!processor){toast('Select an RFO Processor first.',true);return;}
  const ids=[...selectedAssignmentIds]; let updated=0;
  APPLICATIONS.forEach(app=>{if(ids.includes(app.id)&&normaliseStatus(app.status)==='pendingassignment'){app.assignedMaker=processor;app.status='pendingatmaker';app.assignmentStage='maker';app.assignedAt=new Date().toISOString();updated++;}});
  if(!updated){toast('Select at least one pending-assignment application.',true);return;}
  selectedAssignmentIds.clear(); saveApplications(); render(); populateReportOptions(); toast(`${updated} application${updated===1?'':'s'} assigned to ${processor}.`);
}
document.getElementById('processorSelect')?.addEventListener('change',updateLeadAssignmentUI);

function render(){
  const apps=getTrackerApps();
  document.getElementById('resultsCount').textContent=apps.length;
  const body=document.getElementById('resultsBody');
  if(!apps.length){ body.innerHTML='<tr><td colspan="14" class="py-12 text-center text-gray-500 text-[13px]">No applications match the selected filters.</td></tr>'; updateLeadAssignmentUI(); return; }
  body.innerHTML=apps.map(a=>{
    const detail=decisionDetails(a); const pending=normaliseStatus(a.status)==='pendingassignment'; const assigned=assignedToLabel(a);
    const action=normaliseStatus(a.status)==='pendingatmaker'?`<a href="maker?app=${encodeURIComponent(a.id)}" onclick="event.stopPropagation()" class="whitespace-nowrap rounded-lg border border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-700 px-2.5 py-1.5 text-[10px] font-semibold"><i class="fas fa-arrow-right mr-1"></i>Open Maker</a>`:'<span class="text-gray-400">—</span>';
    return `<tr class="border-b border-gray-50 hover:bg-gray-50 align-top">
      <td class="py-3 px-3 text-center">${pending?`<input type="checkbox" class="field-check" ${selectedAssignmentIds.has(a.id)?'checked':''} onchange="toggleAssignmentSelection('${escapeHtml(a.id)}',this.checked)">`:'<span class="text-gray-300">—</span>'}</td><td class="py-3 px-2 text-blue-600 font-medium whitespace-nowrap">${escapeHtml(a.id)}</td><td class="py-3 text-gray-800">${escapeHtml(a.customer)}</td><td class="py-3 text-gray-600">${escapeHtml(a.submittedBy||'—')}</td><td class="py-3 text-gray-600">${escapeHtml(a.branchName||a.branchId||'—')}</td><td class="py-3 text-gray-500 whitespace-nowrap">${escapeHtml(a.submitted||'—')}</td><td class="py-3">${finnOneStatusControl(a)}</td><td class="py-3">${statusBadge(a.status)}</td><td class="py-3">${discrepancyBadge(a)}</td><td class="py-3 text-gray-700 font-semibold">${a.aiProcessingCount}</td><td class="py-3 text-gray-700 font-medium whitespace-nowrap">${escapeHtml(assigned)}</td><td class="py-3">${outcomeBadge(a)}</td><td class="py-3 text-gray-600"><div class="decision-text" title="${escapeHtml(detail)}">${escapeHtml(detail)}</div></td><td class="py-3 px-5">${action}</td>
    </tr>`;
  }).join('');
  updateLeadAssignmentUI(); updateReportCount();
}
function clearTrackerFilters(){ document.getElementById('searchInput').value=''; activeStatus='all'; document.querySelectorAll('.status-pill').forEach(x=>x.classList.toggle('active',x.dataset.status==='all')); render(); }
function resetDemoState(){ localStorage.removeItem(STORAGE_KEY); APPLICATIONS=loadApplications(); selectedAssignmentIds.clear(); render(); populateReportOptions(); toast('Demo workflow state reset.'); }

document.getElementById('searchInput').addEventListener('input',render);
document.querySelectorAll('.status-pill').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.status-pill').forEach(x=>x.classList.remove('active'));b.classList.add('active');activeStatus=b.dataset.status;render();}));

const STATUS_OPTIONS=[['pendingassignment','Pending Assignment'],['pendingatmaker','Pending at Maker'],['withfinnone','With FinnOne – Checker Stage'],['completed','Completed']];
const REPORT_FIELDS=[
  ['id','Application ID',true],['customer','Customer',true],['eid','Emirates ID',true],['product','Product',false],['subProduct','Sub-Product',true],['submittedBy','Submitted By',true],['branchName','Branch Name',true],['branchId','Branch ID',false],['submitted','Submitted Date & Time',true],['finnOneStatus','FinnOne Status',true],['workflowStatus','Workflow Status',true],['discrepancy','Discrepancy',true],['aiRuns','AI Processing Count',false],['assignedTo','Assigned To',true],['assignedMaker','Assigned RFO Processor',false],['outcome','Maker Decision',true],['processorComments','RFO Processor Comments',true],['rejectionReason','Rejection Reason',true],['completedAt','Completed Date & Time',true]
];
function openReportPanel(){ populateReportOptions(); document.getElementById('reportOverlay').classList.add('open'); document.getElementById('reportPanel').classList.add('open'); updateReportCount(); }
function closeReportPanel(){ document.getElementById('reportOverlay').classList.remove('open'); document.getElementById('reportPanel').classList.remove('open'); }
function uniqueValues(key, transform){ return [...new Set(APPLICATIONS.map(a=>transform?transform(a):(a[key]||'')).filter(Boolean))].sort((a,b)=>String(a).localeCompare(String(b))); }
function fillSelect(id, values, first){ const el=document.getElementById(id), current=el.value; el.innerHTML=`<option value="all">${first}</option>`+values.map(v=>`<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join(''); if([...el.options].some(o=>o.value===current))el.value=current; }
function populateReportOptions(){
  if(!document.getElementById('reportStatusChecks').children.length){ document.getElementById('reportStatusChecks').innerHTML=STATUS_OPTIONS.map(([v,l])=>`<label class="flex items-center gap-2 text-[11px] text-gray-700"><input class="report-status field-check" type="checkbox" value="${v}" checked>${l}</label>`).join(''); }
  if(!document.getElementById('reportFieldChecks').children.length){ document.getElementById('reportFieldChecks').innerHTML=REPORT_FIELDS.map(([v,l,checked])=>`<label class="flex items-start gap-2 text-[10px] text-gray-700 leading-4"><input class="report-field field-check mt-0.5" type="checkbox" value="${v}" ${checked?'checked':''}>${l}</label>`).join(''); }
  fillSelect('reportSubProduct',uniqueValues('subProduct'),'All sub-products');
  fillSelect('reportBranch',uniqueValues('branchName',a=>a.branchName||a.branchId),'All branches');
  fillSelect('reportSubmittedBy',uniqueValues('submittedBy'),'All submitters');
  fillSelect('reportFinnOne',uniqueValues('finnOneStatus',finnOneStatusLabel),'All FinnOne statuses');
  document.querySelectorAll('#reportPanel input,#reportPanel select').forEach(el=>{ if(!el.dataset.bound){el.addEventListener('change',updateReportCount);el.dataset.bound='1';} });
}
function resetReportFilters(){
  document.querySelector('input[name="reportScope"][value="all"]').checked=true;
  document.querySelectorAll('.report-status').forEach(x=>x.checked=true);
  ['reportOutcome','reportDiscrepancy','reportSubProduct','reportBranch','reportSubmittedBy','reportFinnOne'].forEach(id=>document.getElementById(id).value='all');
  document.getElementById('reportDateFrom').value=''; document.getElementById('reportDateTo').value=''; updateReportCount();
}
function setAllFields(value){ document.querySelectorAll('.report-field').forEach(x=>x.checked=value); }
function selectedStatuses(){ return [...document.querySelectorAll('.report-status:checked')].map(x=>x.value); }
function selectedFields(){ return [...document.querySelectorAll('.report-field:checked')].map(x=>x.value); }
function getReportApps(){
  const scope=document.querySelector('input[name="reportScope"]:checked')?.value||'all';
  let apps=scope==='current'?getTrackerApps().slice():APPLICATIONS.slice();
  const statuses=selectedStatuses(); if(statuses.length) apps=apps.filter(a=>statuses.includes(normaliseStatus(a.status))); else apps=[];
  const outcome=document.getElementById('reportOutcome').value; if(outcome!=='all') apps=apps.filter(a=>outcome==='pending'?!a.outcome:a.outcome===outcome);
  const disc=document.getElementById('reportDiscrepancy').value; if(disc!=='all') apps=apps.filter(a=>disc==='yes'?a.flags>0:a.flags===0);
  const filters=[['reportSubProduct',a=>a.subProduct||''],['reportBranch',a=>a.branchName||a.branchId||''],['reportSubmittedBy',a=>a.submittedBy||''],['reportFinnOne',a=>finnOneStatusLabel(a)]];
  filters.forEach(([id,getter])=>{const value=document.getElementById(id).value;if(value!=='all')apps=apps.filter(a=>getter(a)===value);});
  const from=document.getElementById('reportDateFrom').value,to=document.getElementById('reportDateTo').value;
  if(from){const d=new Date(from+'T00:00:00');apps=apps.filter(a=>{const x=submittedDate(a);return x&&x>=d;});}
  if(to){const d=new Date(to+'T23:59:59');apps=apps.filter(a=>{const x=submittedDate(a);return x&&x<=d;});}
  return apps;
}
function updateReportCount(){ const el=document.getElementById('reportCount'); if(el)el.textContent=getReportApps().length; }
function previewReportRows(){ updateReportCount(); toast(`${getReportApps().length} applications match the report filters.`); }
function fieldLabel(key){ return REPORT_FIELDS.find(x=>x[0]===key)?.[1]||key; }
function fieldValue(app,key){
  const map={id:app.id,customer:app.customer,eid:app.eid,product:app.product,subProduct:app.subProduct,submittedBy:app.submittedBy,branchName:app.branchName||app.branchId,branchId:app.branchId,submitted:app.submitted,finnOneStatus:finnOneStatusLabel(app),workflowStatus:statusLabel(app.status),discrepancy:app.flags>0?`Yes (${app.flags})`:'No',aiRuns:app.aiProcessingCount,assignedTo:assignedToLabel(app),assignedMaker:app.assignedMaker||'—',outcome:outcomeLabel(app),processorComments:app.rfoProcessorComments||'—',rejectionReason:app.outcome==='rejected'?(app.rejectionReason||app.rfoProcessorComments||'—'):'—',completedAt:formatDateTime(app.completedAt)};
  return map[key]??'—';
}
function reportFilterSummary(){
  const parts=[]; const checked=selectedStatuses(); if(checked.length!==STATUS_OPTIONS.length)parts.push('Statuses: '+checked.map(statusLabel).join(', '));
  const outcome=document.getElementById('reportOutcome').value;if(outcome!=='all')parts.push('Outcome: '+outcome);
  const disc=document.getElementById('reportDiscrepancy').value;if(disc!=='all')parts.push('Discrepancy: '+disc);
  [['reportSubProduct','Sub-product'],['reportBranch','Branch'],['reportSubmittedBy','Submitted by'],['reportFinnOne','FinnOne']].forEach(([id,l])=>{const v=document.getElementById(id).value;if(v!=='all')parts.push(`${l}: ${v}`);});
  const from=document.getElementById('reportDateFrom').value,to=document.getElementById('reportDateTo').value;if(from||to)parts.push(`Submitted: ${from||'start'} to ${to||'today'}`);
  return parts.length?parts.join(' · '):'All applications';
}
function fileStamp(){return new Date().toISOString().replace(/[:T]/g,'-').slice(0,16);}
function validateReport(){ const apps=getReportApps(),fields=selectedFields(); if(!apps.length){toast('No applications match the report filters.',true);return null;} if(!fields.length){toast('Select at least one report field.',true);return null;} return {apps,fields}; }
function exportReportExcel(){
  const data=validateReport();if(!data)return; const rows=data.apps.map(a=>Object.fromEntries(data.fields.map(k=>[fieldLabel(k),fieldValue(a,k)])));
  const ws=XLSX.utils.json_to_sheet(rows); ws['!cols']=data.fields.map(k=>({wch:Math.min(Math.max(fieldLabel(k).length+2, k.includes('Comments')||k==='rejectionReason'?42:16),55)}));
  const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,'Applications');
  const summary=XLSX.utils.aoa_to_sheet([['Sukkuk Application Report'],['Generated',new Date().toLocaleString()],['Application Count',data.apps.length],['Filters',reportFilterSummary()]]); XLSX.utils.book_append_sheet(wb,summary,'Report Summary');
  XLSX.writeFile(wb,`sukkuk-application-report-${fileStamp()}.xlsx`); toast(`Exported ${data.apps.length} applications to Excel.`);
}
function exportReportPDF(){
  const data=validateReport();if(!data)return; const {jsPDF}=window.jspdf; const format=data.fields.length>11?'a3':'a4'; const pdf=new jsPDF({orientation:'landscape',unit:'mm',format});
  pdf.setFontSize(15);pdf.setTextColor(27,62,197);pdf.text('Sukkuk — Application Report',14,16);pdf.setFontSize(8.5);pdf.setTextColor(90);pdf.text(`${data.apps.length} applications · Generated ${new Date().toLocaleString()}`,14,22);pdf.text(pdf.splitTextToSize(reportFilterSummary(),format==='a3'?380:265),14,27);
  pdf.autoTable({startY:35,head:[data.fields.map(fieldLabel)],body:data.apps.map(a=>data.fields.map(k=>String(fieldValue(a,k)))),headStyles:{fillColor:[41,82,232],textColor:255,fontSize:data.fields.length>11?6.5:7.5},bodyStyles:{fontSize:data.fields.length>11?6.2:7.2,valign:'top'},alternateRowStyles:{fillColor:[248,250,255]},styles:{overflow:'linebreak',cellPadding:1.5},margin:{left:10,right:10}});
  pdf.save(`sukkuk-application-report-${fileStamp()}.pdf`);toast(`Exported ${data.apps.length} applications to PDF.`);
}
function toast(message,error=false){const el=document.getElementById('toast');el.textContent=message;el.className=`fixed bottom-6 left-1/2 -translate-x-1/2 ${error?'bg-red-700':'bg-gray-900'} text-white px-5 py-3 rounded-lg shadow-lg text-[13px] z-[100] transition-opacity duration-200 toast-show`;clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('toast-show'),2600);}

document.addEventListener('keydown',e=>{if(e.key==='Escape')closeReportPanel();});
populateReportOptions();render();

(function () {
  const page = (location.pathname.split('/').pop() || 'index').toLowerCase();
  const publicPages = ['login', 'index'];
  const rpaAllowed = ['application-tracker'];
  const role = localStorage.getItem('adibUserRole');
  const username = localStorage.getItem('adibUsername') || 'User';
  //if (!role && !publicPages.includes(page)) { location.href = 'login'; return; }
  if (role === 'rpa' && !rpaAllowed.includes(page) && !publicPages.includes(page)) { location.href = 'application-tracker'; return; }
  function applyRoleNavigation() {
    document.querySelectorAll('nav a').forEach(function (a) { const href = (a.getAttribute('href') || '').split('?')[0].split('#')[0].toLowerCase(); if (role === 'rpa' && !rpaAllowed.includes(href)) a.remove(); });
    const sidebarFooter = document.querySelector('aside .mt-auto');
    if (sidebarFooter && role) sidebarFooter.innerHTML = `<div class="w-9 h-9 bg-blue-300/40 rounded-full flex items-center justify-center"><i class="fas fa-user text-white/80 text-sm"></i></div><div class="flex flex-col min-w-0 flex-1"><span class="text-white text-[12px] font-medium truncate">${escapeHtml(username)}</span><span class="text-blue-300 text-[10px]">${role === 'rpa' ? 'Integration User' : 'RFO Operations'}</span></div><button onclick="adibLogout()" title="Logout" class="text-blue-200 hover:text-white text-[12px]"><i class="fas fa-right-from-bracket"></i></button>`;
  }
  window.adibLogout=function(){localStorage.removeItem('adibUsername');localStorage.removeItem('adibUserRole');location.href='login';};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',applyRoleNavigation);else applyRoleNavigation();
})();
}
