export function redirectCheckerToTracker() {
  window.location.replace('application-tracker?phase1=checker-in-finnone')
}
