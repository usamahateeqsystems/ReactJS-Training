export function mountMaker() {
  window["loadApplications"] = loadApplications;
  window["saveApplications"] = saveApplications;
  window["resetDemoState"] = resetDemoState;
  window["getConfiguredFlaggedDocKeys"] = getConfiguredFlaggedDocKeys;
  window["getEffectiveValidations"] = getEffectiveValidations;
  window["getDocState"] = getDocState;
  window["getFilteredApps"] = getFilteredApps;
  window["workflowStatusLabel"] = workflowStatusLabel;
  window["completionOutcomeLabel"] = completionOutcomeLabel;
  window["formatDateTime"] = formatDateTime;
  window["completionDateTimeLabel"] = completionDateTimeLabel;
  window["rejectionReasonLabel"] = rejectionReasonLabel;
  window["branchDisplayName"] = branchDisplayName;
  window["finnOneStatusLabel"] = finnOneStatusLabel;
  window["aiProcessingCountLabel"] = aiProcessingCountLabel;
  window["rejectionDateTimeLabel"] = rejectionDateTimeLabel;
  window["rfoProcessorCommentsLabel"] = rfoProcessorCommentsLabel;
  window["rfoCheckerCommentsLabel"] = rfoCheckerCommentsLabel;
  window["flaggedBadgeHtml"] = flaggedBadgeHtml;
  window["statusBadgeHtml"] = statusBadgeHtml;
  window["renderResults"] = renderResults;
  window["updateStatusCounts"] = updateStatusCounts;
  window["clearFilters"] = clearFilters;
  window["openDetailPanel"] = openDetailPanel;
  window["closeDetailPanel"] = closeDetailPanel;
  window["statusLabel"] = statusLabel;
  window["renderDecisionCard"] = renderDecisionCard;
  window["docCardHtml"] = docCardHtml;
  window["renderDocList"] = renderDocList;
  window["openDocModal"] = openDocModal;
  window["closeDocModal"] = closeDocModal;
  window["aiRejectionDraft"] = aiRejectionDraft;
  window["showOverallApproveModal"] = showOverallApproveModal;
  window["closeOverallApproveModal"] = closeOverallApproveModal;
  window["confirmOverallApprove"] = confirmOverallApprove;
  window["showOverallRejectModal"] = showOverallRejectModal;
  window["closeOverallRejectModal"] = closeOverallRejectModal;
  window["confirmOverallReject"] = confirmOverallReject;
  window["renderViewer"] = renderViewer;
  window["viewerZoom"] = viewerZoom;
  window["viewerResetZoom"] = viewerResetZoom;
  window["applyViewerZoom"] = applyViewerZoom;
  window["viewerToggleFullscreen"] = viewerToggleFullscreen;
  window["viewerDownload"] = viewerDownload;
  window["toast"] = toast;
  window["toggleExportMenu"] = toggleExportMenu;
  window["fileStamp"] = fileStamp;
  window["exportContext"] = exportContext;
  window["exportResultsPDF"] = exportResultsPDF;
  window["exportResultsExcel"] = exportResultsExcel;

// ============================================================
// MOCK DATA
// ============================================================
// Scope: Sukkuk only (per Excel, ~75-80% of all PF volume).
// Sub-products: Standard, Top-Up / Consolidation, Debt Settlement, PDC.
const SCREEN_MODE = 'maker';
const STORAGE_KEY = 'adib-sukkuk-workflow-v10';
const INITIAL_APPLICATIONS = [
  {
    "id": "SAK-2026-014452",
    "customer": "Ahmed Mohammed Al Mansoori",
    "eid": "784-1990-1234567-1",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Aisha Rahman",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-101",
    "submitted": "14 May 2026, 10:34 AM",
    "ageMin": 38,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 3,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 2,
    "lastAiProcessedAt": "2026-05-09T10:07:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014563",
    "customer": "Fatima Khaled Al Shamsi",
    "eid": "784-1988-9876543-2",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Zainab Noor",
    "branchName": "Dubai Deira Branch",
    "branchId": "BR-102",
    "submitted": "14 May 2026, 9:19 AM",
    "ageMin": 12,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-10T11:14:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014689",
    "customer": "Khalid Rashid Al Nuaimi",
    "eid": "784-1992-4567890-3",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Hassan Ali",
    "branchName": "Sharjah King Faisal Branch",
    "branchId": "BR-103",
    "submitted": "13 May 2026, 2:02 PM",
    "ageMin": 24,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-11T12:21:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014568",
    "customer": "Mariam Saeed Al Maktoum",
    "eid": "784-1995-1112223-4",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Noor Fatima",
    "branchName": "Al Ain Town Centre Branch",
    "branchId": "BR-104",
    "submitted": "13 May 2026, 01:19 PM",
    "ageMin": 65,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 1,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-12T13:28:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014576",
    "customer": "Yousef Hamad Al Falasi",
    "eid": "784-1987-3334445-5",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Sara Khan",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-105",
    "submitted": "13 May 2026, 11:47 AM",
    "ageMin": 22,
    "status": "completed",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-13T14:35:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": "2026-05-13T12:16:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014581",
    "customer": "Sara Ali Al Hashimi",
    "eid": "784-1991-5556667-6",
    "product": "Sukkuk",
    "subProduct": "PDC",
    "submittedBy": "Omar Hussain",
    "branchName": "Dubai Mall Branch",
    "branchId": "BR-106",
    "submitted": "13 May 2026, 09:12 AM",
    "ageMin": 80,
    "status": "completed",
    "outcome": "rejected",
    "flags": 4,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-14T15:42:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "sukuk-certificate",
      "security-cheque",
      "processing-fee",
      "installment-calc"
    ],
    "completedAt": "2026-05-13T10:34:00",
    "rejectionAt": "2026-05-13T10:34:00",
    "rejectionReason": "RFO Processor noted unresolved validation discrepancies across the Emirates ID, Sukuk Certificate, Security Cheque and Processing Fee Form.",
    "rfoProcessorComments": "RFO Processor noted unresolved validation discrepancies across the Emirates ID, Sukuk Certificate, Security Cheque and Processing Fee Form.",
    "decisionComments": "RFO Processor noted unresolved validation discrepancies across the Emirates ID, Sukuk Certificate, Security Cheque and Processing Fee Form.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "rejected"
  },
  {
    "id": "SAK-2026-014622",
    "customer": "Omar Khalifa Al Suwaidi",
    "eid": "784-1993-7778889-7",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Maya Joseph",
    "branchName": "Sharjah King Faisal Branch",
    "branchId": "BR-107",
    "submitted": "13 May 2026, 08:45 AM",
    "ageMin": 18,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 0,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-08T16:49:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014701",
    "customer": "Layla Mohammed Al Zaabi",
    "eid": "784-1989-2223334-8",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Bilal Ahmed",
    "branchName": "Al Ain Town Centre Branch",
    "branchId": "BR-108",
    "submitted": "12 May 2026, 03:21 PM",
    "ageMin": 28,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 2,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-09T09:56:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014728",
    "customer": "Hassan Abdullah Al Ketbi",
    "eid": "784-1986-4448891-9",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Meera Shah",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-109",
    "submitted": "12 May 2026, 01:55 PM",
    "ageMin": 41,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 1,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-10T10:03:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014744",
    "customer": "Reem Nasser Al Ameri",
    "eid": "784-1994-2221187-0",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Adeel Siddiqui",
    "branchName": "Dubai Jumeirah Branch",
    "branchId": "BR-110",
    "submitted": "12 May 2026, 12:07 PM",
    "ageMin": 19,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 0,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-11T11:10:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014759",
    "customer": "Noura Salem Al Qasimi",
    "eid": "784-1996-0099887-3",
    "product": "Sukkuk",
    "subProduct": "PDC",
    "submittedBy": "Rabia Malik",
    "branchName": "Sharjah King Faisal Branch",
    "branchId": "BR-111",
    "submitted": "12 May 2026, 10:26 AM",
    "ageMin": 54,
    "status": "completed",
    "outcome": "accepted",
    "flags": 1,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-12T12:17:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "sukuk-certificate",
      "security-cheque",
      "processing-fee",
      "installment-calc"
    ],
    "completedAt": "2026-05-12T12:05:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014803",
    "customer": "Mohammed Tariq Al Blooshi",
    "eid": "784-1985-7654321-4",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Kiran Thomas",
    "branchName": "Dubai Deira Branch",
    "branchId": "BR-112",
    "submitted": "11 May 2026, 04:42 PM",
    "ageMin": 33,
    "status": "completed",
    "outcome": "rejected",
    "flags": 3,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-13T13:24:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": "2026-05-11T17:35:00",
    "rejectionAt": "2026-05-11T17:35:00",
    "rejectionReason": "RFO Processor rejected the case because the financed amount and customer liability records did not reconcile with FinOne.",
    "rfoProcessorComments": "RFO Processor rejected the case because the financed amount and customer liability records did not reconcile with FinOne.",
    "decisionComments": "RFO Processor rejected the case because the financed amount and customer liability records did not reconcile with FinOne.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "rejected"
  },
  {
    "id": "SAK-2026-014817",
    "customer": "Huda Faisal Al Mazrouei",
    "eid": "784-1997-1029384-5",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Yasmin Ali",
    "branchName": "Ras Al Khaimah Branch",
    "branchId": "BR-113",
    "submitted": "11 May 2026, 03:38 PM",
    "ageMin": 16,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 0,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-14T14:31:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014835",
    "customer": "Saeed Ali Al Darmaki",
    "eid": "784-1991-5647382-6",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Tariq Mahmood",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-114",
    "submitted": "11 May 2026, 02:11 PM",
    "ageMin": 29,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 2,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-08T15:38:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014846",
    "customer": "Amna Khalifa Al Neyadi",
    "eid": "784-1998-9182736-7",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Dina Nabil",
    "branchName": "Fujairah Branch",
    "branchId": "BR-115",
    "submitted": "11 May 2026, 12:48 PM",
    "ageMin": 21,
    "status": "pendingassignment",
    "outcome": null,
    "flags": 1,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-09T16:45:00",
    "assignedMaker": null,
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014852",
    "customer": "Rashid Mubarak Al Kaabi",
    "eid": "784-1984-8273645-8",
    "product": "Sukkuk",
    "subProduct": "PDC",
    "submittedBy": "Asim Khan",
    "branchName": "Dubai Mall Branch",
    "branchId": "BR-116",
    "submitted": "11 May 2026, 11:05 AM",
    "ageMin": 73,
    "status": "completed",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-10T09:52:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "sukuk-certificate",
      "security-cheque",
      "processing-fee",
      "installment-calc"
    ],
    "completedAt": "2026-05-11T12:02:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014869",
    "customer": "Salama Hamad Al Muhairi",
    "eid": "784-1990-6677889-9",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Mona Farouk",
    "branchName": "Al Ain Town Centre Branch",
    "branchId": "BR-117",
    "submitted": "10 May 2026, 04:19 PM",
    "ageMin": 47,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-11T10:59:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014877",
    "customer": "Ali Sultan Al Shehhi",
    "eid": "784-1989-5544332-1",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Rania Habib",
    "branchName": "Ras Al Khaimah Branch",
    "branchId": "BR-118",
    "submitted": "10 May 2026, 02:30 PM",
    "ageMin": 62,
    "status": "pendingatmaker",
    "outcome": null,
    "flags": 3,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-12T11:06:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014889",
    "customer": "Mahra Saif Al Tunaiji",
    "eid": "784-1993-3344556-2",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Ibrahim Noor",
    "branchName": "Sharjah King Faisal Branch",
    "branchId": "BR-119",
    "submitted": "10 May 2026, 12:17 PM",
    "ageMin": 13,
    "status": "completed",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-13T12:13:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": "2026-05-10T13:04:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014901",
    "customer": "Abdullah Hamdan Al Marri",
    "eid": "784-1983-7788991-3",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Shazia Ahmed",
    "branchName": "Dubai Jumeirah Branch",
    "branchId": "BR-120",
    "submitted": "10 May 2026, 10:41 AM",
    "ageMin": 91,
    "status": "completed",
    "outcome": "rejected",
    "flags": 2,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-14T13:20:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": "2026-05-10T11:30:00",
    "rejectionAt": "2026-05-10T11:30:00",
    "rejectionReason": "RFO Processor comments: Debt settlement documents were incomplete and the liability closure confirmation was not available.",
    "rfoProcessorComments": "RFO Processor comments: Debt settlement documents were incomplete and the liability closure confirmation was not available.",
    "decisionComments": "RFO Processor comments: Debt settlement documents were incomplete and the liability closure confirmation was not available.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "rejected"
  },
  {
    "id": "SAK-2026-014916",
    "customer": "Latifa Rashid Al Mansouri",
    "eid": "784-1999-1212121-4",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Hina Qureshi",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-121",
    "submitted": "09 May 2026, 04:07 PM",
    "ageMin": 26,
    "status": "pendingatmaker",
    "outcome": null,
    "flags": 0,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-08T14:27:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014932",
    "customer": "Majid Saeed Al Hosani",
    "eid": "784-1988-3434343-5",
    "product": "Sukkuk",
    "subProduct": "PDC",
    "submittedBy": "Naveed Akram",
    "branchName": "Fujairah Branch",
    "branchId": "BR-122",
    "submitted": "09 May 2026, 02:54 PM",
    "ageMin": 39,
    "status": "withfinnone",
    "outcome": "accepted",
    "flags": 1,
    "finnOneStatus": "Checker Stage",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-09T15:34:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "sukuk-certificate",
      "security-cheque",
      "processing-fee",
      "installment-calc"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "finnone",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014948",
    "customer": "Alya Mohammed Al Falahi",
    "eid": "784-1996-5656565-6",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Sana Shah",
    "branchName": "Dubai Deira Branch",
    "branchId": "BR-123",
    "submitted": "09 May 2026, 11:32 AM",
    "ageMin": 57,
    "status": "pendingatmaker",
    "outcome": null,
    "flags": 2,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-10T16:41:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "salary-certificate",
      "affordability",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014965",
    "customer": "Hamdan Nasser Al Shamsi",
    "eid": "784-1982-7878787-7",
    "product": "Sukkuk",
    "subProduct": "Standard",
    "submittedBy": "Fahad Saleem",
    "branchName": "Dubai Mall Branch",
    "branchId": "BR-124",
    "submitted": "08 May 2026, 03:18 PM",
    "ageMin": 31,
    "status": "completed",
    "outcome": "accepted",
    "flags": 0,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-11T09:48:00",
    "assignedMaker": "Mariam Khalid",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": "2026-05-08T16:07:00",
    "rejectionAt": null,
    "rejectionReason": null,
    "rfoProcessorComments": "RFO Processor approved and sent the case to Checker.",
    "decisionComments": "RFO Processor approved and sent the case to Checker.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "approved"
  },
  {
    "id": "SAK-2026-014981",
    "customer": "Maryam Ali Al Otaiba",
    "eid": "784-1995-9090909-8",
    "product": "Sukkuk",
    "subProduct": "Debt Settlement",
    "submittedBy": "Priya Menon",
    "branchName": "Ras Al Khaimah Branch",
    "branchId": "BR-125",
    "submitted": "08 May 2026, 12:36 PM",
    "ageMin": 44,
    "status": "pendingatmaker",
    "outcome": null,
    "flags": 1,
    "finnOneStatus": "In Process",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-12T10:55:00",
    "assignedMaker": "Faisal Qureshi",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "passport",
      "bank-statement",
      "sukuk-certificate",
      "offer-letter"
    ],
    "completedAt": null,
    "rejectionAt": null,
    "rejectionReason": null,
    "decisionComments": null,
    "rfoProcessorComments": null,
    "rfoCheckerComments": null,
    "assignmentStage": "maker",
    "makerDecision": null
  },
  {
    "id": "SAK-2026-014997",
    "customer": "Sultan Khalifa Al Nahyan",
    "eid": "784-1981-2468246-9",
    "product": "Sukkuk",
    "subProduct": "Top-Up",
    "submittedBy": "Imran Saeed",
    "branchName": "Abu Dhabi Main Branch",
    "branchId": "BR-126",
    "submitted": "08 May 2026, 09:44 AM",
    "ageMin": 69,
    "status": "completed",
    "outcome": "rejected",
    "flags": 5,
    "finnOneStatus": "Completed",
    "aiProcessingCount": 1,
    "lastAiProcessedAt": "2026-05-13T11:02:00",
    "assignedMaker": "Aisha Rahman",
    "assignedChecker": null,
    "documents": [
      "murabaha-request",
      "emirates-id",
      "eid-validation",
      "passport",
      "salary-certificate",
      "key-fact",
      "affordability",
      "sukuk-certificate",
      "murabaha-contract",
      "offer-letter",
      "security-cheque",
      "installment-calc",
      "processing-fee"
    ],
    "completedAt": "2026-05-08T10:52:00",
    "rejectionAt": "2026-05-08T10:52:00",
    "rejectionReason": "RFO Processor comments: Multiple resubmissions failed automated checks; customer documentation did not reconcile with FinOne approval details.",
    "rfoProcessorComments": "RFO Processor comments: Multiple resubmissions failed automated checks; customer documentation did not reconcile with FinOne approval details.",
    "decisionComments": "RFO Processor comments: Multiple resubmissions failed automated checks; customer documentation did not reconcile with FinOne approval details.",
    "rfoCheckerComments": null,
    "assignmentStage": "completed",
    "makerDecision": "rejected"
  }
];

function loadApplications() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (Array.isArray(stored) && stored.length) return stored;
  } catch (e) {}
  return JSON.parse(JSON.stringify(INITIAL_APPLICATIONS));
}

function saveApplications() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(APPLICATIONS));
}

function resetDemoState() {
  APPLICATIONS = JSON.parse(JSON.stringify(INITIAL_APPLICATIONS));
  saveApplications();
  closeDetailPanel();
  renderResults();
  toast('Demo workflow state reset.');
}

let APPLICATIONS = loadApplications();

// Document type config (validation rules from "Additional Clarity" sheet).
// previewFormat: 'pdf' | 'image' — decides which viewer surface is shown.
// previewUrl: if present, the actual file. Without one, a styled placeholder
// is shown but fullscreen + zoom still work for demo purposes.
const DOC_TYPES = {
  'murabaha-request': { title: 'Murabaha Request Form', icon: 'fa-file-alt', previewFormat: 'pdf', fileName: 'murabaha-request-form.pdf' },
  'emirates-id': { title: 'Emirates ID', icon: 'fa-id-card', previewFormat: 'image', previewUrl: 'emirates-id-sample.png', fileName: 'emirates-id-front.png' },
  'eid-validation': { title: 'Emirates ID Validation Report', icon: 'fa-shield-alt', previewFormat: 'pdf', fileName: 'eid-validation-report.pdf' },
  'passport': { title: 'Passport', icon: 'fa-passport', previewFormat: 'pdf', fileName: 'passport-scan.pdf' },
  'salary-certificate': { title: 'Salary Certificate / Income Proof', icon: 'fa-file-invoice', previewFormat: 'pdf', fileName: 'salary-certificate.pdf' },
  'key-fact': { title: 'Key Fact Statement', icon: 'fa-file-contract', previewFormat: 'pdf', fileName: 'key-fact-statement.pdf' },
  'affordability': { title: 'Affordability Assessment', icon: 'fa-calculator', previewFormat: 'pdf', fileName: 'affordability-assessment.pdf' },
  'sukuk-certificate': { title: 'Sukuk Certificate (FinOne)', icon: 'fa-certificate', previewFormat: 'pdf', fileName: 'sukuk-certificate-finone.pdf' },
  'murabaha-contract': { title: 'Murabaha Contract', icon: 'fa-file-signature', previewFormat: 'pdf', fileName: 'murabaha-contract.pdf' },
  'offer-letter': { title: 'Personal Finance Offer Letter', icon: 'fa-envelope-open-text', previewFormat: 'pdf', fileName: 'pf-offer-letter.pdf' },
  'security-cheque': { title: 'Security Cheque', icon: 'fa-money-check', previewFormat: 'image', fileName: 'security-cheque.jpg' },
  'installment-calc': { title: 'Installment Cheque Calculation', icon: 'fa-table', previewFormat: 'pdf', fileName: 'installment-cheque-calc.xlsx' },
  'processing-fee': { title: 'Processing Fee Form', icon: 'fa-file-invoice-dollar', previewFormat: 'pdf', fileName: 'processing-fee-form.pdf' },
  'bank-statement': { title: 'Bank Statement', icon: 'fa-university', previewFormat: 'pdf', fileName: 'bank-statement.pdf' }
};

// Per-doc validation rules (from "Additional Clarity" sheet)
const DOC_VALIDATIONS = {
  'murabaha-request': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '96%' },
    { label: 'Requested amount populated', status: 'pass', match: '100', value: 'AED 250,000' },
    { label: 'Customer signature present', status: 'pass' },
    { label: 'Application exists in FinOne', status: 'pass' }
  ],
  'emirates-id': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '98%' },
    { label: 'Not expired', status: 'pass', value: 'Expires 14/05/2030' },
    { label: '“True Copy” stamp present', status: 'fail', match: '0' }
  ],
  'eid-validation': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '97%' },
    { label: 'Belongs to same Emirates ID number', status: 'pass', match: '100' },
    { label: 'ID number consistency with Emirates ID copy', status: 'pass', match: '100' }
  ],
  'passport': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '95%' },
    { label: 'Passport not expired', status: 'pass', value: 'Expires 22/08/2029' },
    { label: '“True Copy” stamp present', status: 'pass' }
  ],
  'salary-certificate': [
    { label: 'Document available (if required)', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '93%' },
    { label: 'Salary / income extracted', status: 'pass', value: 'AED 32,500 / month' }
  ],
  'key-fact': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '94%' },
    { label: 'Customer signature present', status: 'pass' }
  ],
  'affordability': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '95%' },
    { label: 'Customer signature present', status: 'pass' }
  ],
  'sukuk-certificate': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '96%' },
    { label: 'Financed amount = FinOne approved amount', status: 'fail', match: '0', value: 'AED 248,000 vs AED 250,000' }
  ],
  'murabaha-contract': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '95%' },
    { label: 'Financed amount = FinOne approved', status: 'pass', match: '100', value: 'AED 250,000' },
    { label: 'Profit amount = FinOne profit', status: 'pass', match: '100', value: 'AED 37,200' },
    { label: 'Print date = Customer signed date', status: 'pass' }
  ],
  'offer-letter': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '92%' },
    { label: 'Customer signature present', status: 'pass' }
  ],
  'security-cheque': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '88%' },
    { label: 'Signature present on cheque', status: 'warn' },
    { label: 'Cheque amount matches Installment Calc', status: 'pass', match: '100', value: 'AED 12,400' },
    { label: 'Cheque date matches Installment Calc', status: 'pass', match: '100' }
  ],
  'installment-calc': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '95%' },
    { label: 'Customer account number valid', status: 'pass', match: '100', value: '011-23456789-001' },
    { label: 'Installment dates match FinOne schedule', status: 'pass', match: '100' },
    { label: 'Installment amounts match Security Cheques', status: 'pass', match: '100' },
    { label: 'Account number consistent across documents', status: 'pass', match: '100' }
  ],
  'processing-fee': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '94%' },
    { label: 'Customer signature present', status: 'pass' },
    { label: 'Processing fee amount extracted', status: 'warn', match: '0', value: 'AED 1,250 — expected AED 1,250 + AECB' },
    { label: 'Account number matches FinOne', status: 'pass', match: '100' }
  ],
  'bank-statement': [
    { label: 'Document available', status: 'pass' },
    { label: 'Customer Full Name matches', status: 'pass', match: 'fuzzy', score: '92%' },
    { label: 'Bank seal / stamp present', status: 'warn' }
  ]
};

// Extracted fields per document (subset, with Emirates ID fully populated)
const DOC_FIELDS = {
  'emirates-id': [
    { field: 'ID Number', value: '784-1990-1234567-1' },
    { field: 'Name (English)', value: 'Ahmed Mohammed Al Mansoori' },
    { field: 'Name (Arabic)', value: 'أحمد محمد المنصوري' },
    { field: 'Nationality', value: 'United Arab Emirates' },
    { field: 'Date of Birth', value: '15/03/1990' },
    { field: 'Expiry Date', value: '14/05/2030' }
  ],
  'passport': [
    { field: 'Passport Number', value: 'AB1234567' },
    { field: 'Full Name', value: 'Ahmed Mohammed Al Mansoori' },
    { field: 'Date of Birth', value: '15/03/1990' },
    { field: 'Expiry Date', value: '22/08/2029' }
  ],
  'murabaha-request': [
    { field: 'Customer Name', value: 'Ahmed Mohammed Al Mansoori' },
    { field: 'Requested Amount', value: 'AED 250,000' },
    { field: 'Tenure', value: '48 months' },
    { field: 'Signature Date', value: '12 May 2026' }
  ],
  'sukuk-certificate': [
    { field: 'Customer Name', value: 'Ahmed Mohammed Al Mansoori' },
    { field: 'Financed Amount', value: 'AED 248,000' },
    { field: 'FinOne Approved Amount', value: 'AED 250,000' },
    { field: 'NBC Reference', value: 'NBC-2026-44781' }
  ]
};

// Per-document state is derived from each application's own flag count.
// This prevents a clean application from showing flagged document details merely
// because another mock application uses the same document type.
function getConfiguredFlaggedDocKeys(app) {
  if (!app) return [];
  const requestedCount = Math.max(0, Number(app.flags || 0));
  if (requestedCount === 0) return [];

  const docs = Array.isArray(app.documents) ? app.documents : [];
  const issueDocs = docs.filter(key => (DOC_VALIDATIONS[key] || []).some(rule => rule.status === 'fail' || rule.status === 'warn'));
  const remainingDocs = docs.filter(key => !issueDocs.includes(key));
  return issueDocs.concat(remainingDocs).slice(0, Math.min(requestedCount, docs.length));
}

function getEffectiveValidations(app, docKey) {
  const baseRules = (DOC_VALIDATIONS[docKey] || []).map(rule => ({ ...rule }));
  const isFlaggedForThisApplication = getConfiguredFlaggedDocKeys(app).includes(docKey);

  if (isFlaggedForThisApplication) {
    const hasIssue = baseRules.some(rule => rule.status === 'fail' || rule.status === 'warn');
    return hasIssue ? baseRules : baseRules.concat([{ label: 'Manual document review required', status: 'warn' }]);
  }

  return baseRules.map(rule => {
    if (rule.status !== 'fail' && rule.status !== 'warn') return rule;
    const normalised = { ...rule, status: 'pass' };
    if (normalised.match === '0') normalised.match = '100';
    if (normalised.value && /\bvs\b|expected/i.test(normalised.value)) delete normalised.value;
    return normalised;
  });
}

function getDocState(appId, docKey) {
  const app = APPLICATIONS.find(item => item.id === appId);
  const rules = getEffectiveValidations(app, docKey);
  const hasFail = rules.some(rule => rule.status === 'fail');
  const hasWarn = rules.some(rule => rule.status === 'warn');
  return {
    status: hasFail ? 'flagged' : (hasWarn ? 'flagged' : 'passed'),
    confidence: hasFail ? '82%' : (hasWarn ? '88%' : '95%')
  };
}

// ============================================================
// SEARCH & LIST — defaults to showing all applications.
// Search / status pills only narrow the list down.
// ============================================================
let currentStatusFilter = 'all';

function getFilteredApps() {
  const q = document.getElementById('searchInput').value.trim().toLowerCase();
  const status = currentStatusFilter;

  return APPLICATIONS.filter(app => {
    if (SCREEN_MODE === 'maker' && app.status !== 'pendingatmaker') return false;
    if (SCREEN_MODE === 'checker' && app.status !== 'pendingatchecker') return false;
    if (q) {
      const hay = (app.id + ' ' + app.customer + ' ' + app.eid + ' ' + app.submittedBy + ' ' + branchDisplayName(app) + ' ' + (app.branchId || '') + ' ' + finnOneStatusLabel(app) + ' ' + (app.assignedMaker || '') + ' ' + (app.assignedChecker || '')).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    if (status !== 'all' && app.status !== status) return false;
    return true;
  });
}

function workflowStatusLabel(status) {
  const labels = { pendingassignment:'Pending Assignment', pendingatmaker:'Pending at Maker', withfinnone:'With FinnOne – Checker Stage', completed:'Completed' };
  return labels[status] || status;
}

function completionOutcomeLabel(app) {
  if (!app || !['withfinnone', 'completed'].includes(app.status)) return '—';
  return app.outcome === 'rejected' ? 'Rejected' : 'Accepted';
}

function formatDateTime(value) {
  if (!value) return '—';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return parsed.toLocaleString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true
  });
}

function completionDateTimeLabel(app) {
  return app && app.status === 'completed' ? formatDateTime(app.completedAt) : '—';
}

function rejectionReasonLabel(app) {
  return app && ['withfinnone', 'completed'].includes(app.status) && app.outcome === 'rejected' && app.rejectionReason
    ? app.rejectionReason
    : '—';
}


function branchDisplayName(app) {
  return (app && (app.branchName || app.branchId)) || '—';
}

function finnOneStatusLabel(app) {
  if (!app) return '—';
  if (app.status === 'pendingassignment' || app.status === 'pendingatmaker') return app.finnOneStatus || 'In Process';
  if (app.status === 'withfinnone') return app.finnOneStatus || 'Checker Stage';
  if (app.status === 'completed') return app.finnOneStatus || 'Completed';
  return app.finnOneStatus || '—';
}

function aiProcessingCountLabel(app) {
  return Number((app && app.aiProcessingCount) || 0);
}

function rejectionDateTimeLabel(app) {
  return app && app.outcome === 'rejected' ? formatDateTime(app.rejectionAt || app.completedAt) : '—';
}

function rfoProcessorCommentsLabel(app) {
  if (!app) return '—';
  return app.rfoProcessorComments || app.rejectionReason || '—';
}

function rfoCheckerCommentsLabel(app) {
  if (!app) return '—';
  return app.rfoCheckerComments || app.decisionComments || '—';
}

function flaggedBadgeHtml(app) {
  const count = Number(app.flags || 0);
  if (count > 0) {
    const label = count === 1 ? 'flagged document' : 'flagged documents';
    return `<span title="${count} ${label}" class="bg-red-100 text-red-700 px-2.5 py-1 rounded-full text-[10px] font-semibold whitespace-nowrap">Yes</span>`;
  }
  return '<span class="bg-gray-100 text-gray-600 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">No</span>';
}

function statusBadgeHtml(status) {
  const map = {
    pendingassignment: 'bg-purple-100 text-purple-700',
    pendingatmaker: 'bg-orange-100 text-orange-700',
    withfinnone: 'bg-blue-100 text-blue-700',
    completed: 'bg-green-100 text-green-700'
  };
  return '<span class="' + (map[status] || 'bg-gray-100 text-gray-700') + ' px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap">' + workflowStatusLabel(status) + '</span>';
}

function renderResults() {
  updateStatusCounts();
  // Always show the list. Empty state is only used to convey "no matches".
  document.getElementById('emptyState').style.display = 'none';
  document.getElementById('resultsList').classList.remove('hidden');

  const apps = getFilteredApps();
  document.getElementById('resultsCount').textContent = apps.length;
  const body = document.getElementById('resultsBody');
  if (apps.length === 0) {
    body.innerHTML = '<tr><td colspan="10" class="text-center py-12 text-gray-500 text-[13px]">No applications match your filters.</td></tr>';
    return;
  }
  body.innerHTML = apps.map(app => `
    <tr class="border-b border-gray-50 table-row-hover cursor-pointer" onclick="openDetailPanel('${app.id}')">
      <td class="py-3 px-5 text-blue-600 font-medium">${app.id}</td>
      <td class="py-3 text-gray-800">${app.customer}</td>
      <td class="py-3 text-gray-600">${app.submittedBy}</td>
      <td class="py-3 text-gray-600 font-medium">${branchDisplayName(app)}</td>
      <td class="py-3 text-gray-500 whitespace-nowrap">${app.submitted}</td>
      <td class="py-3 text-gray-700 whitespace-nowrap">${finnOneStatusLabel(app)}</td>
      <td class="py-3">${statusBadgeHtml(app.status)}</td>
      <td class="py-3">${flaggedBadgeHtml(app)}</td>
      <td class="py-3 text-gray-700 font-semibold">${aiProcessingCountLabel(app)}</td>
      <td class="py-3 px-5 text-blue-600"><i class="fas fa-chevron-right text-[10px]"></i></td>
    </tr>
  `).join('');
}

function updateStatusCounts() {
  const q = document.getElementById('searchInput').value.trim().toLowerCase();
  const baseFiltered = APPLICATIONS.filter(app => {
    if (SCREEN_MODE === 'maker' && app.status !== 'pendingatmaker') return false;
    if (SCREEN_MODE === 'checker' && app.status !== 'pendingatchecker') return false;
    if (q) {
      const hay = (app.id + ' ' + app.customer + ' ' + app.eid + ' ' + app.submittedBy + ' ' + branchDisplayName(app) + ' ' + (app.branchId || '') + ' ' + finnOneStatusLabel(app) + ' ' + (app.assignedMaker || '') + ' ' + (app.assignedChecker || '')).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
  document.querySelectorAll('.status-pill').forEach(pill => {
    const s = pill.dataset.status;
    const count = s === 'all' ? baseFiltered.length : baseFiltered.filter(a => a.status === s).length;
    const countEl = pill.querySelector('.count');
    if (countEl) countEl.textContent = count;
  });
}

function clearFilters() {
  document.getElementById('searchInput').value = '';
  currentStatusFilter = 'all';
  document.querySelectorAll('.status-pill').forEach(p => p.classList.toggle('active', p.dataset.status === 'all'));
  renderResults();
}

document.getElementById('searchInput').addEventListener('input', renderResults);
document.querySelectorAll('.status-pill').forEach(pill => {
  pill.addEventListener('click', () => {
    document.querySelectorAll('.status-pill').forEach(p => p.classList.remove('active'));
    pill.classList.add('active');
    currentStatusFilter = pill.dataset.status;
    renderResults();
  });
});

// ============================================================
// DETAIL PANEL
// ============================================================
let currentApp = null;
let currentDocKey = null;

function openDetailPanel(appId) {
  const app = APPLICATIONS.find(a => a.id === appId);
  if (!app) return;
  currentApp = app;
  document.getElementById('detailAppId').textContent = app.id;
  document.getElementById('detailCustomer').textContent = app.customer;
  document.getElementById('detailEid').textContent = app.eid;
  document.getElementById('detailSubmittedBy').textContent = app.submittedBy;
  document.getElementById('detailBranchId').textContent = branchDisplayName(app);
  document.getElementById('detailFinnOneStatus').textContent = finnOneStatusLabel(app);
  document.getElementById('detailAiProcessingCount').textContent = aiProcessingCountLabel(app);
  document.getElementById('detailSubmitted').textContent = app.submitted;
  document.getElementById('detailFlagged').innerHTML = flaggedBadgeHtml(app);
  document.getElementById('detailOutcomeRow').style.display = ['withfinnone', 'completed'].includes(app.status) ? 'flex' : 'none';
  document.getElementById('detailOutcome').textContent = completionOutcomeLabel(app);
  document.getElementById('detailCompletedAtRow').style.display = app.status === 'completed' ? 'flex' : 'none';
  document.getElementById('detailCompletedAt').textContent = completionDateTimeLabel(app);
  document.getElementById('detailRejectionAtRow').style.display = ['withfinnone', 'completed'].includes(app.status) && app.outcome === 'rejected' ? 'flex' : 'none';
  document.getElementById('detailRejectionAt').textContent = rejectionDateTimeLabel(app);
  document.getElementById('detailRejectionReasonRow').style.display = ['withfinnone', 'completed'].includes(app.status) && app.outcome === 'rejected' ? 'flex' : 'none';
  document.getElementById('detailRejectionReason').textContent = rfoProcessorCommentsLabel(app);
  document.getElementById('detailCheckerCommentsRow').style.display = 'none';
  document.getElementById('detailCheckerComments').textContent = rfoCheckerCommentsLabel(app);
  document.getElementById('detailStatusBadge').innerHTML = statusBadgeHtml(app.status);
  renderDocList();
  renderDecisionCard();
  document.getElementById('detailPanel').classList.add('open');
  document.getElementById('mainContent').classList.add('panel-open');
}

function closeDetailPanel() {
  document.getElementById('detailPanel').classList.remove('open');
  document.getElementById('mainContent').classList.remove('panel-open');
  currentApp = null;
}

function statusLabel(s) {
  return s === 'passed' ? 'Passed' :
         s === 'flagged' ? 'Discrepancy' :
         s === 'approved' ? 'Approved' :
         s === 'rejected' ? 'Rejected' : 'Failed';
}

function renderDecisionCard() {
  const el = document.getElementById('workflowActionCard');
  if (!el || !currentApp) return;

  if (SCREEN_MODE === 'maker' && currentApp.status === 'pendingatmaker') {
    el.innerHTML = `
      <div class="bg-gray-50 rounded-xl p-4 border border-gray-200">
        <h3 class="text-gray-900 font-semibold text-[13px] mb-3 flex items-center gap-2">
          <i class="fas fa-user-check text-blue-600 text-[12px]"></i>
          Maker-Level Decision
        </h3>
        <p class="text-[11px] text-gray-600 mb-3">Review the application-level details and supporting documents. The Maker decision is recorded in the AI platform, then the application moves to FinnOne for Checker-stage processing.</p>
        <div class="flex gap-2">
          <button onclick="showOverallApproveModal()" class="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white px-3 py-2.5 rounded-lg text-[12px] font-medium transition">
            <i class="fas fa-arrow-right text-[11px]"></i>
            Approve &amp; Move to FinnOne
          </button>
          <button onclick="showOverallRejectModal()" class="flex-1 flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white px-3 py-2.5 rounded-lg text-[12px] font-medium transition">
            <i class="fas fa-times text-[11px]"></i>
            Reject &amp; Move to FinnOne
          </button>
        </div>
      </div>`;
    return;
  }

  el.innerHTML = `
    <div class="bg-blue-50 rounded-xl p-4 border border-blue-100">
      <h3 class="text-gray-900 font-semibold text-[13px] mb-2 flex items-center gap-2"><i class="fas fa-route text-blue-600 text-[12px]"></i>Workflow Status</h3>
      <p class="text-[11px] text-gray-600">Current status: <strong>${workflowStatusLabel(currentApp.status)}</strong>. This screen is read-only once the Maker decision has been submitted.</p>
    </div>`;
}

// Card markup for a single document. Variant determines border colour.
function docCardHtml(key, state, isFlagged) {
  const meta = DOC_TYPES[key] || { title: key, icon: 'fa-file' };
  const borderCls = isFlagged ? 'border-red-200 bg-white hover:border-red-400' : 'border-gray-200 bg-white hover:border-blue-300';
  const iconBg = isFlagged ? 'bg-red-50' : 'bg-blue-50';
  const iconColor = isFlagged ? 'text-red-600' : 'text-blue-600';
  return `
    <div class="${borderCls} border rounded-lg p-3 cursor-pointer transition" onclick="openDocModal('${key}')">
      <div class="flex items-center justify-between gap-3">
        <div class="flex items-center gap-3 min-w-0 flex-1">
          <div class="w-8 h-8 ${iconBg} rounded-md flex items-center justify-center flex-shrink-0">
            <i class="fas ${meta.icon} ${iconColor} text-[12px]"></i>
          </div>
          <div class="min-w-0 flex-1">
            <div class="text-[12px] font-medium text-gray-900 truncate">${meta.title}</div>
            <div class="text-[10px] text-gray-500">Confidence ${state.confidence}</div>
          </div>
        </div>
        <span class="doc-status-badge ${state.status}">${statusLabel(state.status)}</span>
        <i class="fas fa-chevron-right text-gray-400 text-[10px]"></i>
      </div>
    </div>
  `;
}

function renderDocList() {
  if (!currentApp) return;
  const docs = currentApp.documents;

  // Split flagged (or failed) docs from the rest so the reviewer sees them first.
  const flagged = [];
  const others = [];
  docs.forEach(key => {
    const state = getDocState(currentApp.id, key);
    if (state.status === 'flagged' || state.status === 'failed') flagged.push({ key, state });
    else others.push({ key, state });
  });

  const flaggedSection = document.getElementById('flaggedDocsSection');
  if (flagged.length > 0) {
    flaggedSection.style.display = 'block';
    document.getElementById('flaggedDocsCount').textContent = flagged.length;
    document.getElementById('flaggedDocsList').innerHTML = flagged.map(d => docCardHtml(d.key, d.state, true)).join('');
  } else {
    flaggedSection.style.display = 'none';
  }

  document.getElementById('docCount').textContent = '(' + others.length + ' of ' + docs.length + ')';
  const list = document.getElementById('docList');
  list.innerHTML = others.length > 0
    ? others.map(d => docCardHtml(d.key, d.state, false)).join('')
    : '<div class="text-[11px] text-gray-400 italic p-3 bg-gray-50 rounded-lg">All documents have discrepancies. Resolve the items above to proceed.</div>';
}

// ============================================================
// DOC MODAL
// ============================================================
function openDocModal(docKey) {
  if (!currentApp) return;
  currentDocKey = docKey;
  const meta = DOC_TYPES[docKey] || { title: docKey, icon: 'fa-file' };
  const state = getDocState(currentApp.id, docKey);

  document.getElementById('modalDocTitle').textContent = meta.title;
  document.getElementById('modalDocIcon').innerHTML = '<i class="fas ' + meta.icon + ' text-blue-600"></i>';
  document.getElementById('modalAppRef').textContent = currentApp.id;

  const statusEl = document.getElementById('modalDocStatus');
  statusEl.className = 'doc-status-badge ' + state.status;
  statusEl.textContent = state.status.charAt(0).toUpperCase() + state.status.slice(1);

  // Validation checklist
  const checks = getEffectiveValidations(currentApp, docKey);
  document.getElementById('validationChecks').innerHTML = checks.map(c => {
    const icon = c.status === 'pass' ? '<i class="fas fa-check-circle text-green-600"></i>' :
                 c.status === 'fail' ? '<i class="fas fa-times-circle text-red-600"></i>' :
                 '<i class="fas fa-exclamation-circle text-amber-500"></i>';
    let badge = '';
    if (c.match === '100') badge = '<span class="match-chip match-100">100% match</span>';
    else if (c.match === '0') badge = '<span class="match-chip match-0">0% match</span>';
    else if (c.match === 'fuzzy') badge = '<span class="match-chip match-fuzzy">Fuzzy ' + (c.score || '') + '</span>';
    const value = c.value ? '<div class="text-[10px] text-gray-500 mt-0.5">' + c.value + '</div>' : '';
    return `
      <div class="validation-row ${c.status}">
        <div class="flex items-start gap-2 flex-1 min-w-0">
          <div class="pt-0.5">${icon}</div>
          <div class="min-w-0 flex-1">
            <div class="text-gray-800 text-[12px]">${c.label}</div>
            ${value}
          </div>
        </div>
        ${badge}
      </div>
    `;
  }).join('') || '<div class="text-[11px] text-gray-500 italic">No validation rules configured for this document.</div>';

  // Extracted fields
  const fields = DOC_FIELDS[docKey];
  const fieldsEl = document.getElementById('extractedFields');
  if (fields && fields.length) {
    fieldsEl.innerHTML = '<table class="w-full text-[11px]">' +
      fields.map(f => `
        <tr class="border-b border-gray-100 last:border-0">
          <td class="px-3 py-2 text-gray-500 w-2/5">${f.field}</td>
          <td class="px-3 py-2 text-gray-900 font-medium">${f.value}</td>
        </tr>
      `).join('') + '</table>';
  } else {
    fieldsEl.innerHTML = '<div class="p-4 text-[11px] text-gray-500 italic">Extracted field detail available in the full implementation.</div>';
  }

  // Audit
  document.getElementById('auditDetails').innerHTML = `
    <div>Extraction model: Azure Document Intelligence v3.1</div>
    <div>Validation engine: ADIB Citadel v2.4</div>
    <div>Extracted at: ${currentApp.submitted}</div>
  `;

  // Document preview (PDF / image with toolbar & fullscreen)
  renderViewer(docKey);

  document.getElementById('docModal').classList.add('open');
}

function closeDocModal(e) {
  if (e && e.target !== e.currentTarget) return;
  document.getElementById('docModal').classList.remove('open');
}

// ============================================================
// AI-suggested rejection comment
// Builds a recommendation by reading the failing validation rules on every
// flagged document in the current application. The reviewer can edit before
// submitting.
// ============================================================
function aiRejectionDraft(app) {
  if (!app) return '';
  const findings = [];
  app.documents.forEach(docKey => {
    const state = getDocState(app.id, docKey);
    if (state.status !== 'flagged' && state.status !== 'failed') return;
    const meta = DOC_TYPES[docKey] || { title: docKey };
    getEffectiveValidations(app, docKey)
      .filter(r => r.status === 'fail' || r.status === 'warn')
      .forEach(rule => findings.push({
        doc: meta.title,
        issue: rule.label.replace(/[“”]/g, '"'),
        detail: rule.value || null
      }));
  });

  const header = 'AI suggestion — review and edit before submitting.\n\n';
  if (findings.length === 0) {
    return header +
      `Application ${app.id} for ${app.customer} did not surface automated discrepancies. ` +
      `Recommend manual review notes before rejection.`;
  }

  const bullets = findings.map(f =>
    `• ${f.doc} — ${f.issue}${f.detail ? ' (' + f.detail + ')' : ''}`
  ).join('\n');

  const intro = `Application ${app.id} for ${app.customer} carries ${findings.length} unresolved ` +
                `discrepanc${findings.length === 1 ? 'y' : 'ies'} detected during automated validation:\n\n`;
  const close = `\n\nThese issues cannot be reconciled with existing FinOne records. ` +
                `Recommend rejection until the customer resubmits corrected documents.`;
  return header + intro + bullets + close;
}

// ============================================================
// WORKFLOW DECISIONS
// ============================================================
function showOverallApproveModal() {
  if (!currentApp || SCREEN_MODE !== 'maker' || currentApp.status !== 'pendingatmaker') return;
  document.getElementById('overallApproveSubtitle').textContent = currentApp.id + ' · ' + currentApp.documents.length + ' documents';
  document.getElementById('overallApproveComments').value = '';
  document.getElementById('overallApproveModal').classList.add('open');
}
function closeOverallApproveModal(e) {
  if (e && e.target !== e.currentTarget) return;
  document.getElementById('overallApproveModal').classList.remove('open');
}
function confirmOverallApprove() {
  if (!currentApp || SCREEN_MODE !== 'maker' || currentApp.status !== 'pendingatmaker') return;
  currentApp.status = 'withfinnone';
  currentApp.assignmentStage = 'finnone';
  currentApp.makerDecision = 'approved';
  currentApp.finnOneStatus = 'Checker Stage';
  currentApp.outcome = 'accepted';
  currentApp.completedAt = null;
  currentApp.rejectionReason = null;
  currentApp.rejectionAt = null;
  currentApp.assignedChecker = null;
  currentApp.rfoProcessorComments = document.getElementById('overallApproveComments').value.trim() || 'Approved by RFO Processor. Moved to Checker stage in FinnOne.';
  currentApp.decisionComments = currentApp.rfoProcessorComments;
  currentApp.rfoCheckerComments = null;
  saveApplications();
  closeOverallApproveModal(); closeDetailPanel(); renderResults();
  toast('Application approved by Maker and moved to FinnOne for Checker-stage processing.');
}

function showOverallRejectModal() {
  if (!currentApp || SCREEN_MODE !== 'maker' || currentApp.status !== 'pendingatmaker') return;
  document.getElementById('overallRejectSubtitle').textContent = currentApp.id + ' · ' + currentApp.customer;
  document.getElementById('overallRejectComments').value = aiRejectionDraft(currentApp);
  document.getElementById('overallRejectModal').classList.add('open');
}
function closeOverallRejectModal(e) {
  if (e && e.target !== e.currentTarget) return;
  document.getElementById('overallRejectModal').classList.remove('open');
}
function confirmOverallReject() {
  const comments = document.getElementById('overallRejectComments').value.trim();
  if (!comments) { toast('Comments required for rejection', true); return; }
  if (!currentApp || SCREEN_MODE !== 'maker' || currentApp.status !== 'pendingatmaker') return;
  currentApp.status = 'withfinnone';
  currentApp.assignmentStage = 'finnone';
  currentApp.makerDecision = 'rejected';
  currentApp.finnOneStatus = 'Checker Stage';
  currentApp.outcome = 'rejected';
  currentApp.completedAt = null;
  currentApp.rejectionReason = comments;
  currentApp.rejectionAt = new Date().toISOString();
  currentApp.assignedChecker = null;
  currentApp.rfoProcessorComments = comments;
  currentApp.decisionComments = comments;
  currentApp.rfoCheckerComments = null;
  saveApplications();
  closeOverallRejectModal(); closeDetailPanel(); renderResults();
  toast('Application rejected by Maker and moved to FinnOne for Checker-stage processing.');
}


// ============================================================
// DOCUMENT VIEWER (PDF / image with toolbar + fullscreen)
// ============================================================
let viewerZoomLevel = 1;

function renderViewer(docKey) {
  const meta = DOC_TYPES[docKey] || {};
  const iframe = document.getElementById('docPdfFrame');
  const img = document.getElementById('docImagePreview');
  const placeholder = document.getElementById('docPlaceholder');
  const subtitle = document.getElementById('viewerSubtitle');
  const fileMeta = document.getElementById('placeholderFileMeta');

  // Reset zoom on every open.
  viewerZoomLevel = 1;
  applyViewerZoom();

  // Reset to all-hidden.
  iframe.style.display = 'none';
  img.style.display = 'none';
  placeholder.style.display = 'block';
  iframe.removeAttribute('src');
  img.removeAttribute('src');

  subtitle.textContent = meta.fileName ? meta.fileName : (meta.previewFormat === 'pdf' ? 'PDF document' : 'Image');
  fileMeta.textContent = meta.fileName ? 'File: ' + meta.fileName : '';

  if (meta.previewUrl) {
    if (meta.previewFormat === 'image') {
      img.onload = () => {
        img.style.display = 'block';
        placeholder.style.display = 'none';
      };
      img.onerror = () => {
        img.style.display = 'none';
        placeholder.style.display = 'block';
      };
      img.src = meta.previewUrl;
    } else if (meta.previewFormat === 'pdf') {
      iframe.src = meta.previewUrl + '#view=FitH';
      iframe.style.display = 'block';
      placeholder.style.display = 'none';
    }
  }
  // No real preview file → keep placeholder visible (PDF icon + helper copy).
}

function viewerZoom(delta) {
  viewerZoomLevel = Math.min(2.5, Math.max(0.5, viewerZoomLevel + delta));
  applyViewerZoom();
}
function viewerResetZoom() {
  viewerZoomLevel = 1;
  applyViewerZoom();
}
function applyViewerZoom() {
  const content = document.querySelector('#docViewer .viewer-content');
  if (!content) return;
  content.style.transform = viewerZoomLevel === 1 ? '' : `scale(${viewerZoomLevel})`;
  const label = document.getElementById('viewerZoomLabel');
  if (label) label.textContent = Math.round(viewerZoomLevel * 100) + '%';
}

function viewerToggleFullscreen() {
  const viewer = document.getElementById('docViewer');
  const isFull = document.fullscreenElement || document.webkitFullscreenElement;
  if (!isFull) {
    const req = viewer.requestFullscreen || viewer.webkitRequestFullscreen || viewer.msRequestFullscreen;
    if (req) {
      try { req.call(viewer); } catch (e) { toast('Fullscreen not supported in this browser', true); }
    } else {
      toast('Fullscreen not supported in this browser', true);
    }
  } else {
    const exit = document.exitFullscreen || document.webkitExitFullscreen;
    if (exit) exit.call(document);
  }
}

function viewerDownload() {
  if (!currentDocKey) return;
  const meta = DOC_TYPES[currentDocKey];
  if (meta && meta.previewUrl) {
    const a = document.createElement('a');
    a.href = meta.previewUrl;
    a.download = meta.fileName || 'document';
    document.body.appendChild(a);
    a.click();
    a.remove();
  } else {
    toast('Original file download will be enabled in production');
  }
}

// ============================================================
// TOAST
// ============================================================
let toastTimer = null;
function toast(msg, isError) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.toggle('bg-red-600', !!isError);
  el.classList.toggle('bg-gray-900', !isError);
  el.style.opacity = '1';
  el.style.pointerEvents = 'auto';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.style.opacity = '0';
    el.style.pointerEvents = 'none';
  }, 2600);
}

// ============================================================
// EXPORT — current filtered list to PDF or Excel
// Export reflects whatever filters are active (search / status pill).
// ============================================================
function toggleExportMenu(e) {
  if (e) e.stopPropagation();
  document.getElementById('exportMenu').classList.toggle('hidden');
}
document.addEventListener('click', e => {
  if (!e.target.closest('#exportBtn') && !e.target.closest('#exportMenu')) {
    document.getElementById('exportMenu').classList.add('hidden');
  }
});

function fileStamp() { return new Date().toISOString().slice(0, 10); }

function exportContext() {
  const q = document.getElementById('searchInput').value.trim();
  const filters = [];
  if (q) filters.push(`Search: "${q}"`);
  if (currentStatusFilter !== 'all') filters.push(`Status: ${currentStatusFilter}`);
  return filters.length ? filters.join(' · ') : 'All applications';
}

function exportResultsPDF() {
  document.getElementById('exportMenu').classList.add('hidden');
  const apps = getFilteredApps();
  if (apps.length === 0) { toast('No applications to export', true); return; }

  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

  pdf.setFontSize(14);
  pdf.setTextColor(27, 62, 197);
  pdf.text('Sukkuk — Maker Stage', 14, 16);
  pdf.setFontSize(9);
  pdf.setTextColor(100);
  pdf.text(`${apps.length} application${apps.length === 1 ? '' : 's'} · ${exportContext()} · Exported ${new Date().toLocaleString()}`, 14, 22);

  pdf.autoTable({
    startY: 28,
    head: [['Application ID', 'Customer', 'Emirates ID', 'Submitted By', 'Branch Name', 'Submitted', 'Status', 'Discrepancy', 'Outcome', 'Completed On', 'RFO Processor Comments']],
    body: apps.map(a => [a.id, a.customer, a.eid, a.submittedBy, a.branchId, a.submitted, workflowStatusLabel(a.status), a.flags > 0 ? 'Yes' : 'No', completionOutcomeLabel(a), completionDateTimeLabel(a), rfoProcessorCommentsLabel(a)]),
    headStyles: { fillColor: [41, 82, 232], textColor: 255, fontSize: 9 },
    bodyStyles: { fontSize: 9 },
    alternateRowStyles: { fillColor: [248, 250, 255] },
    margin: { left: 14, right: 14 }
  });

  pdf.save(`sukkuk-applications-${fileStamp()}.pdf`);
  toast(`Exported ${apps.length} application${apps.length === 1 ? '' : 's'} as PDF`);
}

function exportResultsExcel() {
  document.getElementById('exportMenu').classList.add('hidden');
  const apps = getFilteredApps();
  if (apps.length === 0) { toast('No applications to export', true); return; }

  const rows = apps.map(a => ({
    'Application ID': a.id,
    'Customer': a.customer,
    'Emirates ID': a.eid,
    'Sub-Product': a.subProduct,
    'Submitted By': a.submittedBy,
    'Branch Name': a.branchId,
    'Submitted': a.submitted,
    'Status': workflowStatusLabel(a.status),
    'Discrepancy': a.flags > 0 ? 'Yes' : 'No',
    'Discrepancy Count': a.flags,
    'Completion Outcome': completionOutcomeLabel(a),
    'Completion Date & Time': completionDateTimeLabel(a),
    'RFO Processor Comments': rfoProcessorCommentsLabel(a),
    
    'Documents': a.documents.length
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  // Column widths for readability.
  ws['!cols'] = [
    { wch: 20 }, { wch: 32 }, { wch: 22 }, { wch: 20 },
    { wch: 12 }, { wch: 22 }, { wch: 20 }, { wch: 10 },
    { wch: 22 }, { wch: 18 }, { wch: 12 }
  ];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Applications');
  XLSX.writeFile(wb, `sukkuk-applications-${fileStamp()}.xlsx`);
  toast(`Exported ${apps.length} application${apps.length === 1 ? '' : 's'} as Excel`);
}

// ============================================================
// INIT (open app from URL if deeplinked)
// ============================================================
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    // If in fullscreen, let the browser exit; don't close the modal underneath.
    if (document.fullscreenElement || document.webkitFullscreenElement) return;
    closeDocModal();
    closeOverallApproveModal();
    closeOverallRejectModal();
    if (typeof closeExportPanel === 'function') closeExportPanel();
  }
});

(function init() {
  const params = new URLSearchParams(window.location.search);
  const appId = params.get('app');
  if (appId) {
    document.getElementById('searchInput').value = appId;
  }
  renderResults();
  if (appId && APPLICATIONS.find(a => a.id === appId)) {
    setTimeout(() => openDetailPanel(appId), 100);
  }
})();

(function () {
  const page = (location.pathname.split('/').pop() || 'index').toLowerCase();
  const publicPages = ['login', 'index'];
  const rpaAllowed = ['application-tracker'];
  const role = localStorage.getItem('adibUserRole');
  const username = localStorage.getItem('adibUsername') || 'User';

  // if (!role && !publicPages.includes(page)) {
  //   location.href = 'login';
  //   return;
  // }

  if (role === 'rpa' && !rpaAllowed.includes(page) && !publicPages.includes(page)) {
    location.href = 'application-tracker';
    return;
  }

  function applyRoleNavigation() {
    document.querySelectorAll('nav a').forEach(function (a) {
      const href = (a.getAttribute('href') || '').split('?')[0].split('#')[0].toLowerCase();
      if (role === 'rpa' && !rpaAllowed.includes(href)) {
        a.remove();
      }
    });

    const sidebarFooter = document.querySelector('aside .mt-auto');
    if (sidebarFooter && role) {
      sidebarFooter.innerHTML = `
        <div class="w-9 h-9 bg-blue-300/40 rounded-full flex items-center justify-center">
          <i class="fas fa-user text-white/80 text-sm"></i>
        </div>
        <div class="flex flex-col min-w-0 flex-1">
          <span class="text-white text-[12px] font-medium truncate">${username}</span>
          <span class="text-blue-300 text-[10px]">${role === 'rpa' ? 'RPA User' : 'RFO Processor'}</span>
        </div>
        <button onclick="adibLogout()" title="Logout" class="text-blue-200 hover:text-white text-[12px]">
          <i class="fas fa-right-from-bracket"></i>
        </button>`;
    }
  }

  window.adibLogout = function () {
    localStorage.removeItem('adibUsername');
    localStorage.removeItem('adibUserRole');
    location.href = 'login';
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyRoleNavigation);
  } else {
    applyRoleNavigation();
  }
})();
}
