export const ALL_PAGES = [
  {
    href: 'overview',
    title: 'Management Overview',
    description: 'KPIs and trends',
  },
  {
    href: 'application-tracker',
    title: 'Application Tracker',
    description: 'Application status, FinnOne status, discrepancies, and comments',
  },
  {
    href: 'maker',
    title: 'Maker Stage',
    description: 'Processor review and decision comments; handoff to FinnOne Checker stage',
  },
]

const RPA_ALLOWED = ['application-tracker']

export function redirectToLoginIfNeeded() {
  if (!localStorage.getItem('adibUserRole')) {
    window.location.replace('login')
    return true
  }
  return false
}

export function getHomeModel() {
  const role = localStorage.getItem('adibUserRole')
  const pages = role === 'rpa'
    ? ALL_PAGES.filter((page) => RPA_ALLOWED.includes(page.href))
    : ALL_PAGES
  const subtitle = role === 'rpa'
    ? 'Integration operations view.'
    : 'Phase 1 access: overview, assignment tracker, and Maker review.'
  return { pages, subtitle }
}

export function logout() {
  localStorage.removeItem('adibUsername')
  localStorage.removeItem('adibUserRole')
  window.location.href = 'login'
}
