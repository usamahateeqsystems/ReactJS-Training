const ROLE_PAGES = {
  RFOMaker: ['overview', 'maker'],
  RFOLead: ['overview', 'maker', 'application-tracker','checker'],
  RFOChecker: ['overview', 'checker'],
  RFOAdmin: ['overview', 'application-tracker', 'maker', 'checker', 'userlist', 'settings'],
}

export function canAccessPage(role, page) {
  return ROLE_PAGES[role]?.includes(page) ?? false
}
