from dataclasses import replace

from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app, get_current_principal
from app.models import Principal, Role
from app.store import CosmosStore, MemoryStore


def make_settings() -> Settings:
    return Settings(
        app_env="test",
        api_host="127.0.0.1",
        api_port=8000,
        cors_origins=("http://localhost:5173",),
        azure_tenant_id="test-tenant",
        azure_api_audience="api://test-api",
        cosmos_endpoint="",
        cosmos_key="",
        cosmos_database="adib-sukkuk",
        cosmos_users_container="users",
        cosmos_applications_container="applications",
        cosmos_create_resources=False,
        cosmos_required=False,
        bootstrap_admin_email="",
        seed_demo_data=True,
    )


def make_client(role: Role = Role.RFO_ADMIN):
    settings = make_settings()
    store = MemoryStore(settings)
    app = create_app(settings=settings, store=store)
    app.dependency_overrides[get_current_principal] = lambda: Principal(
        id="test-user",
        email="rfo.admin@example.com",
        role=role,
        displayName="Test User",
    )
    return TestClient(app), store


def add_test_maker(store: MemoryStore) -> None:
    store.create_user(
        {
            "id": "test-maker",
            "email": "rfo.maker@example.com",
            "role": Role.RFO_MAKER.value,
            "displayName": "Test Maker",
            "isActive": True,
        }
    )


def test_health_and_role_endpoint() -> None:
    client, _ = make_client()
    assert client.get("/api/v1/health").json()["dataSource"] == "memory"
    response = client.get("/api/v1/roles")
    assert response.status_code == 200
    assert response.json()["items"] == ["RFOLead", "RFOAdmin", "RFOChecker", "RFOMaker"]


def test_users_crud_and_duplicate_email_conflict() -> None:
    client, _ = make_client()
    created = client.post(
        "/api/v1/users",
        json={"email": "new.maker@example.com", "role": "RFOMaker"},
    )
    assert created.status_code == 201
    user_id = created.json()["id"]

    duplicate = client.post(
        "/api/v1/users",
        json={"email": "NEW.MAKER@example.com", "role": "RFOMaker"},
    )
    assert duplicate.status_code == 409

    updated = client.patch(
        f"/api/v1/users/{user_id}",
        json={"role": "RFOChecker"},
    )
    assert updated.status_code == 200
    assert updated.json()["role"] == "RFOChecker"

    deleted = client.delete(f"/api/v1/users/{user_id}")
    assert deleted.status_code == 204
    assert all(user["id"] != user_id for user in client.get("/api/v1/users").json()["items"])
    assert store.find_user_by_email("new.maker@example.com") is None


def test_maker_queue_decision_and_status_conflict() -> None:
    client, store = make_client(Role.RFO_MAKER)
    store._applications = [
        {
            "id": "test-application",
            "stage": "makerreview",
            "status": "pendingatmaker",
            "assignedMaker": "rfo.admin@example.com",
        }
    ]
    queue = client.get("/api/v1/maker/queue")
    assert queue.status_code == 200
    assert queue.json()["total"] == 1
    application_id = queue.json()["items"][0]["id"]

    rejected_without_comments = client.post(
        f"/api/v1/applications/{application_id}/maker-decision",
        json={"decision": "rejected"},
    )
    assert rejected_without_comments.status_code == 422

    decision = client.post(
        f"/api/v1/applications/{application_id}/maker-decision",
        json={"decision": "approved", "comments": "Reviewed and approved."},
    )
    assert decision.status_code == 200
    assert decision.json()["stage"] == "withfinnone"
    assert decision.json()["makerDecision"] == "approved"

    conflict = client.post(
        f"/api/v1/applications/{application_id}/maker-decision",
        json={"decision": "approved"},
    )
    assert conflict.status_code == 409
    assert store.get_application(application_id)["stage"] == "withfinnone"


def test_maker_queue_only_shows_applications_assigned_to_maker() -> None:
    applications = [
        {
            "id": "owned",
            "stage": "makerreview",
            "assignedMaker": "RFO.ADMIN@example.com",
        },
        {
            "id": "other-maker",
            "stage": "makerreview",
            "assignedMaker": "another.maker@example.com",
        },
        {
            "id": "unassigned",
            "stage": "makerreview",
            "assignedMaker": None,
        },
    ]
    maker_client, maker_store = make_client(Role.RFO_MAKER)
    maker_store._applications = applications

    maker_queue = maker_client.get("/api/v1/maker/queue")
    assert [app["id"] for app in maker_queue.json()["items"]] == ["owned"]

    lead_client, lead_store = make_client(Role.RFO_LEAD)
    lead_store._applications = applications
    lead_queue = lead_client.get("/api/v1/maker/queue")
    assert {app["id"] for app in lead_queue.json()["items"]} == {
        "owned",
        "other-maker",
        "unassigned",
    }


def test_user_management_is_forbidden_to_maker() -> None:
    client, _ = make_client(Role.RFO_MAKER)
    assert client.get("/api/v1/users").status_code == 403


def test_assignment_status_update_and_overview_summary() -> None:
    client, store = make_client(Role.RFO_LEAD)
    add_test_maker(store)
    applications = client.get("/api/v1/applications?status=pendingassignment")
    assert applications.status_code == 200
    application_id = applications.json()["items"][0]["id"]

    assigned = client.post(
        "/api/v1/applications/assignments",
        json={
            "applicationIds": [application_id],
            "makerEmail": "rfo.maker@example.com",
        },
    )
    assert assigned.status_code == 200
    assert assigned.json()["updatedCount"] == 1
    assert assigned.json()["items"][0]["stage"] == "makerreview"
    assert assigned.json()["items"][0]["status"] == "pendingatmaker"

    summary = client.get("/api/v1/dashboard/overview")
    assert summary.status_code == 200
    assert summary.json()["kpis"]["processed"] == 26
    assert len(summary.json()["trendSeries"]) == 4


def test_assignment_updates_pending_applications_to_selected_maker() -> None:
    client, store = make_client(Role.RFO_LEAD)
    add_test_maker(store)
    pending = next(
        app for app in store.list_applications() if app["status"] == "pendingassignment"
    )

    response = client.post(
        "/api/v1/applications/assignments",
        json={
            "applicationIds": [pending["id"]],
            "makerEmail": "rfo.maker@example.com",
        },
    )

    assert response.status_code == 200
    assigned = response.json()["items"][0]
    assert assigned["assignedMaker"] == "rfo.maker@example.com"
    assert assigned["status"] == "pendingatmaker"
    assert assigned["stage"] == "makerreview"
    assert store.get_application(pending["id"])["assignedMaker"] == "rfo.maker@example.com"


def test_protected_endpoint_requires_bearer_token() -> None:
    settings = make_settings()
    app = create_app(settings=settings, store=MemoryStore(settings))
    with TestClient(app) as client:
        response = client.get("/api/v1/auth/me")
    assert response.status_code == 401


def test_auth_me_looks_up_role_from_the_user_store() -> None:
    settings = make_settings()
    app = create_app(
        settings=settings,
        store=MemoryStore(settings),
        token_validator=lambda token, token_settings: (
            {"preferred_username": "rfo.maker@example.com"}
            if token == "test-token" and token_settings is settings
            else {}
        ),
    )
    with TestClient(app) as client:
        response = client.get("/api/v1/auth/me", headers={"Authorization": "Bearer test-token"})
    assert response.status_code == 200
    assert response.json()["role"] == "RFOMaker"


def test_checker_can_update_finnone_status() -> None:
    client, store = make_client(Role.RFO_CHECKER)
    checker_case = {
        "id": "APP001|CASE",
        "applicationId": "APP001",
        "type": "Case",
        "stage": "CHECKER_REVIEW",
        "makerDecision": "REJECTED",
        "finnOneStatus": "IN_PROGRESS",
        "flaggedDocumentCount": 2,
        "tenantId": "test",
    }
    maker_case = {
        "id": "APP002|CASE",
        "applicationId": "APP002",
        "type": "Case",
        "stage": "makerreview",
        "tenantId": "test",
    }
    store._applications = [checker_case, maker_case]

    queue = client.get("/api/v1/checker/queue")
    assert queue.status_code == 200
    assert [app["applicationId"] for app in queue.json()["items"]] == ["APP001"]
    assert client.get("/api/v1/applications").status_code == 403
    assert client.get("/api/v1/maker/queue").status_code == 403

    maker_client, _ = make_client(Role.RFO_MAKER)
    assert maker_client.get("/api/v1/checker/queue").status_code == 403

    overview = client.get("/api/v1/dashboard/overview")
    assert overview.status_code == 200
    assert overview.json()["statusBars"]["pendingChecker"] == 1
    assert overview.json()["kpis"]["flagged"] == 1

    updated = client.patch(
        "/api/v1/applications/APP001/finnone-status",
        json={"status": "Completed"},
    )
    assert updated.status_code == 200
    assert updated.json()["stage"] == "completed"
    assert updated.json()["finnOneStatus"] == "Completed"
    assert store.get_application("APP001")["stage"] == "completed"


def test_checker_cannot_update_an_application_outside_checker_queue() -> None:
    client, store = make_client(Role.RFO_CHECKER)
    store._applications.append({
        "id": "APP002|CASE",
        "applicationId": "APP002",
        "type": "Case",
        "stage": "makerreview",
        "tenantId": "test",
    })

    response = client.patch(
        "/api/v1/applications/APP002/finnone-status",
        json={"status": "Completed"},
    )
    assert response.status_code == 409


def test_bootstrap_email_is_provisioned_as_admin() -> None:
    settings = replace(make_settings(), bootstrap_admin_email="rfo.maker@example.com")
    store = MemoryStore(settings)
    assert store.find_user_by_email("rfo.maker@example.com")["role"] == "RFOAdmin"


def test_cosmos_users_map_single_role_array_to_role() -> None:
    user = {
        "id": "PROFILE|test-user",
        "email": "rfolead@example.com",
        "emailLower": "rfolead@example.com",
        "roles": ["RFOLead"],
        "isActive": True,
    }

    class FakeUsersContainer:
        def query_items(self, **kwargs):
            return [user] if kwargs["query"].startswith("SELECT") else []

    store = object.__new__(CosmosStore)
    store.settings = make_settings()
    store.users = FakeUsersContainer()

    assert store.list_users()[0]["role"] == "RFOLead"
    assert store.find_user_by_email("rfolead@example.com")["role"] == "RFOLead"


def test_cosmos_delete_user_queries_by_id_across_partitions() -> None:
    user = {"id": "PROFILE|test-user", "tenantId": "another-tenant"}

    class FakeUsersContainer:
        query = None
        deleted = None

        def query_items(self, **kwargs):
            self.query = kwargs
            return [user]

        def delete_item(self, *, item, partition_key):
            self.deleted = (item, partition_key)

    store = object.__new__(CosmosStore)
    store.users = FakeUsersContainer()

    assert store.delete_user("PROFILE|test-user")
    assert store.users.query["query"] == "SELECT TOP 1 * FROM c WHERE c.id = @id"
    assert store.users.query["parameters"] == [
        {"name": "@id", "value": "PROFILE|test-user"}
    ]
    assert store.users.query["enable_cross_partition_query"] is True
    assert store.users.deleted == ("PROFILE|test-user", "another-tenant")


def test_cosmos_application_lookup_accepts_application_id() -> None:
    application = {
        "id": "APP001|CASE",
        "applicationId": "APP001",
        "type": "Case",
        "tenantId": "test",
    }

    class FakeApplicationsContainer:
        query_options = None

        def query_items(self, **kwargs):
            self.query_options = kwargs
            return [application]

    store = object.__new__(CosmosStore)
    store.settings = make_settings()
    store.applications = FakeApplicationsContainer()

    assert store.get_application("APP001") == application
    query = store.applications.query_options
    assert query["enable_cross_partition_query"] is True
    assert "WHERE (c.applicationId = @application_id OR c.id = @application_id)" in query["query"]


def test_cosmos_application_update_uses_tenant_partition_key() -> None:
    application = {
        "id": "APP001|CASE",
        "applicationId": "APP001",
        "tenantId": "test",
    }

    class FakeApplicationsContainer:
        update_options = None

        def replace_item(self, **kwargs):
            self.update_options = kwargs
            return kwargs["body"]

    store = object.__new__(CosmosStore)
    store.applications = FakeApplicationsContainer()

    assert store.update_application(application) == application
    assert store.applications.update_options["item"] == "APP001|CASE"
    assert store.applications.update_options["partition_key"] == "test"


def test_assignment_validates_all_applications_before_writing() -> None:
    client, store = make_client(Role.RFO_LEAD)
    add_test_maker(store)
    pending = client.get("/api/v1/applications?status=pendingassignment").json()["items"][0]
    with_finnone = client.get("/api/v1/applications?status=withfinnone").json()["items"][0]

    response = client.post(
        "/api/v1/applications/assignments",
        json={
            "applicationIds": [pending["id"], with_finnone["id"]],
            "makerEmail": "rfo.maker@example.com",
        },
    )
    assert response.status_code == 409
    assert store.get_application(pending["id"])["status"] == "pendingassignment"
