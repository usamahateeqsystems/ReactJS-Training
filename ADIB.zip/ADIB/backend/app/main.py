import logging
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Annotated, Callable

from azure.cosmos.exceptions import CosmosHttpResponseError, CosmosResourceNotFoundError
from fastapi import Depends, FastAPI, HTTPException, Query, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jwt.exceptions import PyJWKClientConnectionError
from requests import RequestException

from .config import Settings
from .models import (
    ApplicationPage,
    AssignmentRequest,
    FinnOneStatusUpdate,
    MakerDecision,
    Principal,
    Role,
    UserCreate,
    UserPage,
    UserResponse,
    UserUpdate,
)
from .security import (
    AuthenticationConfigurationError,
    InvalidAccessToken,
    validate_access_token,
)
from .store import CosmosStore, create_store

logger = logging.getLogger(__name__)
bearer_scheme = HTTPBearer(auto_error=False)
USER_ADMIN_ROLES = {Role.RFO_ADMIN, Role.RFO_LEAD}
APPLICATION_ROLES = set(Role)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _clean_application(application: dict) -> dict:
    return {
        key: value
        for key, value in application.items()
        if not key.startswith("_") and key != "tenantId"
    }


def _stage_key(application: dict) -> str:
    stage = application.get("stage") or application.get("status") or ""
    return "".join(
        character for character in str(stage).casefold() if character.isalnum()
    )


def _is_checker_review(application: dict) -> bool:
    return _stage_key(application) in {
        "checkerreview",
        "pendingatchecker",
        "finnonecheckerstage",
        "withfinnone",
    }


def _is_maker_review(application: dict) -> bool:
    return _stage_key(application) in {"makerreview", "pendingatmaker"}


def _matches_search(application: dict, search: str) -> bool:
    if not search:
        return True
    haystack = " ".join(
        str(application.get(key) or "")
        for key in (
            "id",
            "applicationId",
            "customer",
            "customerName",
            "eid",
            "emiratesId",
            "product",
            "subProduct",
            "submittedBy",
            "branchName",
            "branchId",
            "submitted",
            "lastEventAt",
            "latestRunId",
            "finnOneStatus",
            "status",
            "stage",
            "assignedMaker",
            "assignedMakerName",
            "assignedChecker",
            "makerDecision",
            "outcome",
            "rejectionReason",
            "rfoProcessorComments",
        )
    )
    return search.casefold() in haystack.casefold()


def _paginate(items: list, offset: int, limit: int) -> dict:
    return {
        "items": items[offset : offset + limit],
        "total": len(items),
        "offset": offset,
        "limit": limit,
    }


def _dashboard_summary(applications: list[dict]) -> dict:
    def normalized_status(app: dict) -> str:
        stage = _stage_key(app)
        if stage in {"makerreview", "pendingatmaker"}:
            return "pendingatmaker"
        if stage in {
            "checkerreview",
            "pendingatchecker",
            "finnonecheckerstage",
            "withfinnone",
        }:
            return "withfinnone"
        return stage

    completed = [app for app in applications if normalized_status(app) == "completed"]
    rejected = [
        app
        for app in applications
        if "reject"
        in str(
            app.get("outcome")
            or app.get("makerDecision")
            or app.get("finnOneStatus")
            or app.get("rejectionReason")
            or ""
        ).casefold()
    ]
    accepted = [
        app
        for app in applications
        if normalized_status(app) == "completed"
        and any(
            marker
            in str(
                app.get("outcome")
                or app.get("makerDecision")
                or app.get("finnOneStatus")
                or ""
            ).casefold()
            for marker in ("accept", "approv")
        )
    ]
    completed_rejected = [
        app for app in rejected if normalized_status(app) == "completed"
    ]
    flagged = [
        app
        for app in applications
        if int(app.get("flags") or app.get("flaggedDocumentCount") or 0) > 0
    ]
    pending_assignment = sum(
        normalized_status(app) == "pendingassignment" for app in applications
    )
    pending_maker = sum(
        normalized_status(app) == "pendingatmaker" for app in applications
    )
    pending_checker = sum(
        normalized_status(app) == "withfinnone" for app in applications
    )
    pending = max(0, len(applications) - len(completed))

    def flat_trend(value: int) -> list[int]:
        start = max(0, round(value * 0.7))
        return [round(start + ((value - start) * index / 7)) for index in range(8)]

    sub_products: dict[str, dict] = {}
    for app in applications:
        label = app.get("subProduct") or "Standard"
        row = sub_products.setdefault(
            label,
            {
                "label": label,
                "volume": 0,
                "completed": 0,
                "accepted": 0,
                "rejected": 0,
                "flagged": 0,
                "topDiscrepancy": "Document discrepancy",
            },
        )
        row["volume"] += 1
        row["completed"] += normalized_status(app) == "completed"
        row["accepted"] += app in accepted
        row["rejected"] += app in rejected
        row["flagged"] += (
            int(app.get("flags") or app.get("flaggedDocumentCount") or 0) > 0
        )
        if app.get("rejectionReason"):
            row["topDiscrepancy"] = app["rejectionReason"]

    reasons: dict[str, int] = {}
    for app in rejected:
        reason = (
            app.get("rejectionReason")
            or app.get("rfoProcessorComments")
            or app.get("decisionComments")
            or "Rejected in FinnOne"
        )
        reasons[reason] = reasons.get(reason, 0) + 1

    return {
        "kpis": {
            "processed": len(applications),
            "processedDelta": 0,
            "timeMin": 25,
            "timeDelta": 0,
            "completed": len(completed),
            "completedDelta": 0,
            "accepted": len(accepted),
            "rejected": len(completed_rejected),
            "flagged": len(flagged),
            "flaggedDelta": 0,
            "pending": pending,
            "pendingDelta": 0,
        },
        "statusBars": {
            "pendingAssignment": pending_assignment,
            "pendingMaker": pending_maker,
            "pendingChecker": pending_checker,
            "completed": len(completed),
        },
        "trendSeries": [
            {
                "key": "total",
                "label": "Total",
                "color": "#2952E8",
                "points": flat_trend(len(applications)),
            },
            {
                "key": "completed",
                "label": "Completed",
                "color": "#16A34A",
                "points": flat_trend(len(completed)),
            },
            {
                "key": "flagged",
                "label": "Discrepancies",
                "color": "#F97316",
                "points": flat_trend(len(flagged)),
            },
            {
                "key": "pending",
                "label": "Pending",
                "color": "#4F46E5",
                "points": flat_trend(pending),
            },
        ],
        "rejectionReasons": [
            {"label": label, "count": count}
            for label, count in sorted(
                reasons.items(), key=lambda item: item[1], reverse=True
            )[:6]
        ],
        "subProductPerformance": list(sub_products.values())[:6],
        "recentApplications": sorted(
            applications,
            key=lambda app: str(
                app.get("submitted")
                or app.get("lastEventAt")
                or app.get("createdAt")
                or app.get("lastAiProcessedAt")
                or ""
            ),
            reverse=True,
        )[:12],
    }


def get_current_principal(
    request: Request,
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer_scheme)],
) -> Principal:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="A valid bearer access token is required.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    settings: Settings = request.app.state.settings
    try:
        claims = request.app.state.token_validator(credentials.credentials, settings)
    except AuthenticationConfigurationError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    except InvalidAccessToken as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(exc),
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc
    except (PyJWKClientConnectionError, RequestException) as exc:
        logger.exception("Could not retrieve Microsoft Entra signing keys.")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Authentication provider is temporarily unavailable.",
        ) from exc

    email = claims.get("preferred_username") or claims.get("email") or claims.get("upn")
    if not email:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="The access token has no user email claim.",
        )

    user = request.app.state.store.find_user_by_email(email)
    if not user or not user.get("isActive", True):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account has no active application role.",
        )
    return Principal(
        id=user["id"],
        email=user["email"],
        role=user["role"],
        displayName=user.get("displayName"),
    )


def require_roles(*roles: Role) -> Callable:
    def dependency(
        principal: Annotated[Principal, Depends(get_current_principal)],
    ) -> Principal:
        if principal.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to perform this action.",
            )
        return principal

    return dependency


def create_app(
    settings: Settings | None = None,
    store=None,
    token_validator: Callable = validate_access_token,
) -> FastAPI:
    app_settings = settings or Settings.from_env()
    if (
        app_settings.app_env.lower() == "production"
        and not app_settings.cosmos_configured
    ):
        raise ValueError("Production requires both COSMOS_ENDPOINT and COSMOS_KEY.")
    app_store = store or create_store(app_settings)

    @asynccontextmanager
    async def lifespan(application: FastAPI):
        application.state.store.initialize()
        yield

    application = FastAPI(
        title="ADIB Sukkuk API",
        version="1.0.0",
        lifespan=lifespan,
    )
    application.state.settings = app_settings
    application.state.store = app_store
    application.state.token_validator = token_validator
    application.add_middleware(
        CORSMiddleware,
        allow_origins=list(app_settings.cors_origins),
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
    )

    @application.exception_handler(CosmosHttpResponseError)
    async def cosmos_error_handler(request: Request, exc: CosmosHttpResponseError):
        logger.error(
            "Cosmos DB request failed for %s: %s",
            request.url.path,
            exc,
            exc_info=(type(exc), exc, exc.__traceback__),
        )
        return Response(
            content='{"detail":"The data service is temporarily unavailable."}',
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            media_type="application/json",
        )

    @application.get("/api/v1/health")
    def health():
        return {
            "status": "ok",
            "dataSource": "cosmos" if isinstance(app_store, CosmosStore) else "memory",
        }

    @application.get("/api/v1/auth/me", response_model=Principal)
    def current_user(principal: Annotated[Principal, Depends(get_current_principal)]):
        return principal

    @application.get(
        "/api/v1/roles",
        dependencies=[Depends(require_roles(*APPLICATION_ROLES))],
    )
    def list_roles():
        return {"items": [role.value for role in Role]}

    @application.get(
        "/api/v1/users",
        response_model=UserPage,
        dependencies=[Depends(require_roles(*USER_ADMIN_ROLES))],
    )
    def list_users(
        role: Role | None = None,
        search: str = "",
        offset: int = Query(default=0, ge=0),
        limit: int = Query(default=50, ge=1, le=100),
    ):
        users = [
            UserResponse(**user)
            for user in app_store.list_users()
            if (role is None or user["role"] == role.value)
            and (
                not search
                or search.casefold() in user["email"].casefold()
                or search.casefold() in str(user.get("displayName") or "").casefold()
            )
        ]
        page = _paginate(users, offset, limit)
        return UserPage(**page)

    @application.post(
        "/api/v1/users",
        response_model=UserResponse,
        status_code=status.HTTP_201_CREATED,
    )
    def create_user(
        payload: UserCreate,
        principal: Annotated[Principal, Depends(require_roles(*USER_ADMIN_ROLES))],
    ):
        if app_store.find_user_by_email(str(payload.email)):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="A user with this email already exists.",
            )
        email = str(payload.email).lower()
        id = str(uuid.uuid4())
        user = {
            "id": id,
            "applicationId": "USER_" + id,
            "email": email,
            "type": "User",
            "role": payload.role.value,
            "displayName": payload.displayName or email,
            "isActive": True,
            "createdAt": datetime.now(timezone.utc).isoformat(),
            "updatedAt": datetime.now(timezone.utc).isoformat(),
            "createdBy": str(principal.email),
        }
        try:
            return UserResponse(**app_store.create_user(user))
        except CosmosHttpResponseError as exc:
            if exc.status_code == 409:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="A user with this email already exists.",
                ) from exc
            raise

    @application.patch("/api/v1/users/{user_id}", response_model=UserResponse)
    def update_user(
        user_id: str,
        payload: UserUpdate,
        principal: Annotated[Principal, Depends(require_roles(*USER_ADMIN_ROLES))],
    ):
        user = next(
            (item for item in app_store.list_users() if item["id"] == user_id), None
        )
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found."
            )
        updates = payload.model_dump(exclude_unset=True)
        if "email" in updates:
            email = str(updates["email"]).lower()
            other = app_store.find_user_by_email(email)
            if other and other["id"] != user_id:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="A user with this email already exists.",
                )
            user["email"] = email
            user["emailLower"] = email
        if updates.get("role") is not None:
            user["role"] = updates["role"].value
        if "displayName" in updates:
            user["displayName"] = updates["displayName"]
        user["updatedAt"] = _now()
        user["updatedBy"] = str(principal.email)
        try:
            return UserResponse(**app_store.update_user(user))
        except CosmosResourceNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found."
            ) from exc

    @application.delete(
        "/api/v1/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT
    )
    def delete_user(
        user_id: str,
        principal: Annotated[Principal, Depends(require_roles(*USER_ADMIN_ROLES))],
    ):
        if user_id == principal.id:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="You cannot delete your own account.",
            )
        try:
            if not app_store.delete_user(user_id):
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, detail="User not found."
                )
        except CosmosResourceNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found."
            ) from exc
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    @application.get(
        "/api/v1/applications",
        response_model=ApplicationPage,
        dependencies=[Depends(require_roles(Role.RFO_LEAD, Role.RFO_ADMIN))],
    )
    def list_applications(
        status_filter: str | None = Query(default=None, alias="status"),
        stage_filter: str | None = Query(default=None, alias="stage"),
        search: str = "",
        offset: int = Query(default=0, ge=0),
        limit: int = Query(default=50, ge=1, le=500),
    ):
        requested_status = status_filter or stage_filter
        requested_stage = (
            "".join(
                character
                for character in requested_status.casefold()
                if character.isalnum()
            )
            if requested_status
            else None
        )
        apps = [
            _clean_application(app)
            for app in app_store.list_applications()
            if (requested_stage is None or _stage_key(app) == requested_stage)
            and _matches_search(app, search)
        ]
        return ApplicationPage(**_paginate(apps, offset, limit))

    @application.get(
        "/api/v1/maker/queue",
        response_model=ApplicationPage,
        dependencies=[
            Depends(require_roles(Role.RFO_MAKER, Role.RFO_ADMIN, Role.RFO_LEAD))
        ],
    )
    def maker_queue(
        principal: Annotated[
            Principal,
            Depends(require_roles(Role.RFO_MAKER, Role.RFO_ADMIN, Role.RFO_LEAD)),
        ],
        search: str = "",
        offset: int = Query(default=0, ge=0),
        limit: int = Query(default=50, ge=1, le=500),
    ):
        apps = [
            _clean_application(app)
            for app in app_store.list_applications()
            if _is_maker_review(app) and _matches_search(app, search)
            and (
                principal.role != Role.RFO_MAKER
                or str(app.get("assignedMaker") or "").casefold()
                == str(principal.email).casefold()
            )
        ]
        return ApplicationPage(**_paginate(apps, offset, limit))

    @application.get(
        "/api/v1/checker/queue",
        response_model=ApplicationPage,
        dependencies=[
            Depends(require_roles(Role.RFO_CHECKER, Role.RFO_ADMIN, Role.RFO_LEAD))
        ],
    )
    def checker_queue(
        search: str = "",
        offset: int = Query(default=0, ge=0),
        limit: int = Query(default=50, ge=1, le=500),
    ):
        apps = [
            _clean_application(app)
            for app in app_store.list_applications()
            if _is_checker_review(app) and _matches_search(app, search)
        ]
        return ApplicationPage(**_paginate(apps, offset, limit))

    @application.get(
        "/api/v1/applications/{application_id}",
        dependencies=[Depends(require_roles(Role.RFO_LEAD, Role.RFO_ADMIN))],
    )
    def application_detail(
        application_id: str,
    ):
        app = app_store.get_application(application_id)
        if app is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Application not found."
            )
        return _clean_application(app)

    @application.post("/api/v1/applications/{application_id}/maker-decision")
    def maker_decision(
        application_id: str,
        payload: MakerDecision,
        principal: Annotated[
            Principal,
            Depends(require_roles(Role.RFO_MAKER, Role.RFO_ADMIN, Role.RFO_LEAD)),
        ],
    ):
        app = app_store.get_application(application_id)
        if app is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Application not found."
            )
        if not _is_maker_review(app):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="The application is no longer waiting for Maker review.",
            )

        comments = payload.comments.strip()
        app.update(
            {
                "stage": "withfinnone",
                "status": "pendingatchecker",
                "assignmentStage": "finnone",
                "makerDecision": payload.decision,
                "finnOneStatus": "Checker Stage",
                "outcome": "accepted" if payload.decision == "approved" else "rejected",
                "completedAt": None,
                "rejectionReason": comments if payload.decision == "rejected" else None,
                "rejectionAt": _now() if payload.decision == "rejected" else None,
                "assignedChecker": None,
                "rfoProcessorComments": comments
                or "Approved by RFO Processor. Moved to Checker stage in FinnOne.",
                "decisionComments": comments
                or "Approved by RFO Processor. Moved to Checker stage in FinnOne.",
                "rfoCheckerComments": None,
                "updatedAt": _now(),
                "updatedBy": str(principal.email),
            }
        )
        return _clean_application(app_store.update_application(app))

    @application.post("/api/v1/applications/assignments")
    def assign_applications(
        payload: AssignmentRequest,
        principal: Annotated[
            Principal, Depends(require_roles(Role.RFO_LEAD, Role.RFO_ADMIN))
        ],
    ):
        maker = app_store.find_user_by_email(str(payload.makerEmail))
        if (
            not maker
            or not maker.get("isActive", True)
            or maker["role"] != Role.RFO_MAKER.value
        ):
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="The selected account is not an active RFO Maker.",
            )

        applications = []
        for application_id in payload.applicationIds:
            app = app_store.get_application(application_id)
            if app is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Application {application_id} was not found.",
                )
            if _stage_key(app) != "pendingassignment":
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Application {application_id} is no longer pending assignment.",
                )
            applications.append(app)

        updated = []
        for app in applications:
            app.update(
                {
                    "assignedMaker": str(maker["email"]),
                    "status": "pendingatmaker",
                    "stage": "makerreview",
                    "assignmentStage": "maker",
                    "assignedAt": _now(),
                    "updatedAt": _now(),
                    "updatedBy": str(principal.email),
                }
            )
            updated.append(_clean_application(app_store.update_application(app)))
        return {"updatedCount": len(updated), "items": updated}

    @application.patch("/api/v1/applications/{application_id}/finnone-status")
    def update_finnone_status(
        application_id: str,
        payload: FinnOneStatusUpdate,
        principal: Annotated[
            Principal,
            Depends(require_roles(Role.RFO_CHECKER, Role.RFO_LEAD, Role.RFO_ADMIN)),
        ],
    ):
        app = app_store.get_application(application_id)
        if app is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Application not found."
            )
        if _stage_key(app) == "completed":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Completed applications cannot be changed.",
            )
        if principal.role == Role.RFO_CHECKER and not _is_checker_review(app):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="The application is not waiting for Checker review.",
            )
        app["finnOneStatus"] = payload.status
        if payload.status == "Completed":
            app["stage"] = "completed"
            app["assignmentStage"] = "completed"
            app["completedAt"] = _now()
            if not app.get("outcome") and app.get("makerDecision") == "approved":
                app["outcome"] = "accepted"
            if not app.get("outcome") and app.get("makerDecision") == "rejected":
                app["outcome"] = "rejected"
        elif app.get("makerDecision"):
            app["stage"] = "withfinnone"
            app["assignmentStage"] = "finnone"
            app["completedAt"] = None
        app["updatedAt"] = _now()
        app["updatedBy"] = str(principal.email)
        return _clean_application(app_store.update_application(app))

    @application.get(
        "/api/v1/dashboard/overview",
        dependencies=[Depends(require_roles(*APPLICATION_ROLES))],
    )
    def dashboard_overview():
        apps = [_clean_application(app) for app in app_store.list_applications()]
        return _dashboard_summary(apps)

    return application


app = create_app()
