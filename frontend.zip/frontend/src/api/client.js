import { InteractionRequiredAuthError } from '@azure/msal-browser'

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000').replace(/\/$/, '')
const API_SCOPE = import.meta.env.VITE_API_SCOPE

export function createApiClient(instance, account) {
  const fetchAuthorized = async (path, options = {}) => {
    if (!API_SCOPE) {
      throw new Error('VITE_API_SCOPE is not configured. Set it to the API delegated scope.')
    }

    let tokenResponse
    try {
      tokenResponse = await instance.acquireTokenSilent({ scopes: [API_SCOPE], account })
    } catch (error) {
      if (error instanceof InteractionRequiredAuthError) {
        await instance.acquireTokenRedirect({ scopes: [API_SCOPE], account })
        return new Promise(() => {})
      }
      throw error
    }

    const headers = new Headers(options.headers)
    headers.set('Authorization', `Bearer ${tokenResponse.accessToken}`)
    if (options.body && !headers.has('Content-Type')) {
      headers.set('Content-Type', 'application/json')
    }

    const response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers })
    console.log(`${API_BASE_URL}${path}`);
    return response
  }

  const readError = async (response) => {
    const responseText = await response.text()
    if (!responseText) {
      return `API request failed with status ${response.status}.`
    }
    try {
      const data = JSON.parse(responseText)
      return data?.detail || `API request failed with status ${response.status}.`
    } catch {
      return `The API returned an invalid response (${response.status}).`
    }
  }

  const request = async (path, options = {}) => {
    const response = await fetchAuthorized(path, options)
    const responseText = response.status === 204 ? '' : await response.text()
    let data = null

    if (responseText) {
      try {
        data = JSON.parse(responseText)
      } catch {
        throw new Error(`The API returned an invalid response (${response.status}).`)
      }
    }
    if (!response.ok) {
      throw new Error(data?.detail || `API request failed with status ${response.status}.`)
    }
    return data
  }

  const requestBlob = async (path) => {
    const response = await fetchAuthorized(path)
    if (!response.ok) {
      throw new Error(await readError(response))
    }
    const blob = await response.blob()
    return {
      blob,
      contentType: response.headers.get('Content-Type') || blob.type,
    }
  }

  return {
    get: (path) => request(path),
    getBlob: (path) => requestBlob(path),
    post: (path, body) => request(path, { method: 'POST', body: JSON.stringify(body) }),
    patch: (path, body) => request(path, { method: 'PATCH', body: JSON.stringify(body) }),
    delete: (path) => request(path, { method: 'DELETE' }),
  }
}
