export const msalConfig = {
    auth: {
        clientId: "ce684b77-0928-4376-878e-0e6a87213175",
        authority: "https://login.microsoftonline.com/bc0ef24a-f8b9-4df5-8596-7fe389934e83",
        redirectUri: "http://localhost:5173",
        postLogoutRedirectUri: "http://localhost:5173",
    },
    cache: {
        cacheLocation: "sessionStorage",
        storeAuthStateInCookie: false,
    }
};

export const loginRequest = {
    scopes: [
        "openid",
        "profile",
        "email",
        ...(import.meta.env.VITE_API_SCOPE ? [import.meta.env.VITE_API_SCOPE] : []),
    ]
} 