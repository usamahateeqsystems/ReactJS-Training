export default function Toast({ zIndexClass = 'z-50' }) {
  return (
    <div
      className={`fixed bottom-6 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-5 py-3 rounded-lg shadow-lg text-[13px] ${zIndexClass} opacity-0 pointer-events-none transition-opacity duration-200`}
      id="toast"
    ></div>
  )
}
