import { Navigate, Outlet, useOutletContext } from 'react-router-dom'
import { canAccessPage } from '../auth/roleAccess.js'

export default function RequireRole({ page }) {
  const context = useOutletContext()

  if (!canAccessPage(context?.user?.role, page)) {
    return <Navigate to="/" replace />
  }

  return <Outlet context={context} />
}
