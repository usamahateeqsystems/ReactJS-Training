import { useOutletContext } from 'react-router-dom'
import {
  useMsal,
} from '@azure/msal-react'
import { canAccessPage } from '../auth/roleAccess.js'

const navigationItems = [
  { page: 'overview', label: 'Overview', icon: 'fa-chart-line', href: '/overview' },
  { page: 'application-tracker', label: 'Application Tracker', icon: 'fa-clipboard-list', href: '/application-tracker' },
  { page: 'maker', label: 'Maker Stage', icon: 'fa-user-check', href: '/maker' },
  { page: 'checker', label: 'Checker Stage', icon: 'fa-clipboard-check', href: '/checker' },
  { page: 'userlist', label: 'User List', icon: 'fa-users', href: '/userlist' },
  { page: 'settings', label: 'Settings', icon: 'fa-cog', href: '#' },
]

export default function Sidebar({ activePage }) {
  const authContext = useOutletContext()
  const { instance } = useMsal();
  const logout = () => {
    instance.logoutRedirect();
  };



  const user = authContext?.user
  const profileName = user?.displayName || user?.email
  const profileRole = user?.role
  const visibleNavigationItems = navigationItems.filter(({ page }) => canAccessPage(profileRole, page))

  return (
    <aside className="sidebar-bg w-[180px] min-h-screen flex flex-col fixed left-0 top-0 z-30">
      <div className="flex flex-col items-center pt-6 pb-8">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-white text-[28px] font-extrabold tracking-wide">
            ADIB
          </span>
        </div>
        <span className="text-blue-200 text-[11px] mt-0.5 brand-ar">
          مصرف أبوظبي الإسلامي
        </span>
      </div>
      <nav className="flex flex-col gap-1 px-3">
        {visibleNavigationItems.map(({ page, label, icon, href }) => {
          const isActive = page === activePage

          return (
            <a
              key={page}
              className={isActive
                ? 'flex items-center gap-3 px-4 py-3 rounded-xl text-white font-medium text-[13px] nav-active'
                : 'flex items-center gap-3 px-4 py-3 rounded-xl text-blue-200 hover:text-white text-[13px] transition nav-idle'}
              href={href}
            >
              <i className={`fas ${icon} text-[16px]`}></i>
              <span>{label}</span>
            </a>
          )
        })}
      </nav>
      <div className="mt-auto flex items-center gap-3 px-4 py-5">
        {profileName && profileRole && (
          <>
            <div className="w-9 h-9 bg-blue-300/40 rounded-full flex items-center justify-center">
              <i className="fas fa-user text-white/80 text-sm"></i>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="inline-block text-white text-[12px] font-medium flex items-center gap-1">
                {profileName}
              </span>
              <span className="text-blue-300 text-[10px]">{profileRole}</span>
            </div>
            <button onClick={logout} title="Logout" className="text-blue-200 hover:text-white text-[12px]">
              <i className="fas fa-right-from-bracket"></i>
            </button>
          </>
        )}
      </div>
    </aside>
  )
}
