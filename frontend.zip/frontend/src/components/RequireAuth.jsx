import { useEffect, useMemo, useState } from 'react'
import { InteractionStatus } from '@azure/msal-browser'
import { useMsal } from '@azure/msal-react'
import { Navigate, Outlet } from 'react-router-dom'
import { createApiClient } from '../api/client.js'
import LoadingSpinner from './LoadingSpinner.jsx'


export default function RequireAuth() {
  const { accounts, inProgress, instance } = useMsal()
  const account = accounts[0]
  const api = useMemo(() => account ? createApiClient(instance, account) : null, [account, instance])
  const [user, setUser] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (inProgress !== InteractionStatus.None || !api) return undefined

    let active = true
    setLoading(true)
    setError('')
    api.get('/api/v1/auth/me')
      .then((authenticatedUser) => {
        if (active) setUser(authenticatedUser)
      })
      .catch((requestError) => {
        if (active) setError(requestError.message)
      })
      .finally(() => {
        if (active) setLoading(false)
      })

    return () => { active = false }
  }, [api, inProgress])

  if (inProgress !== InteractionStatus.None) {
    return <LoadingSpinner />;
  }

  if (accounts.length === 0) {
    return <Navigate to="/login" replace />
  }

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="max-w-lg rounded-2xl border border-red-100 bg-white p-6 shadow-sm">
          <h1 className="text-[16px] font-semibold text-gray-900">Unable to verify access</h1>
          <p className="mt-2 text-[13px] text-red-700" role="alert">{error}</p>
        </div>
      </div>
    )
  }

  return <Outlet context={{ user, api }} />
}
