import { BrowserRouter, Routes, Route } from "react-router-dom";
import './styles/app.css'
import ApplicationTracker from "./pages/ApplicationTrackerPage";
import CheckerPage from "./pages/CheckerPage";
import Login from "./pages/LoginPage";
import Maker from "./pages/MakerPage";
import Overview from "./pages/OverviewPage";
import Home from "./pages/HomePage";
import AddUpdateUser from "./pages/AddUpdateUser";
import UserList from "./pages/UserListPage";
import RequireAuth from "./components/RequireAuth";
import RequireRole from "./components/RequireRole";

export default function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route element={<RequireAuth />}>
                    <Route path="/index" element={<Home />} />
                    <Route path="/" element={<Home />} />
                    <Route element={<RequireRole page="application-tracker" />}>
                        <Route path="/application-tracker" element={<ApplicationTracker />} />
                    </Route>
                    <Route element={<RequireRole page="checker" />}>
                        <Route path="/checker" element={<CheckerPage />} />
                    </Route>
                    <Route element={<RequireRole page="maker" />}>
                        <Route path="/maker" element={<Maker />} />
                    </Route>
                    <Route element={<RequireRole page="overview" />}>
                        <Route path="/overview" element={<Overview />} />
                    </Route>
                    <Route element={<RequireRole page="userlist" />}>
                        <Route path="/userlist" element={<UserList />} />
                        <Route path="/add-update-user" element={<AddUpdateUser />} />
                    </Route>
                </Route>
            </Routes>
        </BrowserRouter>
    );
}