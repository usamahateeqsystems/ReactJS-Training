import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import LoginPage from '../pages/LoginPage.jsx'

const msalState = vi.hoisted(() => ({
  instance: {
    loginRedirect: vi.fn(),
  },
  accounts: [],
}))

vi.mock('@azure/msal-react', () => ({
  useMsal: () => ({
    instance: msalState.instance,
    accounts: msalState.accounts,
  }),
}))

describe('LoginPage', () => {
  beforeEach(() => {
    msalState.accounts = []
    msalState.instance.loginRedirect.mockReset()
  })

  it('starts Microsoft redirect login when the sign-in button is clicked', async () => {
    const user = userEvent.setup()
    render(
      <MemoryRouter>
        <LoginPage />
      </MemoryRouter>,
    )

    await user.click(screen.getByRole('button', { name: 'Sign in with Microsoft' }))

    expect(msalState.instance.loginRedirect).toHaveBeenCalledOnce()
  })

  it('renders the ADIB login experience', () => {
    render(
      <MemoryRouter>
        <LoginPage />
      </MemoryRouter>,
    )

    expect(screen.getByRole('heading', { name: 'Login' })).toBeInTheDocument()
    expect(screen.getByText('Sukkuk Personal Finance Dashboard')).toBeInTheDocument()
  })
})
