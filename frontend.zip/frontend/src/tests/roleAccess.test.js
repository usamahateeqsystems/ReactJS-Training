import { describe, expect, it } from 'vitest'
import { canAccessPage } from '../auth/roleAccess.js'

describe('canAccessPage', () => {
  it('allows RFOMaker to access overview and maker pages', () => {
    expect(canAccessPage('RFOMaker', 'overview')).toBe(true)
    expect(canAccessPage('RFOMaker', 'maker')).toBe(true)
  })

  it('denies RFOMaker access to checker and application tracker', () => {
    expect(canAccessPage('RFOMaker', 'checker')).toBe(false)
    expect(canAccessPage('RFOMaker', 'application-tracker')).toBe(false)
  })

  it('allows RFOLead to access the complete operational workflow', () => {
    expect(canAccessPage('RFOLead', 'overview')).toBe(true)
    expect(canAccessPage('RFOLead', 'maker')).toBe(true)
    expect(canAccessPage('RFOLead', 'application-tracker')).toBe(true)
    expect(canAccessPage('RFOLead', 'checker')).toBe(true)
  })

  it('allows RFOAdmin to access settings and operational pages', () => {
    expect(canAccessPage('RFOAdmin', 'settings')).toBe(true)
    expect(canAccessPage('RFOAdmin', 'application-tracker')).toBe(true)
  })

  it('limits RFOChecker to overview and checker pages', () => {
    expect(canAccessPage('RFOChecker', 'overview')).toBe(true)
    expect(canAccessPage('RFOChecker', 'checker')).toBe(true)
    expect(canAccessPage('RFOChecker', 'maker')).toBe(false)
  })

  it('limits UserAdmin to user administration pages', () => {
    expect(canAccessPage('UserAdmin', 'userlist')).toBe(true)
    expect(canAccessPage('UserAdmin', 'settings')).toBe(true)
    expect(canAccessPage('UserAdmin', 'overview')).toBe(false)
  })

  it('denies unknown roles and unknown pages', () => {
    expect(canAccessPage('UnknownRole', 'overview')).toBe(false)
    expect(canAccessPage('RFOMaker', 'unknown-page')).toBe(false)
  })

  it('handles missing role values safely', () => {
    expect(canAccessPage(undefined, 'overview')).toBe(false)
    expect(canAccessPage(null, 'maker')).toBe(false)
    expect(canAccessPage('', 'checker')).toBe(false)
  })
})
