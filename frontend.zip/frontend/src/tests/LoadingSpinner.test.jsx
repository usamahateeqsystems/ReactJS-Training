import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import LoadingSpinner from '../components/LoadingSpinner.jsx'

describe('LoadingSpinner', () => {
  it('renders an animated loading indicator', () => {
    render(<LoadingSpinner />)

    const spinner = document.querySelector('.animate-spin')
    expect(spinner).toBeInTheDocument()
  })
})
