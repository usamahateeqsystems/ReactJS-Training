import { render, screen } from '@testing-library/react'
import { MemoryRouter, Outlet, Route, Routes } from 'react-router-dom'
import { describe, expect, it } from 'vitest'
import RequireRole from '../components/RequireRole.jsx'

function renderProtectedRoute(role, page) {
  return render(
    <MemoryRouter initialEntries={[`/${page}`]}>
      <Routes>
        <Route element={<Outlet context={{ user: { role } }} />}>
          <Route element={<RequireRole page={page} />}>
            <Route path={`/${page}`} element={<h1>Protected page</h1>} />
          </Route>
          <Route path="/" element={<h1>Home page</h1>} />
        </Route>
      </Routes>
    </MemoryRouter>,
  )
}

describe('RequireRole', () => {
  it('renders a protected page when the role has access', () => {
    renderProtectedRoute('RFOMaker', 'maker')

    expect(screen.getByRole('heading', { name: 'Protected page' })).toBeInTheDocument()
  })

  it('redirects to home when the role does not have access', () => {
    renderProtectedRoute('RFOMaker', 'checker')

    expect(screen.getByRole('heading', { name: 'Home page' })).toBeInTheDocument()
  })

  it('redirects to home when the user role is missing', () => {
    renderProtectedRoute(undefined, 'maker')

    expect(screen.getByRole('heading', { name: 'Home page' })).toBeInTheDocument()
  })
})
