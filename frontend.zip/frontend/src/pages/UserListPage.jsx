import AddUpdateUser from './AddUpdateUser.jsx'

export default function UserListPage() {
  return <AddUpdateUser />
}
