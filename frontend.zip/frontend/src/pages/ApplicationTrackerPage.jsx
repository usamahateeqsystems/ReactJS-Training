import { useLayoutEffect } from 'react'
import { useOutletContext } from 'react-router-dom'
import { mountApplicationTracker } from '../js/applicationTracker.js'
import Sidebar from '../components/Sidebar.jsx'
import Toast from '../components/Toast.jsx'
import {
  AuthenticatedTemplate,
} from '@azure/msal-react'

function ApplicationTrackerInitializer() {
  const { api, user } = useOutletContext()

  useLayoutEffect(() => {
    mountApplicationTracker(api, user)
  }, [api, user])

  return null
}

export default function ApplicationTrackerPage() {
  return (
    <>
      <AuthenticatedTemplate>
        <ApplicationTrackerInitializer />
        <div className="flex min-h-screen">
          <Sidebar activePage="application-tracker" />
          <main className="main-content flex-1 p-6 min-h-screen">
            <div className="flex items-start justify-between mb-5 gap-4 flex-wrap">
              <div>
                <h1 className="text-[22px] font-bold text-gray-900 leading-tight">
                  Sukkuk — Application Tracker
                </h1>
                <p className="text-blue-600 text-[13px] mt-1">
                  Monitor AI processing, RFO assignment, Maker review, FinnOne status, discrepancies, and completion
                </p>
              </div>
              <button className="flex items-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 text-[13px] font-semibold shadow-sm" onClick={(event) => { window.openReportPanel() }}>
                <i className="fas fa-file-export text-[12px]"></i>
                <span>
                  Generate Report
                </span>
              </button>
            </div>
            <div className="hidden bg-amber-50 border border-amber-200 rounded-2xl px-5 py-4 mb-4 shadow-sm" id="leadAlert">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center flex-shrink-0">
                    <i className="fas fa-bell"></i>
                  </div>
                  <div>
                    <div className="text-[13px] font-semibold text-gray-900">
                      RFO Lead review alert
                    </div>
                    <div className="text-[11px] text-gray-600 mt-1">
                      <span className="font-bold" id="leadAlertCount">
                        0
                      </span>
                      AI-processed applications are pending assignment. The RFO Lead notification is triggered at 20 or more applications.
                    </div>
                  </div>
                </div>
                <span className="bg-amber-100 text-amber-800 px-2.5 py-1 rounded-full text-[10px] font-semibold whitespace-nowrap">
                  20+ threshold reached
                </span>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-4 border border-gray-100/80 shadow-sm mb-4" id="leadAssignmentPanel">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div>
                  <div className="text-[13px] font-semibold text-gray-900">
                    RFO Lead Assignment
                  </div>
                  <div className="text-[11px] text-gray-500 mt-1">
                    <span className="font-semibold text-gray-700" id="pendingAssignmentCount">
                      0
                    </span>
                    applications pending assignment · unassigned applications remain assigned to
                    <strong>
                      RFO Lead
                    </strong>
                    · automatic lead alert at
                    <strong>
                      20+
                    </strong>
                    .
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[11px] text-gray-500" id="selectedAssignmentCount">
                    0 selected
                  </span>
                  <select className="border border-gray-200 rounded-lg px-3 py-2 text-[12px] text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500" id="processorSelect">
                    <option value="">
                      Select RFO Processor
                    </option>
                    <option>
                      Mariam Khalid
                    </option>
                    <option>
                      Faisal Qureshi
                    </option>
                    <option>
                      Aisha Rahman
                    </option>
                  </select>
                  <button type="button" className="rounded-lg bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed hover:bg-blue-700 text-white px-3.5 py-2 text-[12px] font-semibold" id="assignSelectedBtn" disabled>
                    <i className="fas fa-user-check mr-1.5"></i>
                    Assign Selected
                  </button>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-gray-100/80 shadow-sm mb-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="flex-1 relative">
                  <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                  <input className="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl text-[13px] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" id="searchInput" type="text" placeholder="Search by Application ID, customer, Emirates ID, branch, status, or comments" />
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] font-semibold text-gray-500 mr-2">
                  STATUS
                </span>
                <button className="status-pill active" data-status="all">
                  All
                </button>
                <button className="status-pill" data-status="pendingassignment">
                  Pending Assignment
                </button>
                <button className="status-pill" data-status="pendingatmaker">
                  Pending at Maker
                </button>
                <button className="status-pill" data-status="withfinnone">
                  With FinnOne – Checker Stage
                </button>
                <button className="status-pill" data-status="completed">
                  Completed
                </button>
              </div>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100/80 shadow-sm overflow-hidden">
              <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
                <div className="text-[13px] text-gray-600">
                  <span className="font-semibold text-gray-900" id="resultsCount">
                    0
                  </span>
                  applications found
                </div>
                <div className="flex items-center gap-3">
                  <button className="text-[12px] text-blue-600 hover:underline" onClick={(event) => { window.clearTrackerFilters() }}>
                    Clear filters
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[2020px] text-[12px]">
                  <thead>
                    <tr className="text-blue-600 text-[11px] font-semibold bg-gray-50 border-b border-gray-100">
                      <th className="py-3 px-3 text-center w-10">
                        <input className="field-check" id="selectAllPending" type="checkbox" onChange={(event) => { window.toggleSelectAllPending(event.target.checked) }} title="Select all visible pending-assignment applications" />
                      </th>
                      <th className="py-3 px-2 text-left">
                        Application ID
                      </th>
                      <th className="py-3 text-left">
                        Customer
                      </th>
                      <th className="py-3 text-left">
                        Emirates ID
                      </th>
                      <th className="py-3 text-left">
                        Branch ID
                      </th>
                      <th className="py-3 text-left">
                        Submitted / Last Event
                      </th>
                      <th className="py-3 text-left">
                        FinnOne Status
                      </th>
                      <th className="py-3 text-left">
                        Workflow Status
                      </th>
                      <th className="py-3 text-left">
                        Discrepancy
                      </th>
                      <th className="py-3 text-left">
                        AI Runs / Latest Run ID
                      </th>
                      <th className="py-3 text-left">
                        Assigned To
                      </th>
                      <th className="py-3 text-left">
                        Outcome
                      </th>
                      <th className="py-3 text-left">
                        Decision Details
                      </th>
                      <th className="py-3 px-5 text-left">
                        Action
                      </th>
                    </tr>
                  </thead>
                  <tbody id="resultsBody"></tbody>
                </table>
              </div>
            </div>
          </main>
        </div>
        <div className="report-overlay" id="reportOverlay" onClick={(event) => { window.closeReportPanel() }}></div>
        <aside className="report-panel" id="reportPanel">
          <div className="sticky top-0 bg-white z-10 border-b border-gray-100 px-6 py-5 flex items-start justify-between">
            <div>
              <div className="text-[11px] font-semibold tracking-wider text-blue-600 uppercase">
                Application Tracker
              </div>
              <h2 className="text-[19px] font-bold text-gray-900 mt-1">
                Generate Application Report
              </h2>
              <p className="text-[12px] text-gray-500 mt-1">
                Filter the full application population and export the selected fields.
              </p>
            </div>
            <button className="w-9 h-9 rounded-lg hover:bg-gray-100 text-gray-500" onClick={(event) => { window.closeReportPanel() }}>
              <i className="fas fa-times"></i>
            </button>
          </div>
          <div className="p-6 space-y-5">
            <section className="rounded-xl border border-gray-200 p-4">
              <div className="text-[12px] font-semibold text-gray-900 mb-3">
                Report scope
              </div>
              <div className="grid grid-cols-2 gap-3">
                <label className="flex items-start gap-2 rounded-lg border border-gray-200 p-3 cursor-pointer">
                  <input className="mt-0.5 field-check" type="radio" name="reportScope" value="all" defaultChecked />
                  <span>
                    <span className="block text-[12px] font-medium text-gray-800">
                      All applications
                    </span>
                    <span className="block text-[10px] text-gray-500 mt-0.5">
                      Ignore the tracker search and status pill
                    </span>
                  </span>
                </label>
                <label className="flex items-start gap-2 rounded-lg border border-gray-200 p-3 cursor-pointer">
                  <input className="mt-0.5 field-check" type="radio" name="reportScope" value="current" />
                  <span>
                    <span className="block text-[12px] font-medium text-gray-800">
                      Current tracker view
                    </span>
                    <span className="block text-[10px] text-gray-500 mt-0.5">
                      Start from the current search and status selection
                    </span>
                  </span>
                </label>
              </div>
            </section>
            <section className="rounded-xl border border-gray-200 p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="text-[12px] font-semibold text-gray-900">
                  Report filters
                </div>
                <button className="text-[10px] text-blue-600 hover:underline" onClick={(event) => { window.resetReportFilters() }}>
                  Reset filters
                </button>
              </div>
              <div className="text-[10px] font-semibold text-gray-500 uppercase tracking-wide mb-2">
                Workflow status
              </div>
              <div className="grid grid-cols-2 gap-x-4 gap-y-2 mb-4" id="reportStatusChecks"></div>
              <div className="grid grid-cols-2 gap-3">
                <label className="text-[10px] font-semibold text-gray-500">
                  FINAL OUTCOME
                  <select className="filter-input mt-1" id="reportOutcome">
                    <option value="all">
                      All outcomes
                    </option>
                    <option value="accepted">
                      Approved / Accepted
                    </option>
                    <option value="rejected">
                      Rejected
                    </option>
                    <option value="pending">
                      No final decision
                    </option>
                  </select>
                </label>
                <label className="text-[10px] font-semibold text-gray-500">
                  DISCREPANCY
                  <select className="filter-input mt-1" id="reportDiscrepancy">
                    <option value="all">
                      All applications
                    </option>
                    <option value="yes">
                      With discrepancy
                    </option>
                    <option value="no">
                      Without discrepancy
                    </option>
                  </select>
                </label>
                <label className="text-[10px] font-semibold text-gray-500">
                  SUB-PRODUCT
                  <select className="filter-input mt-1" id="reportSubProduct">
                    <option value="all">
                      All sub-products
                    </option>
                  </select>
                </label>
                <label className="text-[10px] font-semibold text-gray-500">
                  BRANCH
                  <select className="filter-input mt-1" id="reportBranch">
                    <option value="all">
                      All branches
                    </option>
                  </select>
                </label>
                <label className="text-[10px] font-semibold text-gray-500">
                  SUBMITTED BY
                  <select className="filter-input mt-1" id="reportSubmittedBy">
                    <option value="all">
                      All submitters
                    </option>
                  </select>
                </label>
                <label className="text-[10px] font-semibold text-gray-500">
                  FINNONE STATUS
                  <select className="filter-input mt-1" id="reportFinnOne">
                    <option value="all">
                      All FinnOne statuses
                    </option>
                  </select>
                </label>
                <label className="text-[10px] font-semibold text-gray-500">
                  SUBMITTED FROM
                  <input className="filter-input mt-1" id="reportDateFrom" type="date" />
                </label>
                <label className="text-[10px] font-semibold text-gray-500">
                  SUBMITTED TO
                  <input className="filter-input mt-1" id="reportDateTo" type="date" />
                </label>
              </div>
            </section>
            <section className="rounded-xl border border-gray-200 p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="text-[12px] font-semibold text-gray-900">
                  Fields to include
                </div>
                <div className="flex gap-3">
                  <button className="text-[10px] text-blue-600 hover:underline" onClick={(event) => { window.setAllFields(true) }}>
                    Select all
                  </button>
                  <button className="text-[10px] text-gray-500 hover:underline" onClick={(event) => { window.setAllFields(false) }}>
                    Clear
                  </button>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-x-3 gap-y-2" id="reportFieldChecks"></div>
            </section>
            <div className="rounded-xl bg-blue-50 border border-blue-100 px-4 py-3 flex items-center justify-between">
              <div>
                <div className="text-[10px] text-blue-700 font-semibold uppercase tracking-wide">
                  Report preview
                </div>
                <div className="text-[13px] text-gray-800 mt-0.5">
                  <span className="font-bold" id="reportCount">
                    0
                  </span>
                  applications match the selected filters
                </div>
              </div>
              <button className="text-[11px] font-medium text-blue-700 hover:underline" onClick={(event) => { window.previewReportRows() }}>
                Refresh count
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3 pb-4">
              <button className="rounded-xl border border-gray-200 bg-white hover:bg-gray-50 px-4 py-3 text-[12px] font-semibold text-gray-700 flex items-center justify-center gap-2" onClick={(event) => { window.exportReportPDF() }}>
                <i className="far fa-file-pdf text-red-500"></i>
                Export PDF
              </button>
              <button className="rounded-xl bg-blue-600 hover:bg-blue-700 px-4 py-3 text-[12px] font-semibold text-white flex items-center justify-center gap-2" onClick={(event) => { window.exportReportExcel() }}>
                <i className="far fa-file-excel"></i>
                Export Excel
              </button>
            </div>
          </div>
        </aside>
        <Toast zIndexClass="z-[100]" />
      </AuthenticatedTemplate>
    </>
  )
}
