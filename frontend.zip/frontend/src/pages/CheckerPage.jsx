import MakerPage from './MakerPage.jsx'

export default function CheckerPage() {
  return <MakerPage mode="checker" />
}
