import { useMsal } from '@azure/msal-react'
import { loginRequest } from '../auth/authConfig.js'
import microsoftLogo from "../assets/logos/microsoft-logo.webp";
import { Navigate } from "react-router-dom";

export default function LoginPage() {

  const { instance, accounts } = useMsal();

  if (accounts.length > 0) {
    return <Navigate to="/" replace />;
  }

  const login = () => {
    instance.loginRedirect(loginRequest)
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-6">
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm w-full max-w-5xl overflow-hidden grid grid-cols-1 md:grid-cols-2 min-h-[560px]">
        <div className="sidebar-bg p-10 text-white flex flex-col justify-between">
          <div>
            <div className="text-[34px] font-extrabold tracking-wide">ADIB</div>
            <div className="brand-ar text-blue-200 text-[13px] mt-1">مصرف أبوظبي الإسلامي</div>
            <div className="mt-12">
              <h1 className="text-[26px] font-bold leading-tight">Sukkuk Personal Finance Dashboard</h1>
              <p className="text-blue-100 text-[13px] mt-3 leading-6 max-w-sm">
                Secure access to application monitoring, review, and decision workflows.
              </p>
            </div>
          </div>
          <div className="text-blue-200 text-[11px]">Role-based access · Secure workflow portal</div>
        </div>

        <div className="p-10 flex flex-col justify-center">
          <div className="mb-7">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-4">
              <i className="fas fa-lock text-lg"></i>
            </div>
            <h2 className="text-[24px] font-bold text-gray-900">Login</h2>
            <p className="text-[13px] text-gray-500 mt-1">Use your ADIB Microsoft account to securely access the portal.
            </p>
          </div>
          <button
            onClick={login}
            className="w-full rounded-xl px-4 py-3 text-[13px] font-semibold text-white bg-blue-600 hover:bg-blue-700 flex items-center justify-center gap-3">

            <img
              src={microsoftLogo}
              className="w-5 h-5"
            />

            Sign in with Microsoft

          </button>
          <div className="mt-8 space-y-2 text-xs text-gray-400">

            <p>
              <i className="fas fa-check-circle text-blue-500"></i>
              Secure Microsoft authentication
            </p>

            <p>
              <i className="fas fa-check-circle text-blue-500"></i>
              Role-based access control
            </p>

            <p>
              <i className="fas fa-check-circle text-blue-500"></i>
              Protected workflow environment
            </p>

          </div>
          <div>
          </div>
          <p className="mt-6 text-[11px] text-gray-400 text-center">Access is controlled through ADIB Identity Management.</p>
        </div>
      </div>
    </div>
  )
}
