import { useEffect, useState } from 'react'
import { useOutletContext } from 'react-router-dom'
import Sidebar from '../components/Sidebar.jsx'

export default function AddUpdateUser() {
  const { api } = useOutletContext()
  const [users, setUsers] = useState([])
  const [roles, setRoles] = useState([])
  const [email, setEmail] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [role, setRole] = useState('')
  const [editingUserId, setEditingUserId] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const loadUsers = async () => {
    setLoading(true)
    setError('')
    try {
      const result = await api.get('/api/v1/users?offset=0&limit=100')
      setUsers(result.items)
      return true
    } catch (requestError) {
      setError(requestError.message)
      return false
    } finally {
      setLoading(false)
    }
  }

  const loadRoles = async () => {
    try {
      const result = await api.get('/api/v1/roles')
      setRoles(result.items)
      setRole((currentRole) => currentRole || result.items[0] || '')
    } catch (requestError) {
      setError(requestError.message)
    }
  }

  useEffect(() => {
    loadUsers()
    loadRoles()
  }, [api])

  const resetForm = () => {
    setEmail('')
    setDisplayName('')
    setRole(roles[0] || '')
    setEditingUserId(null)
    setError('')
  }

  const saveUser = async (event) => {
    event.preventDefault()
    setSaving(true)
    setError('')
    try {
      const body = { email: email.trim(), role, displayName: displayName.trim() }
      if (editingUserId === null) {
        await api.post('/api/v1/users', body)
      } else {
        await api.patch(`/api/v1/users/${encodeURIComponent(editingUserId)}`, body)
      }
      resetForm()
      await loadUsers()
    } catch (requestError) {
      setError(requestError.message)
    } finally {
      setSaving(false)
    }
  }

  const editUser = (user) => {
    setEditingUserId(user.id)
    setEmail(user.email)
    setDisplayName(user.displayName || '')
    setRole(user.role)
    setError('')
  }

  const deleteUser = async (user) => {
    if (window.confirm(`Deactivate ${user.email}?`)) {
      setError('')
      try {
        await api.delete(`/api/v1/users/${encodeURIComponent(user.id)}`)
        await loadUsers()
        if (editingUserId === user.id) resetForm()
      } catch (requestError) {
        setError(requestError.message)
      }
    }
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar activePage="userlist" />
      <main className="main-content flex-1 p-6 min-h-screen">
        <header className="mb-5">
          <h1 className="text-[22px] font-bold text-gray-900 leading-tight">
            User Management
          </h1>
          <p className="text-blue-600 text-[13px] mt-1">
            Add users and assign access roles
          </p>
        </header>

        <section className="bg-white rounded-2xl p-5 border border-gray-100/80 shadow-sm">
          <div className="flex items-center justify-between gap-4 mb-4">
            <div>
              <h2 className="text-[15px] font-semibold text-gray-900">Users</h2>
              <p className="text-[11px] text-gray-500 mt-1">{loading ? 'Loading users…' : `${users.length} users`}</p>
            </div>
          </div>

          <form onSubmit={saveUser}   className="grid grid-cols-1 lg:grid-cols-[320px_220px_180px_auto] gap-3 items-end mb-5">
            <div>
              <label htmlFor="userEmail" className="block text-[11px] font-semibold text-gray-600 mb-1.5">
                Email
              </label>
              <input
                id="userEmail"
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="name@example.com"
                required
                className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-[13px] focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label htmlFor="displayName" className="block text-[11px] font-semibold text-gray-600 mb-1.5">
                Name
              </label>
              <input
                id="displayName"
                type="text"
                value={displayName}
                onChange={(event) => setDisplayName(event.target.value)}
                placeholder="Full Name"
                required
                className="w-full px-3 py-2.5 rounded-lg border border-gray-200 text-[13px] focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label htmlFor="userRole" className="block text-[11px] font-semibold text-gray-600 mb-1.5">
                Role
              </label>
              <select
                id="userRole"
                value={role}
                onChange={(event) => setRole(event.target.value)}
                required
                className="w-full px-3 py-2.5 rounded-lg border border-gray-200 bg-white text-[13px] focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {roles.map((userRole) => (
                  <option key={userRole} value={userRole}>{userRole}</option>
                ))}
              </select>
            </div>
            <div className="flex items-end gap-2">
              <button
                type="submit"
                disabled={saving}
                className="flex items-center justify-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 text-[13px] font-semibold shadow-sm whitespace-nowrap"
              >
                <i className={`fas ${editingUserId === null ? 'fa-user-plus' : 'fa-save'} text-[12px]`}></i>
                {saving ? 'Saving…' : editingUserId === null ? 'Add user' : 'Update user'}
              </button>
              {editingUserId !== null && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="rounded-xl border border-gray-200 px-3 py-2.5 text-[12px] font-medium text-gray-600 hover:bg-gray-50"
                >
                  Cancel
                </button>
              )}
            </div>
            {error && <p className="md:col-span-3 text-[12px] text-red-600" role="alert">{error}</p>}
          </form>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-[12px]">
              <thead>
                <tr className="text-left text-[10px] text-gray-500 uppercase tracking-wide border-b border-gray-100">
                  <th className="py-3 font-semibold">Name</th>
                  <th className="py-3 font-semibold">Email</th>
                  <th className="py-3 font-semibold">Role</th>
                  <th className="py-3 font-semibold text-right">Status</th>
                  <th className="py-3 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {!loading && users.map((user) => (
                  <tr key={user.id} className="border-b border-gray-50 last:border-0">
                    <td className="py-3 font-medium text-gray-800">{user.displayName || '-'}</td>
                    <td className="py-3 text-gray-600">{user.email}</td>
                    <td className="py-3">
                      <span className="inline-flex rounded-full bg-blue-50 text-blue-700 px-2.5 py-1 text-[10px] font-semibold">
                        {user.role}
                      </span>
                    </td>
                    <td className="py-3 text-right">
                      <span className={`inline-flex rounded-full px-2.5 py-1 text-[10px] font-semibold ${user.isActive === true ? 'bg-green-50 text-green-700' : 'bg-gray-50 text-gray-700'}`}>
                        {user.isActive === true ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="py-3">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          aria-label={`Edit ${user.email}`}
                          title="Edit user"
                          onClick={() => editUser(user)}
                          className="w-8 h-8 rounded-lg text-blue-600 hover:bg-blue-50"
                        >
                          <i className="fas fa-pen"></i>
                        </button>
                        <button
                          type="button"
                          aria-label={`Delete ${user.email}`}
                          title="Delete user"
                          onClick={() => deleteUser(user)}
                          className="w-8 h-8 rounded-lg text-red-500 hover:bg-red-50"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {users.length === 0 && (
                  <tr>
                    <td colSpan="3" className="py-8 text-center text-gray-500">
                      {loading ? 'Loading users…' : 'No users yet.'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  )
}
