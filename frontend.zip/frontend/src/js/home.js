import { canAccessPage } from '../auth/roleAccess.js'

export const ALL_PAGES = [
  {
    href: 'overview',
    title: 'Management Overview',
    description: 'KPIs and trends',
  },
  {
    href: 'application-tracker',
    title: 'Application Tracker',
    description: 'Application status, FinnOne status, discrepancies, and comments',
  },
  {
    href: 'maker',
    title: 'Maker Stage',
    description: 'Processor review and decision comments; handoff to FinnOne Checker stage',
  },
  {
    href: 'checker',
    title: 'Checker Stage',
    description: 'FinnOne checker processing',
  },
]

export function getHomeModel(role) {
  const pages = ALL_PAGES.filter((page) => canAccessPage(role, page.href))
  if (canAccessPage(role, 'userlist')) {
    pages.push({
      href: '/userlist',
      title: 'User Management',
      description: 'Manage application users and roles',
    })
  }
  const subtitle = `Signed in with the ${role} role.`
  return { pages, subtitle }
}
