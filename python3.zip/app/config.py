import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[1] / ".env")


def _csv(value: str) -> tuple[str, ...]:
    return tuple(part.strip() for part in value.split(",") if part.strip())


@dataclass(frozen=True)
class Settings:
    app_env: str
    api_host: str
    api_port: int
    cors_origins: tuple[str, ...]
    azure_tenant_id: str
    azure_api_audience: str
    cosmos_endpoint: str
    cosmos_key: str
    cosmos_database: str
    cosmos_users_container: str
    cosmos_applications_container: str
    cosmos_create_resources: bool
    cosmos_required: bool
    azure_storage_connection_string: str
    azure_blob_container: str
    bootstrap_admin_email: str
    seed_demo_data: bool

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            app_env=os.getenv("APP_ENV", "development"),
            api_host=os.getenv("API_HOST", "127.0.0.1"),
            api_port=int(os.getenv("API_PORT", "8000")),
            cors_origins=_csv(os.getenv("CORS_ORIGINS", "http://localhost:5173")),
            azure_tenant_id=os.getenv("AZURE_TENANT_ID", ""),
            azure_api_audience=os.getenv("AZURE_API_AUDIENCE", ""),
            cosmos_endpoint=os.getenv("COSMOS_ENDPOINT", ""),
            cosmos_key=os.getenv("COSMOS_KEY", ""),
            cosmos_database=os.getenv("COSMOS_DATABASE", "adib-sukkuk"),
            cosmos_users_container=os.getenv("COSMOS_USERS_CONTAINER", "users"),
            cosmos_applications_container=os.getenv("COSMOS_APPLICATIONS_CONTAINER", "applications"),
            cosmos_create_resources=os.getenv("COSMOS_CREATE_RESOURCES", "false").lower() == "true",
            cosmos_required=os.getenv("COSMOS_REQUIRED", "false").lower() == "true",
            azure_storage_connection_string=os.getenv("AZURE_STORAGE_CONNECTION_STRING", ""),
            azure_blob_container=os.getenv("AZURE_BLOB_CONTAINER", "documents"),
            bootstrap_admin_email=os.getenv("BOOTSTRAP_ADMIN_EMAIL", "").strip().lower(),
            seed_demo_data=os.getenv("SEED_DEMO_DATA", "true").lower() == "true",
        )

    @property
    def cosmos_configured(self) -> bool:
        return bool(self.cosmos_endpoint and self.cosmos_key)

    @property
    def blob_storage_configured(self) -> bool:
        return bool(self.azure_storage_connection_string and self.azure_blob_container)
