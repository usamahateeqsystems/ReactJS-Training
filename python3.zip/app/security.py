from functools import lru_cache

import jwt
from jwt import PyJWKClient
from jwt.exceptions import PyJWKClientConnectionError, PyJWTError

from .config import Settings


class InvalidAccessToken(Exception):
    pass


class AuthenticationConfigurationError(Exception):
    pass


@lru_cache(maxsize=8)
def _jwk_client(tenant_id: str) -> PyJWKClient:
    return PyJWKClient(
        f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys",
        cache_keys=True,
    )


def validate_access_token(token: str, settings: Settings) -> dict:
    if not settings.azure_tenant_id or not settings.azure_api_audience:
        raise AuthenticationConfigurationError("Microsoft Entra API authentication is not configured.")

    issuer = f"https://login.microsoftonline.com/{settings.azure_tenant_id}/v2.0"
    try:
        signing_key = _jwk_client(settings.azure_tenant_id).get_signing_key_from_jwt(token)
        claims = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            audience=settings.azure_api_audience,
            issuer=issuer,
            options={"require": ["exp", "iss", "aud", "tid"]},
        )
    except PyJWKClientConnectionError:
        raise
    except PyJWTError as exc:
        raise InvalidAccessToken("The bearer token is invalid or expired.") from exc

    if claims.get("tid") != settings.azure_tenant_id:
        raise InvalidAccessToken("The bearer token belongs to a different tenant.")
    return claims
