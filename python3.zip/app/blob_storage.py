from collections.abc import Iterable
from pathlib import PurePosixPath
from typing import BinaryIO
import uuid

from azure.core.exceptions import ResourceNotFoundError
from azure.storage.blob import BlobServiceClient, ContentSettings


class BlobNotFoundError(Exception):
    pass


class AzureBlobStorage:
    def __init__(self, connection_string: str, container_name: str):
        self._service = BlobServiceClient.from_connection_string(connection_string)
        self._container = self._service.get_container_client(container_name)

    def upload_document(
        self,
        application_id: str,
        year: int,
        file_data: BinaryIO,
        original_filename: str,
        mime_type: str,
    ) -> dict[str, str]:
        extension_by_type = {
            "application/pdf": ".pdf",
            "image/jpeg": ".jpg",
            "image/png": ".png",
        }
        extension = extension_by_type.get(mime_type)
        if extension is None:
            raise ValueError("Only PDF, JPG, and PNG documents are supported.")

        document_id = str(uuid.uuid4())
        blob_name = str(
            PurePosixPath(
                "applications",
                str(year),
                application_id,
                f"{document_id}{extension}",
            )
        )
        self._container.upload_blob(
            name=blob_name,
            data=file_data,
            overwrite=False,
            content_settings=ContentSettings(content_type=mime_type),
        )
        return {
            "documentId": document_id,
            "blobPath": blob_name,
            "blobName": PurePosixPath(blob_name).name,
            "originalFilename": PurePosixPath(
                original_filename.replace("\\", "/")
            ).name,
            "mimeType": mime_type,
        }

    def stream_document(self, blob_path: str) -> Iterable[bytes]:
        try:
            downloader = self._container.get_blob_client(blob_path).download_blob()
        except ResourceNotFoundError as exc:
            raise BlobNotFoundError("Document file not found in storage.") from exc
        # Keep document bytes streamed rather than loading the full blob into memory.
        return downloader.chunks()

    def download_document(self, blob_path: str) -> Iterable[bytes]:
        return self.stream_document(blob_path)

    def delete_document(self, blob_path: str) -> None:
        self._container.delete_blob(blob_path)
