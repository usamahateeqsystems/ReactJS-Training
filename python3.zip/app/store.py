import copy
import json
import logging
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from azure.cosmos import CosmosClient, PartitionKey
from azure.cosmos.exceptions import (
    CosmosResourceExistsError,
)

from .config import Settings

logger = logging.getLogger(__name__)
DATA_DIR = Path(__file__).resolve().parent / "data"


def load_seed(filename: str) -> list[dict[str, Any]]:
    with (DATA_DIR / filename).open(encoding="utf-8") as seed_file:
        data = json.load(seed_file)
    if not isinstance(data, list):
        raise ValueError(f"{filename} must contain a JSON array.")
    return data


class MemoryStore:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._lock = threading.RLock()
        self._users = copy.deepcopy(load_seed("users.json"))
        self._applications = copy.deepcopy(load_seed("applications.json"))
        self._add_bootstrap_admin(self._users)

    def initialize(self) -> None:
        return None

    def _add_bootstrap_admin(self, users: list[dict[str, Any]]) -> None:
        email = self.settings.bootstrap_admin_email
        if not email:
            return
        existing = next(
            (user for user in users if user["email"].lower() == email), None
        )
        if existing:
            existing["role"] = "UserAdmin"
            existing["isActive"] = True
            return
        users.append(
            {
                "id": str(uuid.uuid4()),
                "email": email,
                "emailLower": email,
                "role": "UserAdmin",
                "displayName": email,
                "isActive": True,
            }
        )

    def list_users(self) -> list[dict[str, Any]]:
        with self._lock:
            return copy.deepcopy(
                [user for user in self._users if user.get("isActive", True)]
            )

    def find_user_by_email(self, email: str) -> Optional[dict[str, Any]]:
        with self._lock:
            user = next(
                (
                    item
                    for item in self._users
                    if item["email"].lower() == email.lower()
                ),
                None,
            )
            return copy.deepcopy(user) if user else None

    def create_user(self, user: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            self._users.append(copy.deepcopy(user))
            return copy.deepcopy(user)

    def update_user(self, user: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            for index, existing in enumerate(self._users):
                if existing["id"] == user["id"]:
                    self._users[index] = copy.deepcopy(user)
                    return copy.deepcopy(user)
        raise KeyError(user["id"])

    def delete_user(self, user_id: str) -> bool:
        with self._lock:
            for index, user in enumerate(self._users):
                if user["id"] == user_id:
                    del self._users[index]
                    return True
        return False

    def list_applications(self) -> list[dict[str, Any]]:
        with self._lock:
            return copy.deepcopy(self._applications)

    def get_application(self, application_id: str) -> Optional[dict[str, Any]]:
        with self._lock:
            app = next(
                (
                    item
                    for item in self._applications
                    if item["id"] == application_id
                    or item.get("applicationId") == application_id
                ),
                None,
            )
            return copy.deepcopy(app) if app else None

    def find_document(self, document_id: str) -> Optional[dict[str, Any]]:
        for application in self.list_applications():
            documents = application.get("documents")
            if not isinstance(documents, list):
                continue
            for document in documents:
                if not isinstance(document, dict):
                    continue
                if document.get("documentId") == document_id or document.get("id") == document_id:
                    return {
                        "application": application,
                        "document": copy.deepcopy(document),
                    }
        return None

    def update_application(self, application: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            for index, existing in enumerate(self._applications):
                if existing["id"] == application["id"]:
                    self._applications[index] = copy.deepcopy(application)
                    return copy.deepcopy(application)
        raise KeyError(application["id"])


class CosmosStore(MemoryStore):
    def __init__(self, settings: Settings):
        self.settings = settings
        self._lock = threading.RLock()
        self.client = CosmosClient(
            settings.cosmos_endpoint, credential=settings.cosmos_key
        )
        self.database = None
        self.users = None
        self.applications = None

    def initialize(self) -> None:
        if self.settings.cosmos_create_resources:
            self.database = self.client.create_database_if_not_exists(
                self.settings.cosmos_database
            )
            self.users = self.database.create_container_if_not_exists(
                id=self.settings.cosmos_users_container,
                partition_key=PartitionKey(path="/tenantId"),
            )
            self.applications = self.database.create_container_if_not_exists(
                id=self.settings.cosmos_applications_container,
                partition_key=PartitionKey(path="/tenantId"),
            )
        else:
            self.database = self.client.get_database_client(
                self.settings.cosmos_database
            )
            self.users = self.database.get_container_client(
                self.settings.cosmos_users_container
            )
            self.applications = self.database.get_container_client(
                self.settings.cosmos_applications_container
            )

        if self.settings.seed_demo_data:
            self._seed_if_empty()
        self._ensure_bootstrap_admin()

    def _query(
        self,
        container,
        query: str,
        parameters: list[dict[str, Any]],
        partition_key=None,
    ) -> list[dict[str, Any]]:
        kwargs = {
            "query": query,
            "parameters": parameters,
        }

        if partition_key is None:
            kwargs["enable_cross_partition_query"] = True
        else:
            kwargs["partition_key"] = partition_key

        return list(container.query_items(**kwargs))

    @staticmethod
    def _normalize_user(user: dict[str, Any]) -> dict[str, Any]:
        normalized = dict(user)
        if "roles" in normalized:
            roles = normalized.pop("roles")
            if not isinstance(roles, list) or len(roles) != 1:
                raise ValueError("Cosmos user records must contain exactly one role.")
            normalized["role"] = roles[0]
        return normalized

    @staticmethod
    def _serialize_user(user: dict[str, Any]) -> dict[str, Any]:
        serialized = dict(user)
        role = serialized.pop("role", None)
        if role is not None:
            serialized["roles"] = [role]
        return serialized

    def _seed_if_empty(self) -> None:
        if not self._query(
            self.users,
            "SELECT TOP 1 * FROM c WHERE c.type = @type",
            [{"name": "@type", "value": "User"}],
        ):
            for user in load_seed("users.json"):
                user["emailLower"] = user["email"].lower()
                try:
                    self.users.create_item(user)
                except CosmosResourceExistsError:
                    logger.info("Skipping existing seed user %s", user["email"])
        if not self._query(
            self.applications,
            "SELECT TOP 1 * FROM c WHERE c.type = @type",
            [{"name": "@type", "value": "Application"}],
        ):
            for application in load_seed("applications.json"):
                try:
                    self.applications.create_item(application)
                except CosmosResourceExistsError:
                    logger.info(
                        "Skipping existing seed application %s", application["id"]
                    )

    def _ensure_bootstrap_admin(self) -> None:
        email = self.settings.bootstrap_admin_email
        if not email:
            return
        existing = self.find_user_by_email(email)
        if existing:
            if existing.get("role") != "UserAdmin" or not existing.get("isActive", True):
                existing["role"] = "UserAdmin"
                existing["isActive"] = True
                existing["updatedAt"] = datetime.now(timezone.utc).isoformat()
                self.update_user(existing)
            return
        id = str(uuid.uuid4())
        self.create_user(
            {
                "id": id,
                "applicationId": "USER_"+ id,
                "email": email,
                "role": "UserAdmin",
                "displayName": email,
                "isActive": True,
                "type": "User",
                "createdAt": datetime.now(timezone.utc).isoformat(),
                "updatedAt": datetime.now(timezone.utc).isoformat(),
                "createdBy": "bootstrap",

            }
        )

    def list_users(self) -> list[dict[str, Any]]:
        users = self._query(
            self.users,
            "SELECT * FROM c WHERE c.isActive = true",
            [],
        )
        return [self._normalize_user(user) for user in users]

    def find_user_by_email(self, email: str) -> Optional[dict[str, Any]]:
        found = self._query(
            self.users,
            "SELECT TOP 1 * FROM c WHERE c.type = @type AND c.email = @email",
            [
                {"name": "@type", "value": "User"},
                {"name": "@email", "value": email.lower()},
            ],
        )
        return self._normalize_user(found[0]) if found else None

    def create_user(self, user: dict[str, Any]) -> dict[str, Any]:
        created = self.users.create_item(body=self._serialize_user(user))
        return self._normalize_user(created)

    def update_user(self, user: dict[str, Any]) -> dict[str, Any]:
        updated = self.users.replace_item(
            item=user["id"], body=self._serialize_user(user)
        )
        return self._normalize_user(updated)

    def delete_user(self, user_id: str) -> bool:
        from azure.cosmos.exceptions import CosmosResourceNotFoundError
        users = self._query(
            self.users,
            "SELECT TOP 1 * FROM c WHERE c.id = @id",
            [{"name": "@id", "value": user_id}],
        )
        if not users:
            return False

        user = users[0]

        self.users.delete_item(
            item=user["id"],
            partition_key=user["applicationId"],
        )

        try:
            self.users.read_item(
                item=user["id"],
                partition_key=user["applicationId"],
            )
            print("Still exists")
        except CosmosResourceNotFoundError as e:
            print("Deleted" + str(e))
        
        return True

    def list_applications(self) -> list[dict[str, Any]]:
        return self._query(
            self.applications,
            "SELECT * FROM c WHERE c.type = @case",
            [{"name": "@case", "value": "Case"}],
        )

    def get_application(self, application_id: str) -> Optional[dict[str, Any]]:
        applications = self._query(
            self.applications,
            "SELECT TOP 1 * FROM c WHERE c.type = @case"
            " AND (c.applicationId = @application_id OR c.id = @application_id)",
            [
                {"name": "@case", "value": "Case"},
                {"name": "@application_id", "value": application_id},
            ],
        )
        return applications[0] if applications else None

    def find_document(self, document_id: str) -> Optional[dict[str, Any]]:
        matches = self._query(
            self.applications,
            "SELECT VALUE {\"application\": c, \"document\": d} "
            "FROM c JOIN d IN c.documents "
            "WHERE c.type = @case "
            "AND (d.documentId = @document_id OR d.id = @document_id)",
            [
                {"name": "@case", "value": "Case"},
                {"name": "@document_id", "value": document_id},
            ],
        )
        return matches[0] if matches else None

    def update_application(self, application: dict[str, Any]) -> dict[str, Any]:
        return self.applications.replace_item(
            item=application["id"],
            body=application,
        )


def create_store(settings: Settings):
    has_cosmos_setting = bool(settings.cosmos_endpoint) or bool(settings.cosmos_key)
    if has_cosmos_setting and not settings.cosmos_configured:
        raise ValueError(
            "Set both COSMOS_ENDPOINT and COSMOS_KEY, or leave both empty."
        )
    if settings.cosmos_configured:
        return CosmosStore(settings)
    if settings.cosmos_required:
        raise ValueError(
            "COSMOS_REQUIRED is true, but Cosmos DB connection settings are missing."
        )
    logger.warning("Cosmos DB is not configured; using in-memory demo data.")
    return MemoryStore(settings)
