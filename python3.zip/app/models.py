from enum import Enum
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator


class Role(str, Enum):
    RFO_LEAD = "RFOLead"
    RFO_CHECKER = "RFOChecker"
    RFO_MAKER = "RFOMaker"
    USER_ADMIN = "UserAdmin"


class UserCreate(BaseModel):
    email: EmailStr
    role: Role
    displayName: Optional[str] = None


class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    role: Optional[Role] = None
    displayName: Optional[str] = None


class UserResponse(BaseModel):
    id: str
    email: EmailStr
    role: Role
    displayName: Optional[str] = None
    isActive: bool = True


class UserPage(BaseModel):
    items: list[UserResponse]
    total: int
    offset: int
    limit: int


class ApplicationPage(BaseModel):
    items: list[dict]
    total: int
    offset: int
    limit: int


class MakerDecision(BaseModel):
    decision: Literal["approved", "rejected"]
    comments: str = Field(default="", max_length=5000)

    @model_validator(mode="after")
    def require_rejection_comments(self) -> "MakerDecision":
        if self.decision == "rejected" and not self.comments.strip():
            raise ValueError("Comments are required when rejecting an application.")
        return self


class AssignmentRequest(BaseModel):
    applicationIds: list[str] = Field(min_length=1, max_length=100)
    makerEmail: EmailStr

    @field_validator("applicationIds")
    @classmethod
    def require_unique_ids(cls, value: list[str]) -> list[str]:
        if len(set(value)) != len(value):
            raise ValueError("Application IDs must be unique.")
        return value


class FinnOneStatusUpdate(BaseModel):
    status: Literal[
        "In Process",
        "RFF Creation",
        "Checker Stage",
        "Approved",
        "Rejected",
        "Completed",
    ]


class Principal(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    email: EmailStr
    role: Role
    displayName: Optional[str] = None
