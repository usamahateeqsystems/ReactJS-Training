# ADIB Sukkuk API

FastAPI service for role lookup, user administration, application workflow actions, and dashboard data. It uses Cosmos DB when configured and otherwise serves the checked-in demo JSON fixtures from in-memory storage.

## Local setup

1. Use Python 3.11 or newer.
2. From `backend`, create and activate a virtual environment, then install:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```

3. Copy `.env.example` to `.env`. Set `AZURE_TENANT_ID` and `AZURE_API_AUDIENCE` to the values for the Entra API app registration.
4. Run the server from `backend`:

   ```powershell
   python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
   ```

5. Open `http://localhost:8000/docs` to inspect the OpenAPI endpoints.

In-memory mode is for local development and loses changes when the server restarts. Set both Cosmos connection variables to use Cosmos DB. `COSMOS_REQUIRED=true` (and `APP_ENV=production`) prevents startup without a configured Cosmos account. Set `COSMOS_CREATE_RESOURCES=true` only when the application is allowed to create the database and containers.

Set `AZURE_STORAGE_CONNECTION_STRING` and `AZURE_BLOB_CONTAINER` in the backend environment to enable private document previews, and keep public access disabled on the container. The API streams supported PDF, JPG, and PNG files through `GET /documents/{documentId}/preview`; application document records must include `documentId`, `blobPath`, `blobName`, `originalFilename`, and `mimeType`. The frontend receives document bytes only from the authenticated API and never receives Blob Storage URLs or SAS tokens.

For the Vite frontend, copy `frontend/.env.example` to `frontend/.env.local`, set `VITE_API_SCOPE` to the delegated scope exposed by the API app registration, then run `npm run dev` from the `frontend` directory.

## Microsoft Entra ID

Register the API separately from the SPA, expose a delegated scope such as `access_as_user`, and grant that scope to the SPA registration. Set `AZURE_API_AUDIENCE` to the API's configured audience and set the frontend `VITE_API_SCOPE` to the full delegated scope, for example `api://<api-client-id>/access_as_user`. The backend validates the bearer token signature, audience, issuer, expiration, and tenant. User roles are looked up server-side by token email; browser storage is not trusted.

`BOOTSTRAP_ADMIN_EMAIL` optionally provisions one active `UserAdmin` account at startup. In Cosmos mode, use this to bootstrap user administration. Do not commit `.env` files or place Cosmos keys in frontend variables.

## Cosmos DB

The service uses the database and container names in `.env`, creating containers only when `COSMOS_CREATE_RESOURCES=true`. This is a practical initial single-tenant layout; revisit partitioning and throughput as production data volume grows.

When `SEED_DEMO_DATA=true`, the service loads the bundled sample users and applications only into empty containers. The initial applications JSON is exported from the matching Maker and Application Tracker fixtures. Turn seeding off for an existing production database.

## API summary

- `GET /api/v1/health`
- `GET /api/v1/auth/me`, `GET /api/v1/roles`
- `GET/POST /api/v1/users`, `PATCH/DELETE /api/v1/users/{id}`
- `GET /api/v1/applications`, `GET /api/v1/applications/{id}`
- `GET /api/v1/maker/queue`, `GET /api/v1/checker/queue`
- `GET /documents/{documentId}/preview`
- `POST /api/v1/applications/{id}/maker-decision`
- `POST /api/v1/applications/assignments`
- `PATCH /api/v1/applications/{id}/finnone-status`
- `GET /api/v1/dashboard/overview`

The assignments endpoint accepts `applicationIds` and a `makerEmail`, validates that every application is still pending assignment and that the selected account is an active RFO Maker, then records the assignment and moves the applications to Maker review.

User management and workflow mutations are role-authorized on the server. The Maker queue is available to RFO Makers, Leads, and Admins; the Checker queue is available to RFO Checkers and Admins. Application-wide listing and detail access is limited to Leads and Admins. Lists use `offset` and `limit`; user search/filtering supports `search` and `role`, and applications support `search` and `status`.

## Tests

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest
```
